package agrl;

//La difficult�e du jeu influe sur les risques d'avoir des �venements al�atoire dangereux

public class Difficulty {
	
	
	protected int value ; // valeur de la difficult�e 1,2 ou 3 (1 easy, 2 medium, 3 hard)
	
	public Difficulty(int value){
		
		this.value = value;
		
	}
	
	public void setDifficulty(int value){
		
		if ((value>=0)&&(value<=3)){
			
			this.value = value;
		}
	}
	
	public int getDifficulty(){
		
		return this.value;
		
	}
}
