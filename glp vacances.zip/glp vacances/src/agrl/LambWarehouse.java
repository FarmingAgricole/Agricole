package agrl;

public class LambWarehouse {
	private Lamb[] lambs;
	protected int maxCapacity;
	protected int currentSize = 0;

	public LambWarehouse(int maxCapacity) {
		this.maxCapacity = maxCapacity;
		lambs = new Lamb[maxCapacity];
	}

	public void add(Lamb Lamb) {
		if (currentSize != lambs.length) {
			lambs[currentSize] = Lamb;
			currentSize++;
		}
	}

	public void remove(Lamb Lamb) {
		int i;
		for (i = 0; i<currentSize; i++) {
			if (lambs[i].equals(Lamb)) {
				lambs[i] = null;
				break;
			}
		}
		for (int j = i; i<currentSize -1; i++) {
			lambs[j] = lambs[j + 1];
		}
		if (i != currentSize) {
			currentSize--;
		}
	}

	public void check() {
		for(int i=0; i<currentSize;i++) {
			if(	lambs[i].lapsingStatus()) {
				remove(lambs[i]);
				System.out.println("EXPIRE");
				System.out.println("Lamb at posistion " + i + " is removed");
		}
	}
	}
	
	public int warningCheck() { //Check number of all item ready to pass date limit
		int val = 0;
		for(int i=0; i<currentSize;i++) {
			if(	lambs[i].lapsingWarning()) {
				val++;
			}
		}
		return val;
	}

	public Lamb accesValue(int search) {
		Lamb res = null;
		for(int i=0; i<currentSize;i++) {
			if (i == search) {
				res = lambs[i];
			}
		}
		return res;
	}
	public int getSize() {
		return currentSize;
	}
}
