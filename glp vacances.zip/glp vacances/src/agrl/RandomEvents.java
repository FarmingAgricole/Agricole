package agrl;
import java.util.Random;


public class RandomEvents {
	
	public RandomEvents(){
		
	}
	
	// risque d'activer un �venement al�atoire, a utiliser � chaque d�but de tour sauf le 1er
	
	public void RandomEventsrisk(Turn turn,Case caseOp, StrawberryWarehouse strawberrywarehouse, CarrotWarehouse carrotwarehouse, Difficulty difficulty, Enclosure enclosure, Field field){
		
		Random rn = new Random();
		int randomint = rn.nextInt(100) + 1; // from 1 to 100 = 100 differents possibilities
		
		// (=1 chance sur 3 pour chacun)
		if(randomint<=5*difficulty.getDifficulty()){
			System.out.println("random event triggered :" + randomint);
			
			randomint = rn.nextInt(3) + 1; //from 1 to 3
			
			if(randomint==1){
				
				System.out.println("fireInTheBarn :" + randomint);
				
				fireInTheBarn(strawberrywarehouse,carrotwarehouse);
				
			}
			
			if(randomint==2){
				
				System.out.println("epidemicInTheHerd :" + randomint);
				
				epidemicInTheHerd(enclosure, caseOp);
				
			}
			
			if(randomint==3){
				
				System.out.println("Aridity :" + randomint);
				
				Aridity(field, caseOp);
				
			}
		}
		
	}
	
	//Incendie dans la grange
	
	public void fireInTheBarn(StrawberryWarehouse strawberrywarehouse, CarrotWarehouse carrotwarehouse){
		
		// 1 chance sur 2 de supprimer chaque ressources
		
		// pour les fraises
		
		for(int i=0 ; i<strawberrywarehouse.currentSize ; i++){
			Random rn = new Random();
			int randomint = rn.nextInt(2); // 0 or 1
			if (randomint==1){
				strawberrywarehouse.remove(strawberrywarehouse.accesValue(i));
				i--;
			}
		}
		
		// pour les carrotes
		
		for(int i=0 ; i<carrotwarehouse.currentSize ; i++){
			Random rn = new Random();
			int randomint = rn.nextInt(2); // 0 or 1
			if (randomint==1){
				carrotwarehouse.remove(carrotwarehouse.accesValue(i));
				i--;
			}
		}
		
	}
	

	//Epidemie dans le troupeau
	
	public void epidemicInTheHerd(Enclosure enclosure, Case caseOp){
		
		for (int x=1; x<=16; x++) {
			for (int y=1; y<=16; y++) {
				Position p = caseOp.findCase(x,y);
				Random rn = new Random();
				int randomint = rn.nextInt(2); // 0 or 1
				if (randomint==1){
					enclosure.removeAnimal(p);
				}
				
			}
		}
	}
	

	//S�cheresse
	
	public void Aridity(Field field, Case caseOp){
		
		for (int x=1; x<=16; x++) {
			for (int y=1; y<=16; y++) {
				Position p = caseOp.findCase(x,y);
				if (field.accesValue(p) != null) {
					Random rn = new Random();
					int randomint = rn.nextInt(2); // 0 or 1
					if (randomint==1){
						field.removeCrop(p);
					}
				}
			}
		}
	}
	
	

}
