package agrl;

public class ChickenProduct {
	protected int chickenproduct = 0;
	protected int dayspassed;
	protected static int lapsingmax = 4;

	public ChickenProduct(){
		this.dayspassed = 0;
	}
	
	public int getChickenProduct(){
		return this.chickenproduct;
	}
	
	public void addChickenProduct(int amount){
		this.chickenproduct = this.chickenproduct + amount;
	}
	
	public void removeChikenProduct(int amount){
		this.chickenproduct = this.chickenproduct - amount;
	}
	public void daysPasse() { 
		this.dayspassed++;
	}

	public int getDaysPassed() {
		return dayspassed;
	}
	
	public boolean lapsingStatus() { //Check if the item is passe lapsing day
		if (dayspassed > lapsingmax) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean lapsingWarning() { //Allow user to know the item will expire or not
		if (dayspassed >= lapsingmax -3 && dayspassed <= lapsingmax) {
			return true;
		} else {
			return false;
		}
	}
}
