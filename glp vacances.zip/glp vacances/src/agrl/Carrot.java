package agrl;

import java.io.IOException;

public class Carrot extends Vegetable{
	
	protected static int maxhealth = 100;
	protected static int lapsingmax=10;
	
	public Carrot(int healthpoint, int dateofharvest){ 
		super(healthpoint,maxhealth, dateofharvest, lapsingmax);
	}
	
	
	public void isThirsty(){ //Lost point if not add water
		this.setHealthPoint(this.getHealthPoint()-20);
	}
	
	public String toString(){
		return "Age: "+age+" days"+"\n"+ "Can be harvested in: " + super.harvestIn() + " days" +
				"\n"  + super.toString(); 
	}
	
	public int getDate() {
		return dateofharvest;
	}
	


}
