package agrl;

public class BeefWarehouse {
	private Beef[] beefs;
	protected int maxCapacity;
	protected int currentSize = 0;

	public BeefWarehouse(int maxCapacity) {
		this.maxCapacity = maxCapacity;
		beefs = new Beef[maxCapacity];
	}

	public void add(Beef Beef) {
		if (currentSize != beefs.length) {
			beefs[currentSize] = Beef;
			currentSize++;
		}
	}

	public void remove(Beef Beef) {
		int i;
		for (i = 0; i<currentSize; i++) {
			if (beefs[i].equals(Beef)) {
				beefs[i] = null;
				break;
			}
		}
		for (int j = i; i<currentSize -1; i++) {
			beefs[j] = beefs[j + 1];
		}
		if (i != currentSize) {
			currentSize--;
		}
	}

	public void check() {
		for(int i=0; i<currentSize;i++) {
			if(	beefs[i].lapsingStatus()) {
				remove(beefs[i]);
				System.out.println("EXPIRE");
				System.out.println("Beef at posistion " + i + " is removed");
		}
	}
	}
	
	public int warningCheck() { //Check number of all item ready to pass date limit
		int val = 0;
		for(int i=0; i<currentSize;i++) {
			if(	beefs[i].lapsingWarning()) {
				val++;
			}
		}
		return val;
	}

	public Beef accesValue(int search) {
		Beef res = null;
		for(int i=0; i<currentSize;i++) {
			if (i == search) {
				res = beefs[i];
			}
		}
		return res;
	}
	public int getSize() {
		return currentSize;
	}
}
