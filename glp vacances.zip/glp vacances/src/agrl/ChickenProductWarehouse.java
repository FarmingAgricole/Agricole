package agrl;

public class ChickenProductWarehouse {
	private ChickenProduct[] chickenproducts;
	protected int maxCapacity;
	protected int currentSize = 0;

	public ChickenProductWarehouse(int maxCapacity) {
		this.maxCapacity = maxCapacity;
		chickenproducts = new ChickenProduct[maxCapacity];
	}

	public void add(ChickenProduct ChickenProduct) {
		if (currentSize != chickenproducts.length) {
			chickenproducts[currentSize] = ChickenProduct;
			currentSize++;
		}
	}

	public void remove(ChickenProduct ChickenProduct) {
		int i;
		for (i = 0; i<currentSize; i++) {
			if (chickenproducts[i].equals(ChickenProduct)) {
				chickenproducts[i] = null;
				break;
			}
		}
		for (int j = i; i<currentSize -1; i++) {
			chickenproducts[j] = chickenproducts[j + 1];
		}
		if (i != currentSize) {
			currentSize--;
		}
	}

	public void check() {
		for(int i=0; i<currentSize;i++) {
			if(	chickenproducts[i].lapsingStatus()) {
				remove(chickenproducts[i]);
				System.out.println("EXPIRE");
				System.out.println("ChickenProduct at posistion " + i + " is removed");
		}
	}
	}
	
	public int warningCheck() { //Check number of all item ready to pass date limit
		int val = 0;
		for(int i=0; i<currentSize;i++) {
			if(	chickenproducts[i].lapsingWarning()) {
				val++;
			}
		}
		return val;
	}

	public ChickenProduct accesValue(int search) {
		ChickenProduct res = null;
		for(int i=0; i<currentSize;i++) {
			if (i == search) {
				res = chickenproducts[i];
			}
		}
		return res;
	}
	public int getSize() {
		return currentSize;
	}
}
