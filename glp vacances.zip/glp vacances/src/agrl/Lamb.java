package agrl;

public class Lamb {
	protected int lamb = 0;
	protected int dayspassed;
	protected static int lapsingmax = 4;

	public Lamb(){
		this.dayspassed = 0;
	}
	
	public int getLamb(){
		return this.lamb;
	}
	
	public void addLamb(int amount){
		this.lamb = this.lamb + amount;
	}
	
	public void removeChikenProduct(int amount){
		this.lamb = this.lamb - amount;
	}
	public void daysPasse() { 
		this.dayspassed++;
	}

	public int getDaysPassed() {
		return dayspassed;
	}
	
	public boolean lapsingStatus() { //Check if the item is passe lapsing day
		if (dayspassed > lapsingmax) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean lapsingWarning() { //Allow user to know the item will expire or not
		if (dayspassed >= lapsingmax -3 && dayspassed <= lapsingmax) {
			return true;
		} else {
			return false;
		}
	}
}
