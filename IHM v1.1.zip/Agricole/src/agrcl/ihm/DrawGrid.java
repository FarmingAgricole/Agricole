package agrcl.ihm;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class DrawGrid extends JPanel{

	private int scale = ALparameters.SCALE;
	boolean drawglobalgrid = true;

	public DrawGrid(){


	}

	public void paintComponent (Graphics g){
		g.setColor(new Color(0, 102, 34));
		if(drawglobalgrid){
			globalGrid(g);
		}
		cropsGrid(g);
		cowGrid(g);
		pigGrid(g);
		chickenGrid(g);
		sheepGrid(g);
		ressources(g);
		timeInfos(g);
		shop(g);
		endTurn(g);


	}

	public void cropsGrid (Graphics g){

		int lign = ALparameters.cropLign;
		int col = ALparameters.cropCol;

		JPanel field = new JPanel();

		field.setBounds(scale, scale*2, scale*col, scale*lign);
		field.setLayout(new GridLayout(lign,col));
		field.setEnabled(true);


		for (int i = 1;i<=(lign*col);i++){

			JLabel cropsCase = new JLabel(new ImageIcon("CropDirt.png"));
			cropsCase.setBorder(BorderFactory.createLineBorder(Color.GRAY));
			cropsCase.setName(i+"");
			cropsCase.addMouseListener(new CropsListener());
			field.add(cropsCase);

		}

		add(field);
	}

	public void globalGrid (Graphics g){

		int pixel_height = ALparameters.WINDOW_HEIGHT;
		int pixel_width =  ALparameters.WINDOW_WIDTH;

		for (int i = scale; i <= pixel_width; i += scale) {

			Graphics2D g2 = (Graphics2D) g;
			g2.setStroke(new BasicStroke(2));
			g2.drawLine(i, 1, i, pixel_height);

		}

		for (int i = scale; i <= pixel_height; i += scale) {

			Graphics2D g2 = (Graphics2D) g;
			g2.setStroke(new BasicStroke(2));
			g2.drawLine(1, i, pixel_width, i);
		}
	}

	public void cowGrid (Graphics g){

		int col = ALparameters.cowCol;
		int lign = ALparameters.cowLign;
		JPanel cowField = new JPanel();
		cowField.setLayout(new GridLayout(col, lign));
		cowField.setBounds(scale*7, scale*3, scale*lign, scale*col);
		cowField.setEnabled(true);

		for (int i = 1; i<= (col*lign);i++){

			JLabel cowCase = new JLabel(new ImageIcon("enclosure_text.png"));
			cowCase.setBorder(BorderFactory.createLineBorder(Color.GRAY));
			cowCase.addMouseListener(new CowListener());
			cowCase.setName(i+"");
			cowField.add(cowCase);
		}

		add(cowField);

	}

	public void pigGrid (Graphics g){

		int col = ALparameters.pigCol;
		int lign = ALparameters.pigLign;
		JPanel pigField = new JPanel();
		pigField.setLayout(new GridLayout(col, lign));
		pigField.setBounds(scale*7, scale*8, scale*lign, scale*col);
		pigField.setEnabled(true);

		for (int i = 1; i<= (col*lign);i++){

			JLabel pigCase = new JLabel(new ImageIcon("enclosure_text.png"));
			pigCase.setBorder(BorderFactory.createLineBorder(Color.GRAY));
			pigCase.setName(i+"");
			pigField.add(pigCase);
		}

		add(pigField);

	}

	public void chickenGrid (Graphics g){

		int col = ALparameters.chickenCol;
		int lign = ALparameters.chickenLign;
		JPanel chickenField = new JPanel();
		chickenField.setLayout(new GridLayout(col, lign));
		chickenField.setBounds(scale*15, scale*8, scale*lign, scale*col);
		chickenField.setEnabled(true);

		for (int i = 1; i<= (col*lign);i++){

			JLabel chickenCase = new JLabel(new ImageIcon("enclosure_text.png"));
			chickenCase.setBorder(BorderFactory.createLineBorder(Color.GRAY));
			chickenCase.setName(i+"");
			chickenField.add(chickenCase);
		}

		add(chickenField);

	}

	public void sheepGrid (Graphics g){

		int col = ALparameters.sheepCol;
		int lign = ALparameters.sheepLign;
		JPanel sheepField = new JPanel();
		sheepField.setLayout(new GridLayout(col, lign));
		sheepField.setBounds(scale*15, scale*3, scale*lign, scale*col);
		sheepField.setEnabled(true);

		for (int i = 1; i<= (col*lign);i++){

			JLabel sheepCase = new JLabel(new ImageIcon("enclosure_text.png"));
			sheepCase.setBorder(BorderFactory.createLineBorder(Color.GRAY));
			sheepCase.setName(i+"");
			sheepCase.addMouseListener(new SheepListener());
			sheepField.add(sheepCase);
		}

		add(sheepField);

	}

	public void ressources (Graphics g){

		JPanel ressources = new JPanel();
		ressources.setLayout(new GridLayout(1, 4));
		ressources.setBounds(0,0,scale*17,scale);
		ressources.setBackground(Color.gray);
		JLabel gold = new JLabel("Gold: ");
		JLabel milk = new JLabel("Milk: ");
		JLabel wool = new JLabel("Wool: ");
		JLabel meat = new JLabel("Meat: ");
		ressources.add(gold);
		ressources.add(milk);
		ressources.add(wool);
		ressources.add(meat);
		add(ressources);
	}

	public void timeInfos (Graphics g){

		JPanel infos = new JPanel();
		JLabel turn = new JLabel("Turn: ");
		JLabel heure = new JLabel("Time: ");
		infos.setLayout(new GridLayout(2, 1));

		infos.add(turn);
		infos.add(heure);
		infos.setBounds(scale*28, 0, scale*3, scale*2);
		infos.setBackground(Color.gray);
		add(infos);
	}

	public void shop (Graphics g){

		JButton shop = new JButton("Shop");
		shop.setBounds(scale*27, scale*4, scale*4, scale);
		shop.addActionListener(new ShopListener());
		add(shop);
	}

	public void endTurn (Graphics g){

		JButton end = new JButton("Go to bed");
		end.setBounds(scale*28, scale*2, scale*3, scale);
		add(end);

	}


	public class CropsListener extends MouseAdapter {

		public void mouseClicked(MouseEvent me)	{

			JLabel clickedBox =(JLabel)me.getSource(); // get the reference to the box that was clicked 
			JPanel caseInterface = new JPanel();
			JLabel healthInfo = new JLabel("Health: ");
			JLabel shapeInfo = new JLabel("Shape: ");
			JLabel maturityInfo = new JLabel("Maturity: ");
			caseInterface.setLayout(new BorderLayout());

			caseInterface.setBounds(scale*7, scale*13, scale*17, scale*4);
			caseInterface.setBackground(Color.gray);
			caseInterface.setVisible(true);
			caseInterface.add(healthInfo, BorderLayout.NORTH);
			caseInterface.add(shapeInfo,BorderLayout.CENTER);
			caseInterface.add(maturityInfo, BorderLayout.SOUTH);
			add(caseInterface);
			repaint();
			validate();	       	        
		}

		public void mouseEntered (MouseEvent me){

			JLabel clickedBox =(JLabel)me.getSource();
			clickedBox.setBorder(BorderFactory.createLineBorder(Color.WHITE));

		}

		public void mouseExited (MouseEvent me){

			JLabel clickedBox =(JLabel)me.getSource();
			clickedBox.setBorder(BorderFactory.createLineBorder(Color.GRAY));

		}

	}

	public class SheepListener extends MouseAdapter {

		public void mouseClicked(MouseEvent me)	{

			JLabel clickedBox =(JLabel)me.getSource(); // get the reference to the box that was clicked 
			JPanel caseInterface = new JPanel();
			JLabel nameInfo = new JLabel("Name: ");
			JLabel healthInfo = new JLabel("Health: ");
			JLabel shapeInfo = new JLabel("Shape: ");
			caseInterface.setLayout(new BorderLayout());

			caseInterface.setBounds(scale*7, scale*13, scale*17, scale*4);
			caseInterface.setBackground(Color.gray);
			caseInterface.setVisible(true);
			caseInterface.add(nameInfo, BorderLayout.NORTH);
			caseInterface.add(healthInfo,BorderLayout.CENTER);
			caseInterface.add(shapeInfo, BorderLayout.SOUTH);
			add(caseInterface);
			repaint();
			validate();	       	        
		}

		public void mouseEntered (MouseEvent me){

			JLabel clickedBox =(JLabel)me.getSource();
			clickedBox.setBorder(BorderFactory.createLineBorder(Color.WHITE));

		}

		public void mouseExited (MouseEvent me){

			JLabel clickedBox =(JLabel)me.getSource();
			clickedBox.setBorder(BorderFactory.createLineBorder(Color.GRAY));

		}

	}

	public class ShopListener implements ActionListener{

		private int scale = ALparameters.SCALE;

		public void actionPerformed(ActionEvent e) {



		}


	}


}

