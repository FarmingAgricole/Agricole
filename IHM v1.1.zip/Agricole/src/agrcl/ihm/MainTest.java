package agrcl.ihm;

import java.rmi.dgc.DGC;

public class MainTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Interface mainwindow = new Interface();
		
	}

}
