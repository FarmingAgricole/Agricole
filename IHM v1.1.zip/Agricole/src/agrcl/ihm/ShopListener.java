package agrcl.ihm;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class ShopListener implements ActionListener{
	
	private int scale = ALparameters.SCALE;
	
	public ShopListener() {
		
	}
	
	public void actionPerformed(ActionEvent e) {
		
		JFrame shopInterface = new JFrame();
		JPanel shopBoard = new JPanel();
		JButton addCow = new JButton("Buy Cow");	
		JButton addSheep = new JButton("Buy Sheep");
		JButton addChicken = new JButton("Buy Chihcken");
		JButton addPig = new JButton("Buy Pig");
		
		
		shopBoard.setLayout(new GridLayout(3, 2));
		shopBoard.add(addCow);
		shopBoard.add(addSheep);
		shopBoard.add(addPig);
		shopBoard.add(addChicken);
		
		addChicken.addActionListener(new AddObject());
		
		shopInterface.add(shopBoard);
		shopInterface.setSize(new Dimension(ALparameters.WINDOW_WIDTH/2, ALparameters.WINDOW_HEIGHT/2));
		shopInterface.setVisible(true);


	}

	private class AddObject implements ActionListener {


		public void actionPerformed(ActionEvent e) {
			
			
			
		}
		
	}
}
