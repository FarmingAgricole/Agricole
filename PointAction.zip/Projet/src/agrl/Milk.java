package agrl;

public class Milk {
	
	protected int milk = 0;
	protected int dayspassed;
	protected static int lapsingmax = 4;

	public Milk(){
		this.dayspassed = 0;
	}
	
	public int getMilk(){
		return this.milk;
	}
	
	public void addMilk(int amount){
		
		this.milk = this.milk + amount;
		
	}
	
	public void removeMilk(int amount){
		this.milk = this.milk - amount;
	}
	public void daysPasse() { 
		this.dayspassed++;
	}

	public int getDaysPassed() {
		return dayspassed;
	}
	
	public boolean lapsingStatus() { //Check if the item is passe lapsing day
		if (dayspassed > lapsingmax) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean lapsingWarning() { //Allow user to know the item will expire or not
		if (dayspassed >= lapsingmax -3 && dayspassed <= lapsingmax) {
			return true;
		} else {
			return false;
		}
	}
}
