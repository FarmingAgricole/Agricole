package agrl;
import java.awt.*;


public class Shop{
	private RepairVehicle rv = new RepairVehicle();
	private boolean result;

	public Shop(){

	}

	
	public void buyHay(Wallet wallet, Hay hay){ 
		wallet.removeGold(10);
		hay.addHay(1);
	}
	
	//Tractor X1
	public void buyTractorX1(Wallet wallet, Garage garages, Position position){
		if(garages.addMore()) {
			garages.addTractorX1(position);
			wallet.removeGold(1500);
		}
	}

	//Cow
	public void buyCow(Wallet wallet, Enclosure enclosures, Position position){
		enclosures.addAnimal(position,1);
		wallet.removeGold(1600);
	}
	
	public void sellCow(Wallet wallet, Enclosure enclosures, Position position){
		enclosures.removeAnimal(position);
		wallet.addGold(800);
	}
	
	//Poules

	public void buyChicken(Wallet wallet, Enclosure enclosures, Position position){

		enclosures.addAnimal(position,2);
		wallet.removeGold(50);
	}
	
	public void sellChicken(Wallet wallet, Enclosure enclosures, Position position){
		enclosures.removeAnimal(position);
		wallet.addGold(25);
	}

	//Moutons

	public void buySheep(Wallet wallet, Enclosure enclosures, Position position){
		enclosures.addAnimal(position,4);
		wallet.removeGold(150);
	}

	public void sellSheep(Wallet wallet, Enclosure enclosures, Position position){
		enclosures.removeAnimal(position);
		wallet.addGold(75);
	}

	//Pig

	public void buyPig(Wallet wallet, Enclosure enclosures, Position position){
		enclosures.addAnimal(position,3);
		wallet.removeGold(400);
	}
	
	public void sellPig(Wallet wallet, Enclosure enclosures, Position position){
		enclosures.removeAnimal(position);
		wallet.addGold(200);
	}



	public void buyCarrot(Field fields, Wallet wallet, Position p){
		fields.addCrop(p,1);
			wallet.removeGold(10);
		}

	public void sellCarrot(CarrotWarehouse cw, Wallet wallet){
		for (int i=0; i<cw.getSize();i++) {
			//if (cw.accesValue(i).lapsingStatus() == false) {
				cw.remove(cw.accesValue(i));
				wallet.addGold(50);
			}
		}
	
	public void sellStrawberry(StrawberryWarehouse sw, Wallet wallet){
		for (int i=0; i<sw.getSize();i++) {
		//	if (sw.accesValue(i).lapsingStatus() == false) {
				sw.remove(sw.accesValue(i));
				wallet.addGold(300);
			}
		}

	public void buyStrawberry(Field fields, Wallet wallet, Position p){
		fields.addCrop(p,2);
			wallet.removeGold(50);
		}
	
	
	public void buyGrain(Wallet wallet, Grain grain){
		wallet.removeGold(1);
		grain.addGrain(1);
	}

	public void sellMilk(MilkWarehouse mw, Wallet wallet){
		for (int i=0; i<mw.getSize();i++) {	
		mw.remove(mw.accesValue(i));
			wallet.addGold(100);
		}
	}

	public void sellEgg(EggWarehouse ew, Wallet wallet){
		for (int i=0; i<ew.getSize();i++) {	
			ew.remove(ew.accesValue(i));
			wallet.addGold(5);
		}
	}

	public void sellWool(WoolWarehouse ww, Wallet wallet){
		for (int i=0; i<ww.getSize();i++) {		
		ww.remove(ww.accesValue(i));
			wallet.addGold(10);
		}
	}
	
	public boolean purchased() {
		return result;
	}


	public void buyTractorX2(Wallet wallet, Garage garages, Position position){
		if(garages.addMore()) {
			garages.addTractorX2(position);
			wallet.removeGold(3000);
			System.out.println(wallet.getGold());
		}
	}


	public void sellTractor(Wallet wallet, Garage garages, Position position){
		if(garages.getNumberVehicle()==0){
			System.out.println("Tractor not found");
		}
		else {
			if (garages.whichVehicle(position) == 1) {
				System.out.println("Tractor X1 found");
				garages.removeVehicle(position);
				System.out.println("Tractor X1 removed");
				wallet.addGold(750);

			} else if (garages.whichVehicle(position) == 2) {
				System.out.println("Tractor X2 found");
				garages.removeVehicle(position);
				System.out.println("Tractor X2 removed");
				wallet.addGold(1500);
			}
		}
	}

	public void repairTractor(Wallet wallet, Garage garages, Position position){
		if(garages.getNumberVehicle()==0){
			System.out.println("Tractor not found");
		}
		else {
			Vehicle v  = garages.accesValue(position);
			if (garages.whichVehicle(position) == 1) {
				wallet.removeGold(rv.priceFix(v));
				rv.repair(v);
			} else if (garages.whichVehicle(position) == 2) {
				wallet.removeGold(rv.priceFix(v)*2);
				rv.repair(v);
			}
		}

	}
}
