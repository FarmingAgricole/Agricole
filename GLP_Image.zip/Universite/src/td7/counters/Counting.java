package td7.counters;

public interface Counting {
	void increment() throws LimitReachedException;

	void decrement() throws LimitReachedException;

	int getValue();
}
