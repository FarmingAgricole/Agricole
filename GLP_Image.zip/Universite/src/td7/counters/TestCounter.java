package td7.counters;

public class TestCounter {

	public static void main(String[] args) {
		Counting counter = new Counter(0);
		System.out.println(counter.toString());
		for (int i = 1; i <= 10; i++) {
			try {
				counter.increment();
			} catch (LimitReachedException e) {
				
			}
		}
		System.out.println(counter.toString());
		for (int i = 1; i <= 20; i++) {
			try {
				counter.decrement();
			} catch (LimitReachedException e) {
				
			}
		}
		System.out.println(counter.toString());

		Counting boundedCounter = new BoundedCounter(0, 5);
		System.out.println(boundedCounter.toString());
		for (int i = 1; i <= 10; i++) {
			try {
				boundedCounter.increment();
			} catch (LimitReachedException e) {
				
			}
		}
		System.out.println(boundedCounter.toString());

		Counting cyclicCounter = new CyclicCounter(0, 5);
		System.out.println(cyclicCounter.toString());
		for (int i = 1; i <= 10; i++) {
			try {
				cyclicCounter.increment();
			} catch (LimitReachedException e) {		
			}
		}
		System.out.println(cyclicCounter.toString());

		for (int i = 1; i <= 10; i++) {
			try {
				cyclicCounter.decrement();
			} catch (LimitReachedException e) {
				
			}
		}
		System.out.println(cyclicCounter.toString());

	}

}
