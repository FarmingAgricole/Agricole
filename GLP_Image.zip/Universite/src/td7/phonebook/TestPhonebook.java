package td7.phonebook;

import java.util.NoSuchElementException;

public class TestPhonebook {

	public static void main(String[] args) {
		testPhonebookTable();
		testPhonebookArrayList();
		testPhonebookHashMap();
	}

	private static void testPhonebookTable() {
		System.out.println("-- Test phonebook implemented by a table --");
		PhonebookInterface phonebook = new PhonebookTable(50);
		testOperations(phonebook);

	}

	private static void testPhonebookArrayList() {
		System.out.println("-- Test phonebook implemented by an array list --");
		PhonebookInterface phonebook = new PhonebookList();
		testOperations(phonebook);
	}

	private static void testPhonebookHashMap() {
		System.out.println("-- Test phonebook implemented by a hash map --");
		PhonebookInterface phonebook = new PhonebookMap();
		testOperations(phonebook);
	}

	private static void testOperations(PhonebookInterface phonebook) {
		Contact paul = new Contact("Paul", "123456", "paul@gmail.com");
		Contact jean = new Contact("Jean", "234567", "jean@hotmail.com");
		try {
			phonebook.add(paul);
			phonebook.add(jean);

			Contact foundPaul = phonebook.searchByName("Paul");

			System.out.println(foundPaul.toString());

			Contact foundJean = phonebook.searchByNumber("234567");

			System.out.println(foundJean.toString());

			Contact foundJean2 = phonebook.searchByEmail("jean@hotmail.com");

			System.out.println(foundJean2.toString());

			System.out.println("Before removing : " + phonebook.contactCount() + " contact(s).");
		
			phonebook.remove(paul);
	
			System.out.println("After removing : " + phonebook.contactCount() + " contact(s).");
		} catch (ContactAlreadyExistsException caee) {
			System.err.println(caee.getMessage());
		} catch (NoSuchElementException nsee) {
			System.err.println(nsee.getMessage());
		}
	}
}
