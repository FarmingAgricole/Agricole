package td7.phonebook;

import java.util.NoSuchElementException;

public class PhonebookTable implements PhonebookInterface {
	private Contact[] contacts;
	private int currentSize = 0;

	public PhonebookTable(int size) {
		contacts = new Contact[size];
	}

	public void add(Contact contact) throws ContactAlreadyExistsException {
		if (contains(contact)) {
			throw new ContactAlreadyExistsException(contact);
		} else {
			if (currentSize != contacts.length) {
				contacts[currentSize] = contact;
				currentSize++;
			}
		}
	}

	public Contact searchByName(String name) throws NoSuchElementException {
		Contact result = null;
		for (int index = 0; index < currentSize; index++) {
			if (contacts[index].getName().equals(name)) {
				result = contacts[index];
			}
		}
		if (result == null) {
			throw new NoSuchElementException("Contact " + name + " does not exists.");
		} else {
			return result;
		}
	}

	public Contact searchByNumber(String number) throws NoSuchElementException {
		Contact result = null;
		for (int index = 0; index < currentSize; index++) {
			if (contacts[index].getNumber().equals(number)) {
				result = contacts[index];
			}
		}
		if (result == null) {
			throw new NoSuchElementException("Contact " + number + " does not exists.");
		} else {
			return result;
		}
	}

	public Contact searchByEmail(String email) throws NoSuchElementException {
		Contact result = null;
		for (int index = 0; index < currentSize; index++) {
			if (contacts[index].getEmail().equals(email)) {
				result = contacts[index];
			}
		}
		if (result == null) {
			throw new NoSuchElementException("Contact " + email + " does not exists.");
		} else {
			return result;
		}
	}

	@Override
	public void remove(Contact contact) {
		int index;
		// Remove the contact
		for (index = 0; index < currentSize; index++) {
			if (contacts[index].equals(contact)) {
				contacts[index] = null;
				break;
			}
		}

		// Move the next contacts
		for (int newIndex = index; index < currentSize - 1; index++) {
			contacts[newIndex] = contacts[newIndex + 1];
		}

		if (index != currentSize) {
			currentSize--;
		}
	}

	@Override
	public int contactCount() {
		return currentSize;
	}

	@Override
	public boolean contains(Contact contact) {
		Contact result = null;
		for (int index = 0; index < currentSize; index++) {
			if (contacts[index].equals(contact)) {
				result = contact;
			}
		}
		return result != null;
	}
}
