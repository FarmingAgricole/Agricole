package td7.phonebook;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;

/*
 * In this class, we show 3 ways for iterating an array list. 
 * 1) by for loop 2) by iterator 3) by element index
 */
public class PhonebookList implements PhonebookInterface {
	private ArrayList<Contact> contacts = new ArrayList<Contact>();

	@Override
	public void add(Contact contact) throws ContactAlreadyExistsException {
		if (contacts.contains(contact)) {
			throw new ContactAlreadyExistsException(contact);
		} else {
			contacts.add(contact);
		}
	}

	@Override
	public Contact searchByName(String name) throws NoSuchElementException {
		Contact result = null;
		for (Contact contact : contacts) {
			if (contact.getName().equals(name)) {
				result = contact;
			}
		}
		if (result == null) {
			throw new NoSuchElementException("Contact " + name + " does not exists.");
		} else {
			return result;
		}
	}

	@Override
	public Contact searchByNumber(String number) throws NoSuchElementException {
		Contact result = null;
		Iterator<Contact> iterator = contacts.iterator();
		while (iterator.hasNext()) {
			Contact contact = iterator.next();
			if (contact.getNumber().equals(number)) {
				result = contact;
			}
		}
		if (result == null) {
			throw new NoSuchElementException("Contact " + number + " does not exists.");
		} else {
			return result;
		}
	}

	@Override
	public Contact searchByEmail(String email) throws NoSuchElementException {
		Contact result = null;
		for (int index = 0; index < contactCount(); index++) {
			Contact contact = contacts.get(index);
			if (contact.getEmail().equals(email)) {
				result = contact;
			}
		}
		if (result == null) {
			throw new NoSuchElementException("Contact " + email + " does not exists.");
		} else {
			return result;
		}
	}

	@Override
	public void remove(Contact contact) {
		// This works because equals has been redefined (override) in Contact class.
		contacts.remove(contact);
	}

	@Override
	public int contactCount() {
		return contacts.size();
	}

	@Override
	public boolean contains(Contact contact) {
		return contacts.contains(contact);
	}

}
