package td7.phonebook;

import java.util.Collection;
import java.util.HashMap;
import java.util.NoSuchElementException;

public class PhonebookMap implements PhonebookInterface {
	// We choose number as the key of the hash map.
	private HashMap<String, Contact> contacts = new HashMap<String, Contact>();

	@Override
	public void add(Contact contact) throws ContactAlreadyExistsException {
		if (contains(contact)) {
			throw new ContactAlreadyExistsException(contact);
		} else {
			contacts.put(contact.getNumber(), contact);
		}
	}

	@Override
	public Contact searchByName(String name) throws NoSuchElementException {
		Contact result = null;
		Collection<Contact> values = contacts.values();
		for (Contact contact : values) {
			if (contact.getName().equals(name)) {
				result = contact;
			}
		}
		if (result != null) {
			return result;
		} else {
			throw new NoSuchElementException("Contact " + name + " does not exists.");
		}
	}

	@Override
	public Contact searchByNumber(String number) throws NoSuchElementException {
		if (contacts.containsKey(number)) {
			return contacts.get(number);
		} else {
			throw new NoSuchElementException("Contact " + number + " does not exists.");
		}
	}

	@Override
	public Contact searchByEmail(String email) throws NoSuchElementException {
		Contact result = null;
		Collection<Contact> values = contacts.values();
		for (Contact contact : values) {
			if (contact.getEmail().equals(email)) {
				result = contact;
			}
		}
		if (result != null) {
			return result;
		} else {
			throw new NoSuchElementException("Contact " + email + " does not exists.");
		}

	}

	@Override
	public void remove(Contact contact) {
		contacts.remove(contact.getNumber());
	}

	@Override
	public int contactCount() {
		return contacts.size();
	}

	@Override
	public boolean contains(Contact contact) {
		return contacts.containsValue(contact);
	}

}
