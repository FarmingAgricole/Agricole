package td7.point;

public class TestPoint {

	public static void main(String[] args) {
		Point point = new Point(1, 1);

		try {
			point.setX(600);
		} catch (IllegalArgumentException e) {
			System.err.println(e.getMessage());
		}

		try {
			point.setY(-700);
		} catch (IllegalArgumentException e) {
			System.err.println(e.getMessage());
		}
	}

}
