package ProjetGenie;

public class Animal {
	private int weight, water, dayspasse, rate, age;
	private double health, lifepoint;
	private String type, status, name;
	
	public Animal (double lifepoint, String name) {
		this.age= 0;
		//this.rate= rate;
		this.dayspasse = 0;
		//this.type="ABC";
		this.name = name;
		this.lifepoint=lifepoint;
		health = lifepoint;
	}
	
	
	public String report() {
		updateStatus();
		return "Name: " + name + ", Helath status: " + health + ", Age: " + age + ", Days passing: " 
				+ dayspasse + ", Life point: " + lifepoint;
	}
	
	public void updateStatus() {
		// Pas encore finir (barre de vie en fonction d'age)
		//if (age % 10 == 0 && age <= 30) {
			//lifepoint = lifepoint + lifepoint*0.25;
		//}
		double point = (health/lifepoint)*100;
		if (point == 0) {
			status = "Cet animal est mort";
		} else if (point > 0 && point <=25) {
			status = "Très Mauvaise État";
		} else if (point > 25 && point <=50) {
			status = "Mauvaise État";
		} else if (point > 50 && point <=75) {
			status = "Cet animal n'a pas la forme";
		}  else if (point > 75 && point <= 100) {
			status = "Normal";
		}
		System.out.println(status);
	}
	
	public void grow() {
		if (dayspasse > 0) {
			health = health - (lifepoint*0.15);
		}
	dayspasse = dayspasse + 1;
	age = age + 1;
	}
	
	public void autogrow(int days) {
		for (int i= 0; i< days; i++) {
			grow();
		}
	}
	 
	public void feed() {
		health = health + (lifepoint*0.15);
		System.out.println("Animal feeded !!!");
	}
	
	public static void main(String[] args) {
		Animal a1 = new Animal(750, "Cow");
		a1.grow();
		System.out.println(a1.report());
		a1.autogrow(2);
		System.out.println(a1.report());
		a1.feed();
		System.out.println(a1.report());
	}
}
