package ProjetGenie;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Set;

import java.util.Iterator;


import javax.swing.JButton;

public class TESTABC {
    HashMap<String, JButton> elements = new HashMap<String, JButton>();
    
    public TESTABC() {
    	
    }
    
  public void addElement() {
	  String ele;
	  String line;
		String []tab;
		try{
		BufferedReader br =new BufferedReader(new FileReader("/Users/hongphucvu/Desktop/ElementsTest.txt"));
		while((line=br.readLine()) !=null){
				tab=line.split(";");
			     ele=tab[1];
			     elements.put(ele, new JButton(ele));
			     System.out.println(ele);
			}
		br.close();
		}catch(Exception e){
			e.getMessage();
		}	
		} 
  
  public void showKey() {
	  Set set = elements.keySet();

	    Iterator iter = set.iterator();

	    while (iter.hasNext()) {
	      System.out.println(iter.next());
	    }

  }


public static void main(String[] args) {
TESTABC t = new TESTABC();
	t.addElement();
t.showKey();
}
}