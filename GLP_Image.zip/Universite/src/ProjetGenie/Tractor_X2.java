package ProjetGenie;

public class Tractor_X2 extends Vehicle {
	
	public Tractor_X2(String name, double harvestGaintMax) {
		super(name, harvestGaintMax);
	}
	
	public void harvestStatus() {
		super.harvestStatus();
	}
	
	public void setHavest(int gaint) {
		super.setHarvest(gaint);
	}
	
	public String toString() {
		return super.toString();
	}

}
