package ProjetGenie;

public class CarrotsWarehouse {
protected int maxCapacity;
protected int currentPro;

public CarrotsWarehouse(int maxCapacity, int currentPro) {
	this.maxCapacity = maxCapacity;
	this.currentPro = currentPro;
}


}
