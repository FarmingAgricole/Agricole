package ProjetGenie;

public class Lapsing {
protected int expireDate;
protected int datePasse;

public Lapsing(int expireDate, int datePasse) {
	this.expireDate = expireDate;
	this.datePasse = datePasse;
}

public boolean lapsingStatus() {
	boolean res;
	if (datePasse >= expireDate) {
		res = true;
	} else {
		res = false;
	}
	return res;
}

public void warning() {
	if(datePasse < expireDate) {
	if (datePasse >= (expireDate - 5)) {
		System.out.println("ALERT!!!" + "Expire in " + (expireDate - datePasse)
				+ " days");
		System.out.println("Please haverst it soon or it will be go off");
	} else if (datePasse >= ((expireDate*2)/3)) {
		System.out.println("Expire very soon");
		System.out.println("It will be expire in " + (expireDate - datePasse)
				+ " days");
		} else {
			System.out.println("Good conidition");
			System.out.println("It will be expire in " + (expireDate - datePasse)
					+ " days");
		}
	}
}
public int getDatePasse() {
	return datePasse;
}
}
