package ProjetGenie;

public class Warehouse extends Lapsing {
	protected int maxCapacity;
	public Warehouse(int expireDate, int maxCapacity) {
		super(expireDate);
		this.maxCapacity = maxCapacity;
	}

	

}
