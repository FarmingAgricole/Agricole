package ProjetGenie;

public class Test {
private double lifePoint;
private String status;

public String updateStatus() {
if (lifePoint == 0 ) {
	status = "Mort";
} else if (lifePoint > 0 && lifePoint <= 1 ) {
	status = "Mal";
} else if (lifePoint > 1 && lifePoint <= 2 ) {
	status = "Normal";
} else if (lifePoint > 2 && lifePoint <= 3 ) {
	status = "Bien";
}else if (lifePoint > 3 && lifePoint <= 4 ) {
	status = "Tres bien";
}
return status;
}

public Test(double lifePoint) {
	this.lifePoint = lifePoint;
}

public String getStatus() {
	return status;
}

public double perdPoint(double date) {
if (date >= 1 && date <= 5) {
	for (int i =1; i<=date; i++) {
lifePoint = lifePoint - 0.8;
}
}
return lifePoint;
}

public double getPoint() {
	return lifePoint;
}
public static void main(String[] args) {
	Test t = new Test(4);
	t.perdPoint(5);
	t.updateStatus();
	System.out.println(t.getPoint());
System.out.println(t.getStatus());
}

}
