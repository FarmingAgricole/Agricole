package ProjetGenie;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

import javax.imageio.ImageIO;
import javax.swing.*;

public class JustForTest {
	Object[] possibilities = {"ham", "spam", "yam"};
	
	
}
