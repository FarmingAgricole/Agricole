package ProjetGenie;

import java.util.HashMap;
import java.util.Collection;
import java.util.Iterator;

public class Field {
	private Position [] p = new Position[1000];
private HashMap<Position, Crop> crops = new HashMap<Position, Crop>();
private HashMap<Position, Animal> animals = new HashMap<Position, Animal>();
private int max_crops, max_animals;

public Field (int max_crops, int max_animals) {
	this.max_crops = max_crops;
	this.max_animals = max_animals;
}

public boolean plant_crop(Position po, Crop crop) {
	boolean res = true;
//String key;
	if (crops.size() < max_crops) {
		crops.put(po, crop);
		res = true;
	} else {
		res = false;
	}
	return res;
}

public boolean add_animals(Position po, Animal animal) {
	boolean res = true;
	if (animals.size() < max_animals) {
		animals.put(po, animal);
		res = true;
	} else {
		res = false;
	}
	return res;
}

public void harvest_crop(Position po){
	crops.remove(po);
}

public void remove_crop(int num){
	animals.remove(p[num]);
}

public String toString() {
	Iterator iterator = crops.keySet().iterator();
	Iterator iterator1 = animals.keySet().iterator();
	while (iterator.hasNext()) {
		   Position key = (Position) iterator.next();
		   Crop value = crops.get(key);
		   System.out.println("Position:" + key.toString() + " Report: " + value.report());
	}
	while (iterator1.hasNext()) {
		   Position key = (Position) iterator1.next();
		   Animal value = animals.get(key);
		   System.out.println("Position:" + key.toString() + " Report: " + value.report());
	}
	return null;
}

public static void main(String[] args) {
	Field fi = new Field(4,3);
	Crop c = new Crop(4,3);
	c.grow(8,8);
	Crop c1 = new Crop(4,2);
	c1.grow(8,8);
	Crop c2 = new Crop(4,1);
	c2.grow(8,8);
	Position p = new Position(1,2);
	Position p1 = new Position(1,3);
	Position p2 = new Position(1,4);
	
	Position p3 = new Position(2,2);
	Position p4 = new Position(2,3);
    Animal a = new Animal(250,"mouton");
    a.autogrow(2);
    Animal a1 = new Animal(100,"vache");
    a1.autogrow(2);
    //Animal a2 = new Animal(3,"cochon");
    //a2.grow(8,8);
    
	fi.plant_crop(p,c);
	fi.plant_crop(p1,c1);
	fi.plant_crop(p2,c2);
	
	fi.harvest_crop(p1);
	
	
	fi.add_animals(p3,a);
	fi.add_animals(p4,a1);
	//fi.add_animals(p5,a2);
	
	fi.toString();	
	}	
}
