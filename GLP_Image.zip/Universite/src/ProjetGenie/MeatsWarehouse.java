package ProjetGenie;
import java.io.IOException;
import java.util.ArrayList;

public class MeatsWarehouse{
	private Meat[] meats;
	protected int maxCapacity;
	protected int currentSize = 0;

	public MeatsWarehouse(int maxCapacity) {
		this.maxCapacity = maxCapacity;
		meats = new Meat[maxCapacity];
	}

	public void add(Meat meat) {
		if (currentSize != meats.length) {
			meats[currentSize] = meat;
			currentSize++;
		}
	}

	public void remove(Meat meat) {
		int i;
		for (i = 0; i<currentSize; i++) {
			if (meats[i].equals(meat)) {
				meats[i] = null;
				break;
			}
		}
		for (int j = i; i<currentSize -1; i++) {
			meats[i] = meats[i + 1];
		}
		if (i != currentSize) {
			currentSize--;
		}
	}



	public void check() {
		for(int i=0; i<currentSize;i++) {
			meats[i].warning();
			if(	meats[i].getStatus()) {
				remove(meats[i]);
				System.out.println("EXPIRE");
				System.out.println("Meat at posistion " + i + " is removed");
			}
		}
	}

	public static void main(String[] args) throws IOException {
		MeatsWarehouse mw = new MeatsWarehouse(100);
		Meat m1 = new Meat(30, 10);
		Meat m2 = new Meat(30, 7);
		Meat m3 = new Meat(30, 30);
		mw.add(m1);
		mw.add(m2);
		mw.add(m3);
		mw.check();
		System.out.println("---------");
		mw.check();
	}

}