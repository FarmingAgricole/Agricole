package ProjetGenie;

public class Shop {
	private Garage garages = new Garage();
	private RepairVehicle rv = new RepairVehicle();
	private boolean result;
	public Shop(){

	}

	public boolean purchased() {
		return result;
	}

	public void buyTractorX1(Wallet wallet, Garage garages, Position position){
		if (wallet.getGold()<1500){
			System.out.println("Not enough money to buy this item");
			result = false;
		} 
		else if(garages.addMore()) {
			garages.addTractorX1(position);
			if (garages.added()) {
				wallet.removeGold(1500);
				System.out.println(wallet.getGold());
				result = true;
			} else {
				result = false;
			}
		} else {
			result = false;
		}
	}


	public void buyTractorX2(Wallet wallet, Garage garages, Position position){
		if (wallet.getGold()<3000){
			System.out.println("Not enough money to buy this item");
			result = false;
		} 
		else if(garages.addMore()) {
			garages.addTractorX2(position);
			if (garages.added()) {
				wallet.removeGold(3000);
				System.out.println(wallet.getGold());
				result = true;
			} else {
				result = false;
			}
		} else {
			result = false;
		}
	}


	public void sellTractor(Wallet wallet, Garage garages, Position position){
		if(garages.getNumberVehicle()==0){
			System.out.println("Tractor not found");
		}
		else {
			if (garages.whichVehicle(position) == 1) {
				System.out.println("Tractor X1 found");
				garages.removeVehicle(position);
				System.out.println("Tractor X1 removed");
				wallet.addGold(750);

			} else if (garages.whichVehicle(position) == 2) {
				System.out.println("Tractor X2 found");
				garages.removeVehicle(position);
				System.out.println("Tractor X2 removed");
				wallet.addGold(1500);
			}
		}
	}
	
	public void repairTractor(Wallet wallet, Garage garages, Position position){
		if(garages.getNumberVehicle()==0){
			System.out.println("Tractor not found");
		}
		else {
			Vehicle v  = garages.accesValue(position);
			if (garages.whichVehicle(position) == 1) {
				wallet.removeGold(rv.priceFix(v));
				rv.repair(v);
			} else if (garages.whichVehicle(position) == 2) {
				wallet.removeGold(rv.priceFix(v)*2);
				rv.repair(v);
			}
		}
	}
}      