package ProjetGenie;

//public class Cow extends Animal {
	//private double lifepoint;
	
	//public Cow(String food, int rate, double health, String name, double lifepoint) {
		this.lifepoint=lifepoint;
	//}

	//public void updateStatus() {
	//}
	
	
//}
