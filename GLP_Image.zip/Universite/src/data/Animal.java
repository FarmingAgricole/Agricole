
package data;

public class Animal {
	
	int age;
	//reprendre ici
	

}