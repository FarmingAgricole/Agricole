package tree.data;

public abstract class ArithmeticOperation implements Tree {
	private Tree leftOperand;
	private Tree rightOperand;

	public ArithmeticOperation(Tree leftOperand, Tree rightOperand) {
		this.leftOperand = leftOperand;
		this.rightOperand = rightOperand;
	}

	@Override
	public Tree getLeftOperand() {
		return leftOperand;
	}

	@Override
	public Tree getRightOperand() {
		return rightOperand;
	}

	public void setLeftOperand(Tree leftOperand) {
		this.leftOperand = leftOperand;
	}

	public void setRightOperand(Tree rightOperand) {
		this.rightOperand = rightOperand;
	}

}
