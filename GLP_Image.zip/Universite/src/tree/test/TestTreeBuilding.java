package tree.test;

import tree.core.CalculationVisitor;
import tree.core.HeigtVisitor;
import tree.core.NodeCountVisitor;
import tree.core.TreeBuilder;
import tree.core.TreeVisitor;
import tree.data.Tree;

/**
 * This is a non automated test.
 */
public class TestTreeBuilding {

	public static void main(String[] args) {
		TreeBuilder builder = new TreeBuilder("src/tree/input.txt");
		Tree tree = builder.buildTree();
		TreeVisitor<Integer> visitor = new CalculationVisitor();
		System.out.println(tree.toString() + "=" + tree.accept(visitor));
		HeigtVisitor heightVisitor = new HeigtVisitor();
		tree.accept(heightVisitor);
		System.out.println("Tree height : " + heightVisitor.getHeight());
		NodeCountVisitor nodeCountVisitor = new NodeCountVisitor( );
		System.out.println( "Node count : " + tree.accept( nodeCountVisitor ));
		
		
	}
}
