package tree.test;

import org.junit.runners.Suite;
import org.junit.runner.RunWith;

@RunWith(Suite.class)
@Suite.SuiteClasses({TestTreeVisitor.class})
public class TreeTestSuite {

}
