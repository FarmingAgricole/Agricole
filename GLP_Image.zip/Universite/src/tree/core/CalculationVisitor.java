package tree.core;

import tree.data.Addition;
import tree.data.Constant;
import tree.data.Multiplication;
import tree.data.Subtraction;
import tree.data.Variable;

/**
 * @author Tianxiao.Liu@u-cergy.fr
 **/
public class CalculationVisitor implements TreeVisitor<Integer> {

	@Override
	public Integer visit(Constant node) {
		return node.getValue();
	}

	@Override
	public Integer visit(Variable node) {
		VariableRepository variableRepository = VariableRepository.getInstance();
		return variableRepository.search(node);
	}

	@Override
	public Integer visit(Addition node) {
		Integer leftResult = node.getLeftOperand().accept(this);
		Integer rightResult = node.getRightOperand().accept(this);
		return leftResult + rightResult;
	}

	@Override
	public Integer visit(Subtraction node) {
		Integer leftResult = node.getLeftOperand().accept(this);
		Integer rightResult = node.getRightOperand().accept(this);
		return leftResult - rightResult;
	}

	@Override
	public Integer visit(Multiplication node) {
		Integer leftResult = node.getLeftOperand().accept(this);
		Integer rightResult = node.getRightOperand().accept(this);
		return leftResult * rightResult;
	}

}
