package tree.core;

import tree.data.Addition;
import tree.data.Constant;
import tree.data.Multiplication;
import tree.data.Subtraction;
import tree.data.Variable;

/**
 * @author Tianxiao.Liu@u-cergy.fr
 **/
public interface TreeVisitor<T> {

	T visit(Constant node);

	T visit(Variable node);

	T visit(Addition node);

	T visit(Subtraction node);

	T visit(Multiplication node);

}