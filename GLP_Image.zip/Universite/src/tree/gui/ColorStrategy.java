package tree.gui;

import java.awt.Graphics;

import tree.data.Addition;
import tree.data.Constant;
import tree.data.Multiplication;
import tree.data.Subtraction;
import tree.data.Variable;

public interface ColorStrategy {

	void setColor(Graphics graphics, Constant node);

	void setColor(Graphics graphics, Variable node);

	void setColor(Graphics graphics, Addition node);

	void setColor(Graphics graphics, Subtraction node);

	void setColor(Graphics graphics, Multiplication node);
	
	void setLineColor(Graphics graphics);

}
