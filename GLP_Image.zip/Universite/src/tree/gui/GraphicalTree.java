package tree.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;

import org.jfree.chart.ChartPanel;

import tree.core.TreeBuilder;
import tree.data.Tree;
import tree.instrument.ChartManager;
import tree.instrument.InstrumentVisitor;

/**
 * @author Tianxiao.Liu@u-cergy.fr
 */
public class GraphicalTree extends JFrame {

	private static final long serialVersionUID = 5193610496520599151L;
	private JPanel treePanel;
	private JPanel statsPanel = new JPanel();
	private JPanel typeCountPie;
	private JPanel heightEvolutionChart;
	
	private ChartManager chartManager = new ChartManager();

	public GraphicalTree() throws IllegalArgumentException {
		super("Graphical Tree Demo");

		TreeBuilder builder = new TreeBuilder("src/tree/input.txt");
		Tree tree = builder.buildTree();
		
		InstrumentVisitor instrumentVisitor = new InstrumentVisitor(chartManager);
		tree.accept(instrumentVisitor);
		
		treePanel = new TreePanel(tree);

		globalLayout();
	}

	private void globalLayout() {
		getContentPane().setPreferredSize(new Dimension(GTParameters.WINDOW_WIDTH, GTParameters.WINDOW_HEIGHT));
		treePanel.setBackground(Color.WHITE);

		statsPanel.setLayout(new GridLayout(1, 2));

		typeCountPie = new ChartPanel(chartManager.getTypeCountPie());
		heightEvolutionChart = new ChartPanel(chartManager.getHeightEvolutionChart());
		
		statsPanel.add(typeCountPie);
		statsPanel.add(heightEvolutionChart);

		getContentPane().setLayout(new GridLayout(2, 1));
		getContentPane().add(treePanel);
		getContentPane().add(statsPanel);

		setVisible(true);
		pack();
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
	}

	public static void main(String[] args) {
		try {
			new GraphicalTree();
		} catch (IllegalArgumentException e) {
			System.err.println(e.getMessage());
		}
	}

}
