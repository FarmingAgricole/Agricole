package tree.instrument;

import java.util.ArrayList;
import java.util.HashMap;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class ChartManager {
	private HashMap<Character, Integer> nodeTypeCount = new HashMap<Character, Integer>();
	private ArrayList<Integer> heights = new ArrayList<Integer>();

	public ChartManager() {
		nodeTypeCount.put('c', 0);
		nodeTypeCount.put('v', 0);
		nodeTypeCount.put('a', 0);
		nodeTypeCount.put('s', 0);
		nodeTypeCount.put('m', 0);
	}

	public void countType(char type) {
		int count = nodeTypeCount.get(type);
		nodeTypeCount.put(type, count + 1);
	}

	public void registerHeightByStep(int height) {
		heights.add(height);
	}

	public JFreeChart getTypeCountPie() {
		DefaultPieDataset dataset = new DefaultPieDataset();
		dataset.setValue("Constant", nodeTypeCount.get('c'));
		dataset.setValue("Variable", nodeTypeCount.get('v'));
		dataset.setValue("Addition", nodeTypeCount.get('a'));
		dataset.setValue("Subtraction", nodeTypeCount.get('s'));
		dataset.setValue("Multiplication", nodeTypeCount.get('m'));

		return ChartFactory.createPieChart("", dataset, true, true, false);
	}
	
	public JFreeChart getHeightEvolutionChart() {
		XYSeries serie = new XYSeries("Height Evolution");
		for (int index = 0; index < heights.size(); index++) {
			serie.add(index, heights.get(index));
		}

		XYSeriesCollection dataset = new XYSeriesCollection();
		dataset.addSeries(serie);
		
		return ChartFactory.createXYLineChart("", "Visit step", "Height", dataset, PlotOrientation.VERTICAL, true, true, false);
		
	}

}
