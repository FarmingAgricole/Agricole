/* package agrl;

import java.util.ArrayList;

public class CarrotsPlanted {
	
	ArrayList<Carrot> carrots = new ArrayList<Carrot>();
	protected int numberofcarrot=0;
	
	public CarrotsPlanted(){
		
	}
	
	public void addCarrot(Carrot carrot){
		carrots.add(carrot);
		numberofcarrot++;
	}
	
	public void supCarrot(int number){
		Carrot carrotsup = carrots.get(number); // carrotte qui va etre supprim�e
		carrots.remove(carrotsup);
		numberofcarrot--;
	}
	
	public int size(){
		return carrots.size();
	}
	
	public Carrot get(int number){
		return carrots.get(number);
	}

}*/
