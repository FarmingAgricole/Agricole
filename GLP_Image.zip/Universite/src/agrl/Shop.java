package agrl;

public class Shop {
	private Garage garages = new Garage();
	private Enclosure enclosures = new Enclosure();
	private RepairVehicle rv = new RepairVehicle();
	private boolean result;

	public Shop(){

	}

	//Tractor X1
	public void buyTractorX1(Wallet wallet, Garage garages, Position position){
		if(garages.addMore()) {
			garages.addTractorX1(position);
			wallet.removeGold(1500);
		}
	}

	//Cow
	public void buyCow(Wallet wallet, Enclosure enclosures, Position position){
		enclosures.addAnimal(position,1);
		wallet.removeGold(500);
	}
	
	/*public void buyAndFeedCows(Wallet wallet, EnclosureCow enclos){
		if (wallet.getGold()<(10*enclos.getNumberOfCows())){
			//message non
		}

		else{
			wallet.removeGold(10*enclos.getNumberOfCows());
			enclos.feedEveryCows();
		}

	}*/

	/*public void feedCows(Hay hay, EnclosureCow enclos){
		if (hay.getHay()<enclos.getNumberOfCows()){
		}
		else{
			enclos.feedEveryCows();
			hay.removeHay(enclos.getNumberOfCows());
		}
	}*/

	//Poules

	public void buyChicken(Wallet wallet, Enclosure enclosures, Position position){

		enclosures.addAnimal(position,2);
		wallet.removeGold(500);
	}


	//Moutons

	public void buySheep(Wallet wallet, Enclosure enclosures, Position position){
		enclosures.addAnimal(position,4);
		wallet.removeGold(500);
	}



	//Pig

	public void buyPig(Wallet wallet, Enclosure enclosures, Position position){
		enclosures.addAnimal(position,3);
		wallet.removeGold(500);
	}


	/*public void feedPigs(Grain grain, EnclosurePig enclos){
		if (grain.getGrain()<enclos.getNumberOfPigs()){

		}
		else{
			enclos.feedEveryPigs();
			grain.removeGrain(enclos.getNumberOfPigs());
		}
	}*/


	public void buyHay(Wallet wallet, Hay hay){
			wallet.removeGold(10);
			hay.addHay(1);
		}
	
	public void buyGrain(Wallet wallet, Grain grain){
		wallet.removeGold(10);
		grain.addGrain(1);
	}

	public void sellMilk(Milk milk, Wallet wallet){
			milk.removeMilk(1);
			wallet.addGold(50);
		}

	public void sellEgg(Egg egg, Wallet wallet){

			egg.removeEgg(1);
			wallet.addGold(50);
		}

	public void sellWool(Wool wool, Wallet wallet){
			wool.removeWool(1);
			wallet.addGold(50);
		}

	public boolean purchased() {
		return result;
	}


	public void buyTractorX2(Wallet wallet, Garage garages, Position position){
		if(garages.addMore()) {
			garages.addTractorX2(position);
			wallet.removeGold(3000);
			System.out.println(wallet.getGold());
		}
	}


	public void sellTractor(Wallet wallet, Garage garages, Position position){
		if(garages.getNumberVehicle()==0){
			System.out.println("Tractor not found");
		}
		else {
			if (garages.whichVehicle(position) == 1) {
				System.out.println("Tractor X1 found");
				garages.removeVehicle(position);
				System.out.println("Tractor X1 removed");
				wallet.addGold(750);

			} else if (garages.whichVehicle(position) == 2) {
				System.out.println("Tractor X2 found");
				garages.removeVehicle(position);
				System.out.println("Tractor X2 removed");
				wallet.addGold(1500);
			}
		}
	}

	public void repairTractor(Wallet wallet, Garage garages, Position position){
		if(garages.getNumberVehicle()==0){
			System.out.println("Tractor not found");
		}
		else {
			Vehicle v  = garages.accesValue(position);
			if (garages.whichVehicle(position) == 1) {
				wallet.removeGold(rv.priceFix(v));
				rv.repair(v);
			} else if (garages.whichVehicle(position) == 2) {
				wallet.removeGold(rv.priceFix(v)*2);
				rv.repair(v);
			}
		}

	}
}
