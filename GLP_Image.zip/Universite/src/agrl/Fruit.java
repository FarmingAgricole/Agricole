package agrl;

public abstract class Fruit extends Crop{
	
	public Fruit(){
		super();
	}
	
	public Fruit(int healthpoint, int maxhealth, int age, int dateofharvest){
		super(healthpoint, maxhealth, age, dateofharvest);
	}
	
	//public Fruit(int healthpoint, int maxhealth, int lapsingmax){
		//super(healthpoint, maxhealth, lapsingmax);
	//}

}
