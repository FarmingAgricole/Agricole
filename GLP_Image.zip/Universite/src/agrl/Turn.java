package agrl;

public class Turn {
	
	int maxTurn;
	int Turn;
	
	
	public Turn(){
		
	}
	
	public void nextTurn(EnclosureCow enclos, Milk milk){
		this.Turn++;
		//turnOfCows(enclos, milk);
	}
	
	//Tour des vaches
	
	public void turnAnimal(Enclosure enclos,Case caseOp, Milk milk, Egg egg, Wool wool){
		for (int x=1; x<=16; x++) {
			for (int y=1; y<=16; y++) {
				Position p = caseOp.findCase(x,y);
				if(enclos.whichAnimal(p) == 1) {
				if (enclos.accesValue(p).getFed()) {
					milk.addMilk(1);
					enclos.accesValue(p).starve();
				} else {
					enclos.accesValue(p).isStarving();
					if (enclos.accesValue(p).getHealthPoint()<=0) {
						enclos.removeAnimal(p);
					}
				}
			} else if (enclos.whichAnimal(p) == 2){
				if (enclos.accesValue(p).getFed()) {
					egg.addEgg(1);
					enclos.accesValue(p).starve();
				} else {
					enclos.accesValue(p).isStarving();
					if (enclos.accesValue(p).getHealthPoint()<=0) {
						enclos.removeAnimal(p);
					}
				}
			} else if (enclos.whichAnimal(p) == 3) { // ADD MEAT!!!!!!!!!!
				if (enclos.accesValue(p).getFed()) {
				//wool.add(1);
					enclos.accesValue(p).starve();
				} else {
					enclos.accesValue(p).isStarving();
					if (enclos.accesValue(p).getHealthPoint()<=0) {
						enclos.removeAnimal(p);
					}
				}
			}else if (enclos.whichAnimal(p) == 4) {
				if (enclos.accesValue(p).getFed()) {
					wool.addWool(1);
					enclos.accesValue(p).starve();
				} else {
					enclos.accesValue(p).isStarving();
					if (enclos.accesValue(p).getHealthPoint()<=0) {
						enclos.removeAnimal(p);
					}
				}
			}
			}
		}
	}
	
	//Tour des poules
	
	public void turnOfChickens(EnclosureChicken enclos, Egg egg){
		for(int i=0;i<enclos.size();i++){
			if ((enclos.get(i)).getFed()){
				egg.addEgg(1);
				(enclos.get(i)).starve();
			}
			else{
				(enclos.get(i)).isStarving();
				if ((enclos.get(i)).getHealthPoint()<=0){
					enclos.supChicken(i);
				}
				
			}
		}
	}
	
	//Tour des moutons
	
	public void turnOfSheeps(EnclosureSheep enclos, Wool wool){
		for(int i=0;i<enclos.size();i++){
			if ((enclos.get(i)).getFed()){
				wool.addWool(1);
				(enclos.get(i)).starve();
			}
			else{
				(enclos.get(i)).isStarving();
				if ((enclos.get(i)).getHealthPoint()<=0){
					enclos.supSheep(i);
				}
				
			}
		}
	}
	
	//Tour des cochons
	
	public void turnOfPigs(EnclosurePig enclos){
		for(int i=0;i<enclos.size();i++){
			if ((enclos.get(i)).getFed()){ // si les cochons ont été nourris
				(enclos.get(i)).starve(); // a présent ils ont de l'apétits
			}
			else{
				(enclos.get(i)).isStarving(); // si les cochons ont faim, il perdent de la vie
				if ((enclos.get(i)).getHealthPoint()<=0){ // si ils ont <= 0HP ils meurent
					enclos.supPig(i);
				}
				
			}
		}
	}
	
	
	public void turnCrops(Field field, Case caseOp) {
		for (int x=1; x<=16; x++) {
			for (int y=1; y<=16; y++) {
				Position p = caseOp.findCase(x,y);
				if (field.accesValue(p) != null) {
					field.accesValue(p).getOlder();
					if(field.accesValue(p).getWater()) {
						field.accesValue(p).dry();
					} else {
						field.accesValue(p).isThirsty();
						if(field.accesValue(p).getHealthPoint()<=0) {
							field.removeCrop(p);
						}
					}
			}
		}
		}
	}

	
	public int getTurn() {
		return this.Turn;
	}
	
	public void goTurn(){
		this.Turn++;
	}
	

}
