package agrl;

public abstract class Crop extends Shape{
	
	protected boolean water = false;
	protected int maturity;
	protected int lapsingmax;
	protected int age;
	protected int dateofharvest;
	
	public Crop(){
		super();
	}
	
	public Crop(int healthpoint, int maxhealth, int age, int dateofharvest){ /////add age
		super(healthpoint, maxhealth);
		this.age = age;
		this.dateofharvest = dateofharvest;
		
	}
	
	//public Crop(int healthpoint, int maxhealth, int lapsingmax){
		//super(healthpoint, maxhealth);
		//this.lapsingmax=lapsingmax;
	//}
	
	public abstract void isThirsty(); //abstrait car le comportement sera différent selon le type de culture
	
	public void water(){
		this.water=true;
	}
	
	public void dry(){
		this.water=false;
	}
	
	public boolean getWater(){
		return this.water;
	}
	
	public void getOlder() {
		this.age++;
	}

	public boolean isHarvested() {
		boolean res;
		if (age >= dateofharvest) {
			res = true;
		} else {
			res = false;
	}	
		return res;
	}
	
	public void warning() {
		if(age < lapsingmax) {
		if (age >= (lapsingmax - 5)) {
			System.out.println("ALERT!!!" + "Expire in " + (lapsingmax - age)
					+ " days");
			System.out.println("Please haverst it soon or it will be go off");
		} else if (age >= ((lapsingmax*2)/3)) {
			System.out.println("Expire very soon");
			System.out.println("It will be expire in " + (lapsingmax - age)
					+ " days");
			} else {
				System.out.println("Good conidition");
				System.out.println("It will be expire in " + (lapsingmax - age)
						+ " days");
			}
		}
	}

}
