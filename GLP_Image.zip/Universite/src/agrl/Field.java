package agrl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;

public class Field {
	private HashMap<Position, Crop> crops = new HashMap<Position, Crop>();

public Field() {
	
}

public void addCrop(Position position, int choice) {
	if (choice == 1) {
	crops.put(position, new Carrot(70,2));
	}
	else if (choice ==2) {
		crops.put(position, new Strawberry(70,2));
	}
}

public void removeCrop(Position position) {
	crops.remove(position);
}

public int whichCrop(Position position) {
	int res = 0;
	Crop c = accesValue(position);
	if(c == null) {
		res = 0;
	} else if (c instanceof Carrot ) {
		res = 3;
	} else if (c instanceof Strawberry) {
		res = 4;
	}
	return res;
}

public String updateStatus(Position position) {
	Crop c = accesValue(position);
	return c.toString();
}

public int getSize() {
	return crops.size();
}

public Crop accesValue(Position position) {
	Crop c = (Crop)crops.get(position);
	return c;
}

/*public static void main(String[] args) throws IOException {
	Field fields = new Field();
	fields.addCrop(1,1);
	System.out.println(fields.accesValue(1).toString());
	fields.accesValue(1).getOlder();
	System.out.println(fields.accesValue(1).toString());
}*/
}
