package agrl;

public class Case {
	protected int x, y;
	Position[] cases = new Position[256];
	public Case() {
		for (int i=0; i< cases.length; i++) {
			for (int x=1; x<=16; x++) {
				for (int y=1; y<=16; y++) {
					cases[i] = new Position(x,y);
					i++;
				}
			}
		}
	}

	public Position findCase(int rows, int colums) {
		Position p = null;
		for (int i=0; i< cases.length; i++) {
			for (int x=1; x<=16; x++) {
				for (int y=1; y<=16; y++) {
					if (x == rows && y == colums) {
						p = cases[i];
					}
					i++;
				}
			}
		}
		return p;
	}

	public int findIndex(int rows, int colums) {
		int find = 0;
		for (int i=0; i< cases.length; i++) {
					if (cases[i].getX() == rows && cases[i].getY() == colums) {
						find = i;
				}
			}
		return find;
	}
	
	public Position accesValue(int search) {
		Position p = null;
		for (int i = 0; i< cases.length; i++) {
			if (i == search) {
				p = cases[i];	
			}
		}
		return p;
	}
	
	/*public static void main(String[] args)  {
		Case caseOp = new Case();
		for (int i=0; i< 256; i++) {
			for (int x=1; x<=16; x++) {
				for (int y=1; y<=16; y++) {
					System.out.println("("+x+","+y+") - i: " + i + "- i find" + caseOp.findIndex(x, y));
					i++;
				}
			}
				}
	}*/
}
