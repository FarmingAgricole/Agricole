package agrl;

public class CarrotWarehouse{
	private Carrot[] carrots;
	protected int maxCapacity;
	protected int currentSize = 0;

	public CarrotWarehouse(int maxCapacity) {
		this.maxCapacity = maxCapacity;
		carrots = new Carrot[maxCapacity];
	}

	public void add(Carrot carrot) {
		if (currentSize != carrots.length) {
			carrots[currentSize] = carrot;
			currentSize++;
		}
	}

	public void remove(Carrot carrot) {
		int i;
		for (i = 0; i<currentSize; i++) {
			if (carrots[i].equals(carrot)) {
				carrots[i] = null;
				break;
			}
		}
		for (int j = i; i<currentSize -1; i++) {
			carrots[i] = carrots[i + 1];
		}
		if (i != currentSize) {
			currentSize--;
		}
	}



	public void check() {
		for(int i=0; i<currentSize;i++) {
			carrots[i].warning();
			if(	carrots[i].) {
				remove(carrots[i]);
				System.out.println("EXPIRE");
				System.out.println("Carrot at posistion " + i + " is removed");
			}
		}
	}