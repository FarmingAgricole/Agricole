package ProjetGenie;

public class Meat extends Lapsing{
	protected int expireDate;
	
	public Meat(int expireDate, int datePasse) {
		super(expireDate, datePasse);
	}
	
	public boolean getStatus() {
		return super.lapsingStatus();
	}
	
	public void warning() {
		super.warning();
	}
	
	public void setDatePasse(int val) {
		
	}
}
