package ProjetGenie;
import java.util.Scanner;

public class Crop {
private int water, growth, daysgrowing, rategrowth;
private String type, status;
private boolean addwater = false;
Scanner input = new Scanner( System.in );

public Crop(int water, int rategrowth) {
	this.water=water;
	this.rategrowth= rategrowth;
	this.daysgrowing = 0;
	this.growth = 0;
	this.type="ABC";
}

public void needs(int water, int light) {
	this.water=water;
}
public String report() {
	updateStatus();
	return "Type: " + type + ", Status: " + status +
			", Growth: " + growth + ", Days growing: " 
			+ daysgrowing;
}

public void add_water() {
	addwater = true;
}

public void updateStatus() {
	if (growth == 0) {
		status = "Seed";
	} else if (growth > 0 && growth <=5) {
		status = "Seeding";
	} else if (growth > 5 && growth <=10) {
		status = "Young";
	} else if (growth > 10 && growth <=15) {
		status = "Mature";
	}  else if (growth > 15) {
		status = "Old";
	}
}

public void grow(int water, int light) {
	if (water>= this.water) {
		growth = growth + rategrowth;
	}
	daysgrowing = daysgrowing + 1;
	updateStatus();
}

public void needs() {
	System.out.println("[Water need]: " + water);
}

public void autoGrow(Crop crop, int days) {
	for (int i=0; i< days; i++) {
		crop.grow(4,4);
	}
}

public void menu () {
System.out.println("1. Grown manually over & day");
System.out.println("2. Grown automatically over 30 days");
System.out.println("3. Report status");
System.out.println("");
System.out.println("Please select an operation from menu above");
}

public void choice() {
	System.out.println("This is the crop management program");
	menu();
	String option = input.next(); 
	int select = Integer.parseInt(option);
	switch (select) {
	case 1: option.equals("2");
	String args0 = input.next();
	String args1 = input.next();
//autoGrow(args0, args1);	
		break;
	case 2:
	}
			
}
	
public static void main(String[] args) {
	Crop c = new Crop(4,2);
	c.needs();
	System.out.println(c.report());
	c.grow(4,4);
	System.out.println(c.report());
    c.autoGrow(c, 20);
    System.out.println(c.report());

}
}
