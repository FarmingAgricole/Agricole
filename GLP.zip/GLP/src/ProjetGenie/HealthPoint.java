package ProjetGenie;

public class HealthPoint {

}
