package ProjetGenie;

import java.util.ArrayList;

public class TractorX1Garage {
ArrayList<TractorX1> tractors = new ArrayList<TractorX1>();
protected static int numberTractor;

public TractorX1Garage() {
	this.numberTractor=0;
}

public void addTractorX1(TractorX1 tractorX1) {
	tractors.add(tractorX1);
	numberTractor++;
}
public void supTractorX1(int number) {
	tractors.remove(tractors.get(number));
	numberTractor--;
}

public String report(int number) {
	return tractors.get(number).toString();
}

public int getNumberTractor() {
	return tractors.size();
}

public TractorX1 get(int number) {
	return tractors.get(number);
}
}
