package td7.phonebook;

import java.util.NoSuchElementException;

public interface PhonebookInterface {
	void add(Contact contact) throws ContactAlreadyExistsException;

	Contact searchByName(String name) throws NoSuchElementException;

	Contact searchByNumber(String number) throws NoSuchElementException;

	Contact searchByEmail(String email) throws NoSuchElementException;
	
	boolean contains(Contact contact);

	void remove(Contact contact);

	int contactCount();
}
