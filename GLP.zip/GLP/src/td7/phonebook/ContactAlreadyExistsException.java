package td7.phonebook;

public class ContactAlreadyExistsException extends Exception {
	public ContactAlreadyExistsException(Contact contact) {
		super("Contact exists : " + contact.toString());
	}
}
