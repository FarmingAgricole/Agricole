package tree.gui;

import java.awt.Color;
import java.awt.Graphics;

import tree.data.Addition;
import tree.data.Constant;
import tree.data.Multiplication;
import tree.data.Subtraction;
import tree.data.Variable;

public class TriColoredStrategy implements ColorStrategy {

	@Override
	public void setColor(Graphics graphics, Constant node) {
		graphics.setColor(Color.RED);

	}

	@Override
	public void setColor(Graphics graphics, Variable node) {
		graphics.setColor(Color.BLUE);

	}

	@Override
	public void setColor(Graphics graphics, Addition node) {
		processOperation(graphics);
	}

	private void processOperation(Graphics graphics) {
		graphics.setColor(Color.GREEN);

	}

	@Override
	public void setColor(Graphics graphics, Subtraction node) {
		processOperation(graphics);

	}

	@Override
	public void setColor(Graphics graphics, Multiplication node) {
		processOperation(graphics);
	}

	@Override
	public void setLineColor(Graphics graphics) {
		graphics.setColor(Color.ORANGE);

	}

}
