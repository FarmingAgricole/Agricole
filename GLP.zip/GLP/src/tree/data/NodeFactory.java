package tree.data;

import org.apache.log4j.Logger;

import tree.log.LoggerUtility;

/**
 * @author Tianxiao.Liu@u-cergy.fr
 **/
public class NodeFactory {
	private static Logger logger = LoggerUtility.getLogger(NodeFactory.class);

	public static Constant createConstant(int value) {
		Constant constant = new Constant(value);
		logger.info("Constant creation with value : " + value);
		return constant;
	}

	public static Variable createVariable(String name) {
		Variable variable = new Variable(name);
		logger.info("Variable creation with name : " + name);
		return variable;

	}

	public static ArithmeticOperation createOperation(char type, Tree leftOperand, Tree rightOperand) {
		switch (type) {
		case '+':
			Addition addition = new Addition(leftOperand, rightOperand);
			logger.info("Addition operation creation");
			return addition;
		case '-':
			Subtraction subtraction = new Subtraction(leftOperand, rightOperand);
			logger.info("Subtraction operation creation");
			return subtraction;
		case '*':
			Multiplication multiplication = new Multiplication(leftOperand, rightOperand);
			logger.info("Multiplication operation creation");
			return multiplication;
		default:
			return null;
		}

	}

}
