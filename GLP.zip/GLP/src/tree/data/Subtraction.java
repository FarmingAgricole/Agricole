package tree.data;

import tree.core.TreeVisitor;

public class Subtraction extends ArithmeticOperation {

	public Subtraction(Tree leftOperand, Tree rightOperand) {
		super(leftOperand, rightOperand);
	}

	@Override
	public String toString() {
		return getLeftOperand().toString() + "-" + getRightOperand().toString();
	}

	@Override
	public <T> T accept(TreeVisitor<T> visitor) {
		return visitor.visit(this);
	}

}
