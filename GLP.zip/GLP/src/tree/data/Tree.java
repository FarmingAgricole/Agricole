package tree.data;

import tree.core.TreeVisitor;

public interface Tree {
	Tree getLeftOperand();

	Tree getRightOperand();

	<T> T accept(TreeVisitor<T> visitor);
}
