package tree.data;

public abstract class Operand implements Tree {

	@Override
	public Tree getLeftOperand() {
		return null;
	}

	@Override
	public Tree getRightOperand() {
		return null;
	}

}
