package tree.test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import tree.core.CalculationVisitor;
import tree.core.HeigtVisitor;
import tree.core.NodeCountVisitor;
import tree.core.TreeBuilder;
import tree.data.Tree;

/**
 * 
 * This is an automated test.
 *
 */
public class TestTreeVisitor{
	private Tree tree;
	
	@Before
	public void prepareTree() {
		TreeBuilder builder = new TreeBuilder("src/tree/input.txt");
		tree = builder.buildTree();
	}

	@Test
	public void testCalculationVisitor() {
		CalculationVisitor visitor = new CalculationVisitor();
		int result = tree.accept(visitor);
		assertEquals(-4, result);
	}
	
	@Test
	public void testNodeCountVisitor() {
		NodeCountVisitor visitor = new NodeCountVisitor();
		int nodeCount = tree.accept(visitor);
		assertEquals(11, nodeCount);
	}
	
	@Test
	public void testHeightVisitor() {
		HeigtVisitor visitor = new HeigtVisitor();
		tree.accept(visitor);
		
		assertEquals(3, visitor.getHeight());
	}

}
