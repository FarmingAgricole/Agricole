package tree.core;

import java.util.HashMap;
import java.util.Map;

import tree.data.Variable;


/**
 * Singleton implementation.
 * 
 * @author Tianxiao.Liu@u-cergy.fr
 **/
public class VariableRepository {
	private Map<String, Integer> variables = new HashMap<String, Integer>();

	private VariableRepository() {

	}

	private static VariableRepository instance = new VariableRepository();

	public static VariableRepository getInstance() {
		return instance;
	}

	public void register(String name, int initialValue) {
		variables.put(name, initialValue);
	}

	public int search(Variable variable) {
		return variables.get(variable.getName());
	}

}
