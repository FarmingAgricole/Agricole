package agrl;

public abstract class Vegetable extends Crop{
	
	public Vegetable(){
		super();
	}
	
	public Vegetable(int healthpoint, int maxhealth, int age, int dateofharvest){
		super(healthpoint, maxhealth, age, dateofharvest);
	}
	
	//public Vegetable(int healthpoint, int maxhealth, int lapsingmax){
		//super(healthpoint, maxhealth, lapsingmax);
	//}

}
