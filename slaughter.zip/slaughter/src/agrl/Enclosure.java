package agrl;

import java.util.HashMap;
import java.io.IOException;
import java.util.Collection;

public class Enclosure { 
	private HashMap<Position, Animal> animals = new HashMap<Position, Animal>();

	public Enclosure(){

	}
	//Add animal with choice(add in shop)
	public void addAnimal(Position position, int choice) {
		if (choice == 1) {
			animals.put(position, new Cow(100));
		}
		else if (choice ==2) {
			animals.put(position, new Chicken(100));
		}
		else if (choice ==3) {
			animals.put(position, new Pig(100));
		}
		else if (choice ==4) {
			animals.put(position, new Sheep(100));
		}
	}

	public void removeAnimal(Position position) {
		animals.remove(position);
	}

	//Return what kind of animal
	public int whichAnimal(Position position) {
		int res = 0;
		Animal c = accesValue(position);
		if(c == null) {
			res = 0;
		} else if (c instanceof Cow ) {
			res = 1;
		} else if (c instanceof Chicken) {
			res = 2;
		} else if (c instanceof Pig ) {
			res = 3;
		} else if (c instanceof Sheep) {
			res = 4;
		}
		return res;
	}

	public Animal accesValue(Position position) {
		Animal a = (Animal)animals.get(position);
		return a;
	}


	public int totalCow() {
		int n = 0;
		Collection<Animal> values = animals.values();
		for (Animal animal : values) {
			if (animal instanceof Cow) {
				n++;
			}
		}
		return n;
	}

	public int totalChicken() {
		int n = 0;
		Collection<Animal> values = animals.values();
		for (Animal animal : values) {
			if (animal instanceof Chicken) {
				n++;
			}
		}
		return n;
	}

	public int totalPig() {
		int n = 0;
		Collection<Animal> values = animals.values();
		for (Animal animal : values) {
			if (animal instanceof Pig) {
				n++;
			}
		}
		return n;
	}

	public int totalSheep() {
		int n = 0;
		Collection<Animal> values = animals.values();
		for (Animal animal : values) {
			if (animal instanceof Sheep) {
				n++;
			}
		}
		return n;
	}



	public int feeded() {
		int count = 0;
		Collection<Animal> values = animals.values();
		for (Animal animal : values) {
			if (animal instanceof Cow) {
				if (animal.getFed() == true) {
					count++;
				}
			}
		}
		return count;
	}

	public boolean autoFeedAllChicken(int turnbase, int durability){

		if (turnbase < durability){

			Collection<Animal> values = animals.values();
			for (Animal animal : values) {

				if (animal instanceof Chicken) {
					if (animal.getFed() == false) {
						animal.feed();
					}
				}
			}
			return true;
		}
		else {

			return false;
		}
	}

	public boolean autoFeedAllPig(int turnbase, int durability){

		if (turnbase < durability){

			Collection<Animal> values = animals.values();
			for (Animal animal : values) {

				if (animal instanceof Pig) {
					if (animal.getFed() == false) {
						animal.feed();
					}
				}
			}
			return true;
		}
		else {

			return false;
		}
	}

	public boolean autoFeedAllSheep(int turnbase, int durability){

		if (turnbase < durability){

			Collection<Animal> values = animals.values();
			for (Animal animal : values) {

				if (animal instanceof Sheep) {
					if (animal.getFed() == false) {
						animal.feed();
					}
				}
			}
			return true;
		}
		else {

			return false;
		}
	}

	public boolean autoFeedAllCow(int turnbase, int durability){

		if (turnbase < durability){

			Collection<Animal> values = animals.values();
			for (Animal animal : values) {

				if (animal instanceof Cow) {
					if (animal.getFed() == false) {
						animal.feed();
					}
				}
			}
			return true;
		}
		else {

			return false;
		}
	}

	public int size(){
		return animals.size();
	}

	/*public void feedManual(Position p) {
		Animal a = accesValue(p);
		a.feed();
	}*/

	//FEED ALL
	public void feedEveryAnimals(){
		for(int i=0;i<animals.size();i++){
			(animals.get(i)).feed();
		}
	}

	//SHOW STARVE
	public void afficheStarvation(){
		for(int i=0;i<animals.size();i++){
			System.out.println((animals.get(i)).getFed());
		}
	}
}
