package agrl;

import sun.security.krb5.internal.APOptions;

public class ActionPoint {

	private int initPoint = ALparameters.beginWith;
	private Turn turn = new Turn();
	private int backup;
	
	public ActionPoint (){
		
		
	}
	
	public boolean verifyPoint (int nbaction){ //
		
		backup = initPoint;
		initPoint -= nbaction;
		
		if (initPoint<0){
			
			initPoint = backup;
			return false;
			//message d'erreur et on revient aux point d'actions d'avant
			
			
		}
		
		else {
			
			return true;
		}
		
	}
	

	
	public void resetPoint (){
		
		initPoint = ALparameters.beginWith;
		
	}
	
	public int getInitPoint() {
		return initPoint;
	}
	
}

