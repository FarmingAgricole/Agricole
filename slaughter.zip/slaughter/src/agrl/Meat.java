package agrl;

public class Meat {
	protected int meat = 0;
	protected int dayspassed;
	protected static int lapsingmax = 5;

	public Meat(){
		this.dayspassed = 0;
	}
	
	public int getMeat(){
		return this.meat;
	}
	
	public void addMeat(int amount){
		this.meat = this.meat + amount;
	}
	
	public void removeMeat(int amount){
		this.meat = this.meat - amount;
	}
	public void daysPasse() { 
		this.dayspassed++;
	}

	public int getDaysPassed() {
		return dayspassed;
	}
	
	public boolean lapsingStatus() { //Check if the item is passe lapsing day
		if (dayspassed > lapsingmax) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean lapsingWarning() { //Allow user to know the item will expire or not
		if (dayspassed >= lapsingmax -3 && dayspassed <= lapsingmax) {
			return true;
		} else {
			return false;
		}
	}
}
