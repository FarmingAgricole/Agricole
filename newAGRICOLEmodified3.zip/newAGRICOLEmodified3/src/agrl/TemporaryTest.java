package agrl;

public class TemporaryTest {
	
	public TemporaryTest(){
		
	}
	
	public static void main (String[] args){
		Carrot carrot1 = new Carrot(50,0,1); //un cochon nommé cochon avec 50hp
		System.out.println(carrot1.toString());
	}

}
