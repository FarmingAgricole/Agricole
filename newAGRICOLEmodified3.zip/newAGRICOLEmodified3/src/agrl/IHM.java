package agrl;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;
import java.awt.Graphics;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class IHM extends JFrame {
	
	EnclosureCow enclosvaches = new EnclosureCow();
	StrawberrysPlanted strawberrysplanted = new StrawberrysPlanted();
	CarrotsPlanted carrotsplanted = new CarrotsPlanted();
	
	Wallet wallet = new Wallet(1500); // ARGENT DE DEPART
	Shop shop = new Shop();
	Turn turn = new Turn();
	Milk milk = new Milk();
	Hay hay = new Hay();
	
	ImageIcon grassIcon = new ImageIcon("grass.jpg");
	ImageIcon dirtIcon = new ImageIcon("dirt.jpg");
	ImageIcon strawberryIcon = new ImageIcon("strawberry.jpg");
	ImageIcon sleepIcon = new ImageIcon("sleep.jpg");
	ImageIcon waterIcon = new ImageIcon("arrosoir.jpg");
	ImageIcon harvestIcon = new ImageIcon("cash.jpg");
	
	protected JLabel casecow0 = new JLabel(grassIcon);
	protected JLabel casecow1 = new JLabel(grassIcon);
	protected JLabel casecow2 = new JLabel(grassIcon);
	protected JLabel casecow3 = new JLabel(grassIcon);
	
	protected JLabel casecrop0 = new JLabel(dirtIcon);
	protected JLabel casecrop1 = new JLabel(dirtIcon);
	protected JLabel casecrop2 = new JLabel(dirtIcon);
	protected JLabel casecrop3 = new JLabel(dirtIcon);
	
	protected JButton buyCowButton = new JButton("BuyCow(-500)");
	protected JButton sellCowButton = new JButton("SellCow(+250)");
	protected JButton feedCowButton = new JButton("FeedCow");
	protected JButton nextTurnButton = new JButton(sleepIcon);
	
	protected JButton buyCarrotButton = new JButton("BuyCarrot(-10)");
	protected JButton buyStrawberryButton = new JButton(strawberryIcon);
	protected JButton waterButton = new JButton(waterIcon);
	protected JButton sellCropsButton = new JButton(harvestIcon);
	
	protected JLabel turnLabel = new JLabel("Turn : "+turn.getTurn());
	protected JLabel messageLabel = new JLabel("message");
	protected JLabel walletLabel = new JLabel("Wallet :");
	protected JLabel goldLabel = new JLabel("Gold : "+String.valueOf(wallet.getGold()));
	
	protected JLabel milkLabel = new JLabel("Milk : "+milk.getMilk());
	protected JButton sellMilkButton = new JButton("Sell Milk(+50)");
	protected JLabel hayLabel = new JLabel("Hay : "+hay.getHay());
	protected JButton buyHayButton = new JButton("Buy Hay(-10)");
	
	private static final Font LABEL_FONT = new Font(Font.MONOSPACED, Font.BOLD, 40);
	private static final Font BUTTON_FONT = new Font(Font.DIALOG, Font.BOLD, 20);
	
	public IHM(String title) throws IOException {
		
		super(title);
		
		initStyle();
	
		initLayout();
		
		initActions();
	
	}
	
	protected void initLayout() throws IOException{
		
		GridLayout grid = new GridLayout(6,4); // lignes,colonnes
		Container contentPane = getContentPane();
		contentPane.setLayout(grid);
		
		
		contentPane.add(casecow0);
		contentPane.add(casecow1);
		contentPane.add(casecow2);
		contentPane.add(casecow3);
		
		contentPane.add(casecrop0);
		contentPane.add(casecrop1);
		contentPane.add(casecrop2);
		contentPane.add(casecrop3);
		
		contentPane.add(buyCowButton);
		contentPane.add(sellCowButton);
		contentPane.add(feedCowButton);
		contentPane.add(nextTurnButton);
		
		contentPane.add(buyCarrotButton);
		contentPane.add(buyStrawberryButton);
		contentPane.add(waterButton);
		contentPane.add(sellCropsButton);
		
		contentPane.add(turnLabel);
		contentPane.add(messageLabel);
		contentPane.add(walletLabel);
		contentPane.add(goldLabel);
		
		contentPane.add(milkLabel);
		contentPane.add(sellMilkButton);
		contentPane.add(hayLabel);
		contentPane.add(buyHayButton);
		
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(800, 1000);
		setResizable(false);
		setVisible(true);
		
	}
	
	protected void initStyle() {

		casecow0.setFont(LABEL_FONT);
		casecow1.setFont(LABEL_FONT);
		casecow2.setFont(LABEL_FONT);
		casecow3.setFont(LABEL_FONT);
		
		buyCowButton.setFont(BUTTON_FONT);
		sellCowButton.setFont(BUTTON_FONT);
		feedCowButton.setFont(BUTTON_FONT);
		nextTurnButton.setFont(BUTTON_FONT);
		
		buyStrawberryButton.setFont(BUTTON_FONT);
		waterButton.setFont(BUTTON_FONT);
	}
	
	protected void initActions(){
		buyCowButton.addActionListener(new BuyCowAction());
		sellCowButton.addActionListener(new SellCowAction());
		feedCowButton.addActionListener(new FeedCowAction());
		nextTurnButton.addActionListener(new NextTurnAction());
		sellMilkButton.addActionListener(new SellMilkAction());
		buyHayButton.addActionListener(new BuyHayAction());
		casecow0.addMouseListener(new Case0Action());
		
		buyStrawberryButton.addMouseListener(new BuyStrawberryAction());
		waterButton.addMouseListener(new WaterAction());
		sellCropsButton.addMouseListener(new SellCropsAction());
	}
	
	private class Case0Action implements MouseListener{
		
		public void mouseClicked(MouseEvent e){
			
			messageLabel.setText("msg : "+(enclosvaches.get(0)).getName());
			System.out.println("name : "+(enclosvaches.get(0)).getName()+
					" HP:"+(enclosvaches.get(0)).getHealthPoint());
		}


		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
	}
	
	private class BuyStrawberryAction implements MouseListener{
		
		public void mouseClicked(MouseEvent e){
			
			if (wallet.getGold()<50){
				//message non
			System.out.println("argent<50");
			messageLabel.setText("Pas assez pour acheter une plantation de fraise");
		}
			
		else if(strawberrysplanted.size()>3){
				//message trop de fraises
			System.out.println("Trop de fraises");
			messageLabel.setText("Trop de fraise");
		}
			
		else{
			System.out.println("fraise achet�e");
			shop.buyStrawberry(wallet, carrotsplanted, strawberrysplanted);
			messageLabel.setText("Fraise achet�e");
		}
		
		actualizeStrawberryIcon();
		actualizeWallet();
			
		}


		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
	}
	
	private class WaterAction implements MouseListener{
		
		public void mouseClicked(MouseEvent e){
			
			strawberrysplanted.waterEveryStrawberrys();
		
			actualizeStrawberryIcon();
			
		}


		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
	}
	
	private class SellCropsAction implements MouseListener{
		
		public void mouseClicked(MouseEvent e){
			
			shop.sellCrops(wallet, carrotsplanted, strawberrysplanted);
			actualizeStrawberryIcon();
			actualizeWallet();
		}


		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
	}
	
	private class BuyCowAction implements ActionListener {
		
		public void actionPerformed(ActionEvent e){
			
			if (wallet.getGold()<500){
					//message non
				System.out.println("argent<500");
				messageLabel.setText("Pas assez pour acheter une vache");
			}
				
			else if(enclosvaches.getNumberOfCows()>3){
					//message trop de vache
				System.out.println("Trop de vache");
				messageLabel.setText("Trop de vache");
			}
				
			else{
				System.out.println("Vache achet�e");
				shop.buyCow(wallet,"Vache",enclosvaches);
				messageLabel.setText("Vache achet�e");
			}
			
			actualizeCowIcon();
			actualizeWallet();
			
			
		}
	}
	
	private class SellCowAction implements ActionListener {
		
		public void actionPerformed(ActionEvent e){
			
			if (enclosvaches.getNumberOfCows()==0){
				//message pas de vache a vendre
				System.out.println("Pas de vache a vendre");
				messageLabel.setText("Pas de vache a vendre");
			}
			else {
				shop.sellCow(wallet,enclosvaches);
				System.out.println("Vache vendue");
				messageLabel.setText("Vache vendue");
			}
			
			actualizeCowIcon();
			actualizeWallet();	
			
		}
	}
	
	private class FeedCowAction implements ActionListener {
		
		public void actionPerformed(ActionEvent e){
			
			shop.feedCows(hay, enclosvaches);
			actualizeCowIcon();
			actualizeWallet();
			actualizeHay();
			messageLabel.setText("");
			
		}
	}

	private class NextTurnAction implements ActionListener {
	
	public void actionPerformed(ActionEvent e){
		
		turn.nextTurn(enclosvaches, milk, carrotsplanted, strawberrysplanted);
		
		actualizeCowIcon();
		actualizeStrawberryIcon();
		actualizeWallet();
		actualizeTurn();
		actualizeMilk();
		messageLabel.setText("Tour pass�");
		
		}
	}
	
	private class SellMilkAction implements ActionListener {
		
	public void actionPerformed(ActionEvent e){
		
		shop.sellMilk(milk, wallet);
		actualizeMilk();
		actualizeWallet();
		messageLabel.setText("");
		
		
		}
	}
	
	private class BuyHayAction implements ActionListener {
		
	public void actionPerformed(ActionEvent e){
		
		shop.buyHay(wallet, hay);
		actualizeHay();
		actualizeWallet();
		messageLabel.setText("");
		}
	}
	
	public void actualizeCowIcon(){
		
		int i=0;
		ImageIcon cowIcon = new ImageIcon("cow.jpg");
		ImageIcon cowfedIcon = new ImageIcon("cowfed.jpg");
		ImageIcon grassIcon = new ImageIcon("grass.jpg");
		if (i<enclosvaches.getNumberOfCows()){
			if ((enclosvaches.get(i)).getFed()){casecow0.setIcon(cowfedIcon);}
			else{casecow0.setIcon(cowIcon);}
			i++;
		}
		else {casecow0.setIcon(grassIcon);}
		if (i<enclosvaches.getNumberOfCows()){
			if ((enclosvaches.get(i)).getFed()){casecow1.setIcon(cowfedIcon);}
			else{casecow1.setIcon(cowIcon);}
			i++;
		}
		else {casecow1.setIcon(grassIcon);}
		if (i<enclosvaches.getNumberOfCows()){
			if ((enclosvaches.get(i)).getFed()){casecow2.setIcon(cowfedIcon);}
			else{casecow2.setIcon(cowIcon);}
			i++;
		}
		else {casecow2.setIcon(grassIcon);}
		if (i<enclosvaches.getNumberOfCows()){
			if ((enclosvaches.get(i)).getFed()){casecow3.setIcon(cowfedIcon);}
			else{casecow3.setIcon(cowIcon);}
			i++;
		}
		else {casecow3.setIcon(grassIcon);}
		
	}
	
	public void actualizeStrawberryIcon(){
		
		int i=0;
		ImageIcon youngstrawberryIcon = new ImageIcon("youngstrawberry.jpg");
		ImageIcon youngstrawberrywateredIcon = new ImageIcon("youngstrawberrywatered.jpg");
		ImageIcon strawberryplantedIcon = new ImageIcon("strawberryplanted.jpg");
		ImageIcon dirtIcon = new ImageIcon("dirt.jpg");
		
		if (i<strawberrysplanted.size()){
			if ((strawberrysplanted.get(i)).getAge()<5){
				if((strawberrysplanted.get(i)).getWater()){
					casecrop0.setIcon(youngstrawberrywateredIcon);
				}
				else{
					casecrop0.setIcon(youngstrawberryIcon);
				}
			}
			else{
				casecrop0.setIcon(strawberryplantedIcon);
			}
			i++;
		}
		else {casecrop0.setIcon(dirtIcon);}
		
		if (i<strawberrysplanted.size()){
			if ((strawberrysplanted.get(i)).getAge()<5){
				if((strawberrysplanted.get(i)).getWater()){
					casecrop1.setIcon(youngstrawberrywateredIcon);
				}
				else{
					casecrop1.setIcon(youngstrawberryIcon);
				}
			}
			else{
				casecrop1.setIcon(strawberryplantedIcon);
			}
			i++;
		}
		else {casecrop1.setIcon(dirtIcon);}
		
		if (i<strawberrysplanted.size()){
			if ((strawberrysplanted.get(i)).getAge()<5){
				if((strawberrysplanted.get(i)).getWater()){
					casecrop2.setIcon(youngstrawberrywateredIcon);
				}
				else{
					casecrop2.setIcon(youngstrawberryIcon);
				}
			}
			else{
				casecrop2.setIcon(strawberryplantedIcon);
			}
			i++;
		}
		else {casecrop2.setIcon(dirtIcon);}
		
		if (i<strawberrysplanted.size()){
			if ((strawberrysplanted.get(i)).getAge()<5){
				if((strawberrysplanted.get(i)).getWater()){
					casecrop3.setIcon(youngstrawberrywateredIcon);
				}
				else{
					casecrop3.setIcon(youngstrawberryIcon);
				}
			}
			else{
				casecrop3.setIcon(strawberryplantedIcon);
			}
			i++;
		}
		else {casecrop3.setIcon(dirtIcon);}
		
	}
	
	public void actualizeWallet(){
		goldLabel.setText("Gold : "+String.valueOf(wallet.getGold()));
	}
	
	public void actualizeMilk(){
		milkLabel.setText("Milk : "+String.valueOf(milk.getMilk()));
	}
	
	public void actualizeTurn(){
		turnLabel.setText("Turn : "+String.valueOf(turn.getTurn()));
	}
	
	public void actualizeHay(){
		hayLabel.setText("Hay : "+String.valueOf(hay.getHay()));
	}
	
	
	public static void main(String[] args) throws IOException {
		new IHM("r�ussite IHM");
	}
	
	

	
}
