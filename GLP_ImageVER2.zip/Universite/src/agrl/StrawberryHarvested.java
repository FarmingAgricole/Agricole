package agrl;

public class StrawberryHarvested{
	

	protected static int lapsingmax=30;
	protected int dateofharvest; // retient a quel tour on a récolté la culture
	
	public StrawberryHarvested(){
	}
	
	
	public String toString(){
		return "\n"+"dateofharvest:"+dateofharvest+" tours";
		
	}

}
