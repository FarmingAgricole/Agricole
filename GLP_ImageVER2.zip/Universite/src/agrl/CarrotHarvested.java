/*package agrl;

public class CarrotHarvested {
	
	protected static int lapsingmax=30;
	protected int dateofharvest; // retient a quel tour on a récolté la culture
	
	public CarrotHarvested() {
	}
	
	
	public String toString(){
		return "\n"+"dateofharvest:"+dateofharvest+" tours";
		
	}

}*/