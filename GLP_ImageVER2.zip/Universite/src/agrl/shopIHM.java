package agrl;
import java.awt.*;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

import javax.imageio.ImageIO;
import javax.swing.*;


public class shopIHM  extends JFrame {
	protected JButton buyHayButton = new JButton("Buy Hay (-10)");
	protected JLabel hayLabel = new JLabel("Message");
	private JPanel cardPanel, jp1, jp2, buttonPanel;
    private JLabel jl1, jl2;
    private JButton btn1, btn2;
    private CardLayout cardLayout = new CardLayout();
	private JPanel rightPanel;
	private JPanel leftPanel;
	private static final Font LABEL_FONT = new Font(Font.MONOSPACED, Font.BOLD, 90);
	private static final Font BUTTON_FONT = new Font(Font.DIALOG, Font.BOLD, 20);
	
	public shopIHM() {
		initLayout();
		initStyle();
		initActions();
	}
	
	protected void initLayout(){
		 setTitle("Test med CardLayout");
	        setSize(400, 300);
	        cardPanel = new JPanel();
	        buttonPanel = new JPanel();
	        cardPanel.setLayout(cardLayout);
	        jp1 = new JPanel();
	        jp2 = new JPanel();
	        jl1 = new JLabel("Card 1");
	        jl2 = new JLabel("Card 2");
	        jp1.add(jl1);
	        jp2.add(jl2);
	        cardPanel.add(jp1, "1");
	        cardPanel.add(jp2, "2");
	        btn1 = new JButton("Show Card 1");
	        btn1.addActionListener(new ActionListener() {

	            public void actionPerformed(ActionEvent e) {
	                cardLayout.show(cardPanel, "1");
	            }
	        });
	        btn2 = new JButton("Show Card 2");
	        btn2.addActionListener(new ActionListener() {

	            public void actionPerformed(ActionEvent e) {
	                cardLayout.show(cardPanel, "2");
	            }
	        });
	        buttonPanel.add(btn1);
	        buttonPanel.add(btn2);
	        add(cardPanel, BorderLayout.NORTH);
	        add(buttonPanel, BorderLayout.SOUTH);
		/*rightPanel = new JPanel();
		rightPanel.setLayout(new GridLayout(2,2));
		
		
		add(rightPanel, BorderLayout.CENTER);
		add(cards, BorderLayout.NORTH);
		rightPanel.setPreferredSize(new Dimension(500,500));
		rightPanel.add(buyHayButton);
		rightPanel.add(hayLabel);
		card2.setLayout(new BorderLayout());*/
		setVisible(true);
		pack();
    }

	
	protected void initActions(){
		buyHayButton.addActionListener(new buyHayAction());
	}
	
	protected void initStyle() {
		buyHayButton.setFont(BUTTON_FONT);
	}
	
	private class buyHayAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
		}
	}
	public static void main(String[] args) throws IOException {
		new shopIHM();
	}
}
