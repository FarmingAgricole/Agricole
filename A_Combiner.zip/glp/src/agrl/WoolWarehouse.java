package agrl;

public class WoolWarehouse {
	private Wool[] wools;
	protected int maxCapacity;
	protected int currentSize = 0;

	public WoolWarehouse(int maxCapacity) {
		this.maxCapacity = maxCapacity;
		wools = new Wool[maxCapacity];
	}

	public void add(Wool Wool) {
		if (currentSize != wools.length) {
			wools[currentSize] = Wool;
			currentSize++;
		}
	}

	public void remove(Wool Wool) {
		int i;
		for (i = 0; i<currentSize; i++) {
			if (wools[i].equals(Wool)) {
				wools[i] = null;
				break;
			}
		}
		for (int j = i; i<currentSize -1; i++) {
			wools[j] = wools[j + 1];
		}
		if (i != currentSize) {
			currentSize--;
		}
	}

	public void check() { //Check if the item pass date limit then throw them away
		for(int i=0; i<currentSize;i++) {
			if(	wools[i].lapsingStatus()) {
				remove(wools[i]);
				System.out.println("EXPIRE");
				System.out.println("Wool at posistion " + i + " is removed");
		}
	}
	}
	
	public int warningCheck() { //Check number of all item ready to pass date limit
		int val = 0;
		for(int i=0; i<currentSize;i++) {
			if(	wools[i].lapsingWarning()) {
				val++;
			}
		}
		return val;
	}

	public Wool accesValue(int search) {
		Wool res = null;
		for(int i=0; i<currentSize;i++) {
			if (i == search) {
				res = wools[i];
			}
		}
		return res;
	}
	public int getSize() {
		return currentSize;
	}
}
