package agrl;

public abstract class Crop extends Shape{

	protected boolean water = true;
	protected int lapsingmax;
	protected int age;
	protected int dateofharvest;
	protected int dayspassed;


	public Crop(int healthpoint, int maxhealth, int dateofharvest, int lapsingmax){ /////add age
		super(healthpoint, maxhealth);
		this.age = 0;
		this.dayspassed = 0;
		this.dateofharvest = dateofharvest;
		this.lapsingmax = lapsingmax;
	}


	public abstract void isThirsty(); //abstrait car le comportement sera différent selon le type de culture

	public void water(){
		this.water=true;
	}

	public void dry(){
		this.water=false;
	}

	public boolean getWater(){
		return this.water;
	}

	public void getOlder() {
		this.age++;
	}

	public boolean isHarvested() {
		boolean res;
		if (age >= dateofharvest) {
			res = true;
		} else {
			res = false;
		}	
		return res;
	}
	
	public int harvestIn() {
		return dateofharvest - age;
	}

	public void daysPasse() {
		this.dayspassed++;
	}

	public int getDaysPassed() {
		return dayspassed;
	}
	
	public boolean isDying() {
		return super.isDying();
	}
	
	public boolean lapsingStatus() {
		boolean res;
		if (dayspassed >= lapsingmax) {
			res = true;
		} else {
			res = false;
		}
		return res;
	}

	public void warning() {
		if(dayspassed < lapsingmax) {
			if (dayspassed >= (lapsingmax - 5)) {
				System.out.println("ALERT!!!" + "Expire in " + (lapsingmax - dayspassed)
						+ " days");
				System.out.println("Please haverst it soon or it will be go off");
			} else if (dayspassed >= ((lapsingmax*2)/3)) {
				System.out.println("Expire very soon");
				System.out.println("It will be expire in " + (lapsingmax - dayspassed)
						+ " days");
			} else {
				System.out.println("Good conidition");
				System.out.println("It will be expire in " + (lapsingmax - dayspassed)
						+ " days");
			}
		}
	}



}
