package agrl;

public class MeatWarehouse {
	private Meat[] meats;
	protected int maxCapacity;
	protected int currentSize = 0;

	public MeatWarehouse(int maxCapacity) {
		this.maxCapacity = maxCapacity;
		meats = new Meat[maxCapacity];
	}

	public void add(Meat Meat) {
		if (currentSize != meats.length) {
			meats[currentSize] = Meat;
			currentSize++;
		}
	}

	public void remove(Meat Meat) {
		int i;
		for (i = 0; i<currentSize; i++) {
			if (meats[i].equals(Meat)) {
				meats[i] = null;
				break;
			}
		}
		for (int j = i; i<currentSize -1; i++) {
			meats[j] = meats[j + 1];
		}
		if (i != currentSize) {
			currentSize--;
		}
	}

	public void check() {
		for(int i=0; i<currentSize;i++) {
			if(	meats[i].lapsingStatus()) {
				remove(meats[i]);
				System.out.println("EXPIRE");
				System.out.println("Meat at posistion " + i + " is removed");
		}
	}
	}
	
	public int warningCheck() { //Check number of all item ready to pass date limit
		int val = 0;
		for(int i=0; i<currentSize;i++) {
			if(	meats[i].lapsingWarning()) {
				val++;
			}
		}
		return val;
	}

	public Meat accesValue(int search) {
		Meat res = null;
		for(int i=0; i<currentSize;i++) {
			if (i == search) {
				res = meats[i];
			}
		}
		return res;
	}
	public int getSize() {
		return currentSize;
	}
}
