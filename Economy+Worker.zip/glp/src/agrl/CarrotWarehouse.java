package agrl;

public class CarrotWarehouse{
	private Crop[] carrots;
	protected int maxCapacity;
	protected int currentSize = 0;

	public CarrotWarehouse(int maxCapacity) {
		this.maxCapacity = maxCapacity;
		carrots = new Carrot[maxCapacity];
	}

	public void add(Crop carrot) {
		if (currentSize != carrots.length) {
			carrots[currentSize] = carrot;
			currentSize++;
		}
	}

	public void remove(Crop carrot) {
		int i;
		for (i = 0; i<currentSize; i++) {
			if (carrots[i].equals(carrot)) {
				carrots[i] = null;
				break;
			}
		}
		for (int j = i; i<currentSize -1; i++) {
			carrots[j] = carrots[j + 1];
		}
		if (i != currentSize) {
			currentSize--;
		}
	}

	public void check() {
		for(int i=0; i<currentSize;i++) {
			carrots[i].warning();
			if(	carrots[i].lapsingStatus()) {
				remove(carrots[i]);
				System.out.println("EXPIRE");
				System.out.println("Carrot at posistion " + i + " is removed");
		}
	}
	}

	public Crop accesValue(int search) {
		Crop res = null;
		for(int i=0; i<currentSize;i++) {
			if (i == search) {
				res = carrots[i];
			}
		}
		return res;
	}
	public int getSize() {
		return currentSize;
	}
	}