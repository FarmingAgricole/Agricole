package agrl;

public class Strawberry extends Fruit{
	
	protected static int maxhealth = 100;
	protected static int lapsingmax = 5;

	public Strawberry(int healthpoint, int dateofharvest){ 
		super(healthpoint,maxhealth, dateofharvest, lapsingmax);
	}
	
	
	public void isThirsty(){
		this.setHealthPoint(this.getHealthPoint()-20);
	}
	
	public String toString(){
		return "Age: "+age+" days"+"\n"+ "Can be harvested in: " + super.harvestIn() + " days" +
				"\n"  + super.toString(); 
	}	
	}
