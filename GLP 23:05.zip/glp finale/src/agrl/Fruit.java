package agrl;

public abstract class Fruit extends Crop{
	
	public Fruit(int healthpoint, int maxhealth, int dateofharvest, int lapsingmax){
		super(healthpoint, maxhealth, dateofharvest, lapsingmax);
	}


}
