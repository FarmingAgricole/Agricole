package agrl;

public class Turn {

	int maxTurn;
	int Turn;


	public Turn(){

	}

	//Turn of all animal

	public void turnAnimal(Enclosure enclos,Case caseOp, Milk milk, Egg egg, Wool wool
			,MilkWarehouse mw, EggWarehouse ew, WoolWarehouse ww){
		for (int x=1; x<=16; x++) {
			for (int y=1; y<=16; y++) {
				Position p = caseOp.findCase(x,y);
				if(enclos.whichAnimal(p) == 1) {
					if (enclos.accesValue(p).getFed()) {
						enclos.accesValue(p).starve();
					} else {
						enclos.accesValue(p).isStarving();
						if (enclos.accesValue(p).getHealthPoint()<=0) {
							enclos.removeAnimal(p);
						}
					}
					enclos.accesValue(p).getOlder();
				} else if (enclos.whichAnimal(p) == 2){
					if (enclos.accesValue(p).getFed()) {
						enclos.accesValue(p).starve();
					} else {
						enclos.accesValue(p).isStarving();
						if (enclos.accesValue(p).getHealthPoint()<=0) {
							enclos.removeAnimal(p);
						}
					}
					enclos.accesValue(p).getOlder();
				} else if (enclos.whichAnimal(p) == 3) { // ADD MEAT!!!!!!!!!!
					if (enclos.accesValue(p).getFed()) {
						enclos.accesValue(p).starve();
					} else {
						enclos.accesValue(p).isStarving();
						if (enclos.accesValue(p).getHealthPoint()<=0) {
							enclos.removeAnimal(p);
						}
					}
					enclos.accesValue(p).getOlder();
				}else if (enclos.whichAnimal(p) == 4) {
					if (enclos.accesValue(p).getFed()) {
						enclos.accesValue(p).starve();
					} else {
						enclos.accesValue(p).isStarving();
						if (enclos.accesValue(p).getHealthPoint()<=0) {
							enclos.removeAnimal(p);
						}
					}
					enclos.accesValue(p).getOlder();
				}
			}
		}
	}



	public void turnCrops(Field field, Case caseOp) {
		for (int x=1; x<=16; x++) {
			for (int y=1; y<=16; y++) {
				Position p = caseOp.findCase(x,y);
				if (field.accesValue(p) != null) {
					field.accesValue(p).getOlder();
					if (field.accesValue(p).isHarvested() == false) {
						if(field.accesValue(p).getWater()) {
							field.accesValue(p).dry();
						} else {
							field.accesValue(p).isThirsty();
							if(field.accesValue(p).getHealthPoint()<=0) {
								field.removeCrop(p);
							}
						}
					} else {
						field.accesValue(p).water();
					}
				}
			}
		}
	}

	public void turnWarehouse(CarrotWarehouse cw, StrawberryWarehouse sw) {
		for (int i = 0; i<cw.getSize(); i++) {
			cw.accesValue(i).daysPasse();
		}
		for (int i = 0; i<sw.getSize(); i++) {
			sw.accesValue(i).daysPasse();
		}
	}


	public int getTurn() {
		return this.Turn;
	}

	public void goTurn(){
		this.Turn++;
	}


}
