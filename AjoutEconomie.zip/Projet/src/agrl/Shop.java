package agrl;
import java.awt.*;

import com.sun.org.apache.bcel.internal.util.BCELifier;

import sun.awt.image.PixelConverter.Bgrx;


public class Shop{
	private RepairVehicle rv = new RepairVehicle();
	private boolean result;
	private int CarrotEco;
	private int StrawEco;
	private int MilkEco;
	private int EggEco;
	private int WoolEco;



	//Prix de la nourriture
	private int hayPrice = ALparameters.buyHayPrice;
	private int buyGrain = ALparameters.buyGrainPrice;

	//Prix des animaux
	private int buyCow = ALparameters.buyCowPrice;
	private int sellCow = ALparameters.sellCowPrice;
	private int buySheep = ALparameters.buySheepPrice;
	private int sellSheep = ALparameters.sellSheepPrice;
	private int buyChicken = ALparameters.buyChickenPrice;
	private int sellChicken = ALparameters.sellChickenPrice;
	private int buyPig = ALparameters.buyPigPrice;
	private int sellPig = ALparameters.sellPigPrice;

	//Prix des ressources
	private int buyCarrot = ALparameters.buyCarrotPrice;
	private int sellCarrot = ALparameters.sellCarrotPrice;
	private int buyStraw = ALparameters.buyStrawPrice;
	private int sellStraw = ALparameters.sellStrawPrice;
	private int sellMilk = ALparameters.sellMilkPrice;
	private int sellWool = ALparameters.sellWoolPrice;
	private int sellEgg = ALparameters.sellEggPrice;


	public Shop(){

	}


	public void buyHay(Wallet wallet, Hay hay){ 
		wallet.removeGold(hayPrice);
		hay.addHay(1);
	}

	//Tractor X1
	public void buyTractorX1(Wallet wallet, Garage garages, Position position){
		if(garages.addMore()) {
			garages.addTractorX1(position);
			wallet.removeGold(1500);
		}
	}

	//Cow
	public void buyCow(Wallet wallet, Enclosure enclosures, Position position){
		enclosures.addAnimal(position,1);
		wallet.removeGold(buyCow);
	}

	public void sellCow(Wallet wallet, Enclosure enclosures, Position position){
		enclosures.removeAnimal(position);
		wallet.addGold(sellCow);
	}

	//Poules

	public void buyChicken(Wallet wallet, Enclosure enclosures, Position position){

		enclosures.addAnimal(position,2);
		wallet.removeGold(buyChicken);
	}

	public void sellChicken(Wallet wallet, Enclosure enclosures, Position position){
		enclosures.removeAnimal(position);
		wallet.addGold(sellChicken);
	}

	//Moutons

	public void buySheep(Wallet wallet, Enclosure enclosures, Position position){
		enclosures.addAnimal(position,4);
		wallet.removeGold(buySheep);
	}

	public void sellSheep(Wallet wallet, Enclosure enclosures, Position position){
		enclosures.removeAnimal(position);
		wallet.addGold(sellSheep);
	}

	//Pig

	public void buyPig(Wallet wallet, Enclosure enclosures, Position position){
		enclosures.addAnimal(position,3);
		wallet.removeGold(buyPig);
	}

	public void sellPig(Wallet wallet, Enclosure enclosures, Position position){
		enclosures.removeAnimal(position);
		wallet.addGold(sellPig);
	}



	public void buyCarrot(Field fields, Wallet wallet, Position p){
		fields.addCrop(p,1);
		wallet.removeGold(buyCarrot);


	}

	public void sellCarrot(CarrotWarehouse cw, Wallet wallet){

		for (int i=0; i<cw.getSize();i++) {
			//if (cw.accesValue(i).lapsingStatus() == false) {
			cw.remove(cw.accesValue(i));
			wallet.addGold(sellCarrot);

		}
		CarrotEco += 1;

		if (CarrotEco == 10){

			CarrotEco = 0;
			sellCarrot -=10;
			sellStraw +=50;


		}
		if (sellCarrot <=0){

			sellCarrot = 0;
		}
	}

	public void sellStrawberry(StrawberryWarehouse sw, Wallet wallet){
		for (int i=0; i<sw.getSize();i++) {
			//	if (sw.accesValue(i).lapsingStatus() == false) {
			sw.remove(sw.accesValue(i));
			wallet.addGold(sellStraw);
		}
		StrawEco += 1;

		if (StrawEco == 10){

			StrawEco = 0;
			sellStraw -= 20;
			sellCarrot +=50;

		}
		if (sellStraw <=0){

			sellStraw = 0;
		}

	}

	public void buyStrawberry(Field fields, Wallet wallet, Position p){
		fields.addCrop(p,2);
		wallet.removeGold(buyStraw);
	}


	public void buyGrain(Wallet wallet, Grain grain){
		wallet.removeGold(buyGrain);
		grain.addGrain(1);
	}

	public void sellMilk(MilkWarehouse mw, Wallet wallet){
		for (int i=0; i<mw.getSize();i++) {	
			mw.remove(mw.accesValue(i));
			wallet.addGold(sellMilk);
		}
		MilkEco += 1;

		if (MilkEco == 10){

			MilkEco = 0;
			sellMilk -= 2;
			sellWool +=25;

		}

		if (sellMilk <=0){

			sellMilk = 0;
		}

	}

public void sellEgg(EggWarehouse ew, Wallet wallet){
	for (int i=0; i<ew.getSize();i++) {	
		ew.remove(ew.accesValue(i));
		wallet.addGold(sellEgg);
	}
	EggEco += 1;

	if (EggEco == 10){

		EggEco = 0;
		sellEgg -= 2;
		sellWool +=20;

	}

	if (sellEgg <=0){

		sellEgg = 0;
	}
}

public void sellWool(WoolWarehouse ww, Wallet wallet){
	for (int i=0; i<ww.getSize();i++) {		
		ww.remove(ww.accesValue(i));
		wallet.addGold(sellWool);
	}
	WoolEco += 1;

	if (WoolEco == 8){

		WoolEco = 0;
		sellWool -= 25;
		sellEgg +=10;
		sellMilk += 10;

	}

	if (sellMilk <=0){

		sellMilk = 0;
	}
}

public boolean purchased() {
	return result;
}


public void buyTractorX2(Wallet wallet, Garage garages, Position position){
	if(garages.addMore()) {
		garages.addTractorX2(position);
		wallet.removeGold(3000);
		System.out.println(wallet.getGold());
	}
}


public void sellTractor(Wallet wallet, Garage garages, Position position){
	if(garages.getNumberVehicle()==0){
		System.out.println("Tractor not found");
	}
	else {
		if (garages.whichVehicle(position) == 1) {
			System.out.println("Tractor X1 found");
			garages.removeVehicle(position);
			System.out.println("Tractor X1 removed");
			wallet.addGold(750);

		} else if (garages.whichVehicle(position) == 2) {
			System.out.println("Tractor X2 found");
			garages.removeVehicle(position);
			System.out.println("Tractor X2 removed");
			wallet.addGold(1500);
		}
	}
}

public void repairTractor(Wallet wallet, Garage garages, Position position){
	if(garages.getNumberVehicle()==0){
		System.out.println("Tractor not found");
	}
	else {
		Vehicle v  = garages.accesValue(position);
		if (garages.whichVehicle(position) == 1) {
			wallet.removeGold(rv.priceFix(v));
			rv.repair(v);
		} else if (garages.whichVehicle(position) == 2) {
			wallet.removeGold(rv.priceFix(v)*2);
			rv.repair(v);
		}
	}
}
}

