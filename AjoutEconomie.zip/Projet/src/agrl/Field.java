package agrl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;

public class Field {
	private HashMap<Position, Crop> crops = new HashMap<Position, Crop>();
	private int level = 0;

public Field() {
	
}

//Add crop with choice(for shop)
public void addCrop(Position position, int choice) {
	if (choice == 1) {
	crops.put(position, new Carrot(100,3));
	}
	else if (choice ==2) {
		crops.put(position, new Strawberry(100,7));
	}
}

public void removeCrop(Position position) {
	crops.remove(position);
}

//Return what kind of choice
public int whichCrop(Position position) {
	int res = 0;
	Crop c = accesValue(position);
	if(c == null) {
		res = 0;
	} else if (c instanceof Carrot ) {
		res = 3;
	} else if (c instanceof Strawberry) {
		res = 4;
	}
	return res;
}

//Show info of crop
public String updateStatus(Position position) {
	Crop c = accesValue(position);
	return c.toString();
}

public int getSize() {
	return crops.size();
}

public Crop accesValue(Position position) {
	Crop c = (Crop)crops.get(position);
	return c;
}

public int getLevel(){
	return this.level;
}

public void setLevel(int amount){
	this.level = amount;
}

public void levelUp(){
	this.level = this.level + 1;
}
}
