Modficiation des classes: ALparameters, Shop
Ajout de l'economie dans cahque sell* methode, exemple : 

public void sellWool(WoolWarehouse ww, Wallet wallet){
	for (int i=0; i<ww.getSize();i++) {		
		ww.remove(ww.accesValue(i));
		wallet.addGold(sellWool);
	}
	WoolEco += 1;

	if (WoolEco == 8){

		WoolEco = 0;
		sellWool -= 25;
		sellEgg +=10;
		sellMilk += 10;

	}

	if (sellMilk <=0){

		sellMilk = 0;
	}
}