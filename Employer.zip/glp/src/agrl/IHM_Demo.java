package agrl;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.HashMap;

import javax.swing.*;
import javax.swing.border.LineBorder;

import javafx.concurrent.Worker;




public class IHM_Demo extends JFrame {

	Garage garages = new Garage();
	RepairVehicle rp = new RepairVehicle();

	Enclosure enclosures = new Enclosure();
	CarrotWarehouse cw = new CarrotWarehouse(100);
	StrawberryWarehouse sw = new StrawberryWarehouse(100);
	EggWarehouse ew = new EggWarehouse(100);
	MilkWarehouse mw = new MilkWarehouse(100);
	WoolWarehouse ww = new WoolWarehouse(100);
	MeatWarehouse meatw = new MeatWarehouse(100);  //Ajouter


	ActionPoint actionpoint = new ActionPoint();
	Field fields = new Field();
	Hay hay = new Hay();
	Grain grain = new Grain();
	Milk milk = new Milk();
	Egg egg = new Egg();
	Wool wool = new Wool(); 
	Meat meat = new Meat(); //Ajouter

	Wallet wallet = new Wallet(20000);
	Shop shop = new Shop();
	Turn turn = new Turn();



	RandomEvents randomevents = new RandomEvents();
	Difficulty difficulty = new Difficulty(1); //1 = easy

	String mode = "navigation"; // permet de savoir ce que l'utilisateur fait, et que doivent faire les actionslisteners 
	Position positionofvehiclerunning ;

	private boolean maxWorker = false;//Qu'un seul Employer a la fois

	private boolean feedCowWorker = false;
	private boolean stillWorking = false;

	private boolean feedPigWorker = false;

	private boolean feedChickenWorker = false;

	private boolean feedSheepWorker = false;

	private int workingUntil;
	//Les diff�rentes images que le curseur prendra

	Toolkit toolkit = Toolkit.getDefaultToolkit();
	Cursor cursorcow = toolkit.createCustomCursor(toolkit.getImage("image/cow.png") , new Point(getX(), getY()), "img");
	Cursor cursorchicken = toolkit.createCustomCursor(toolkit.getImage("image/chicken.png") , new Point(getX(), getY()), "img");
	Cursor cursorsheep = toolkit.createCustomCursor(toolkit.getImage("image/sheep.png") , new Point(getX(), getY()), "img");
	Cursor cursorpig = toolkit.createCustomCursor(toolkit.getImage("image/pig.png") , new Point(getX(), getY()), "img");

	Cursor cursortractorx1 = toolkit.createCustomCursor(toolkit.getImage("image/tractor.png") , new Point(getX(), getY()), "img");
	Cursor cursortractorx2 = toolkit.createCustomCursor(toolkit.getImage("image/tractor1.png") , new Point(getX(), getY()), "img");

	Cursor cursordollar = toolkit.createCustomCursor(toolkit.getImage("image/dollar.png") , new Point(getX(), getY()), "img"); //chercher une image dollar avec fond transparent
	Cursor cursorwateringcan = toolkit.createCustomCursor(toolkit.getImage("image/wateringcan.png") , new Point(getX(), getY()), "img");

	Cursor cursorcarrot = toolkit.createCustomCursor(toolkit.getImage("image/carrot.png") , new Point(getX(), getY()), "img");
	Cursor cursorstrawberry = toolkit.createCustomCursor(toolkit.getImage("image/strawberry.png") , new Point(getX(), getY()), "img");
	Cursor cursorwhichtractor = toolkit.createCustomCursor(toolkit.getImage("image/whichtractor.png") , new Point(getX(), getY()), "img");
	Cursor cursorsickle = toolkit.createCustomCursor(toolkit.getImage("image/sickle.png") , new Point(getX(), getY()), "img");

	Cursor cursorhay = toolkit.createCustomCursor(toolkit.getImage("image/hay.png") , new Point(getX(), getY()), "img");
	Cursor cursorgrain = toolkit.createCustomCursor(toolkit.getImage("image/grain.png") , new Point(getX(), getY()), "img");
	Cursor cursorwrench = toolkit.createCustomCursor(toolkit.getImage("image/wrench.png") , new Point(getX(), getY()), "img");

	int weight = 16;
	Position[] cases = new Position[weight*weight];
	Case caseOp = new Case();
	Integer[] possibilities = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};

	JButton[] casesLabel = new JButton[weight*weight];

	//Garage Button
	protected JButton buyTractorX1Button = new JButton("<html>"+"Buy"+"<br>"+"TractorX1"+"<br>"+"(-1500)"+"</html>");
	protected JButton buyTractorX2Button = new JButton("<html>"+"Buy"+"<br>"+"TractorX2"+"<br>"+"(-3000)"+"</html>");
	protected JButton sellTractorButton = new JButton("<html>"+"Sell"+"<br>"+"Vehicle"+"</html>");
	protected JButton repairVehicleButton = new JButton("<html>"+"Repair"+"<br>"+"Vehicle"+"</html>");

	//WarehouseLabel
	protected JLabel carrotLabel = new JLabel("Carrot: " + String.valueOf(cw.getSize()));
	protected JLabel strawberryLabel = new JLabel("Strawberry: " + String.valueOf(sw.getSize()));
	protected JLabel milkLabel = new JLabel("Milk: " + String.valueOf(mw.getSize()));
	protected JLabel woolLabel = new JLabel("Wool: " + String.valueOf(ww.getSize()));
	protected JLabel eggLabel = new JLabel("Egg: " + String.valueOf(ew.getSize()));
	protected JLabel milkExpireLabel = new JLabel("Milk Expire In: " + String.valueOf(mw.warningCheck()));
	protected JLabel woolExpireLabel = new JLabel("Wool Expire In: " + String.valueOf(ww.warningCheck()));
	protected JLabel eggExpireLabel = new JLabel("Egg Expire In: " + String.valueOf(ew.warningCheck()));
	protected JLabel meatExpireLabel = new JLabel("Meat Expire In: " + String.valueOf(meatw.warningCheck()));
	protected JLabel meatLabel = new JLabel("Meat: " + String.valueOf(meatw.getSize())); //Ajouter

	//WarehouseButton
	protected JButton sellCarrotButton = new JButton("<html>"+"Sell Carrot"+"<br>"+"(+50)"+"</html>");
	protected JButton sellStrawberryButton = new JButton("<html>"+"Sell Strawberry"+"<br>"+"(+300)"+"</html>");
	protected JButton sellMilkButton = new JButton("<html>"+"Sell Milk"+"<br>"+"(+100)"+"</html>");
	protected JButton sellEggButton = new JButton("<html>"+"Sell Egg"+"<br>"+"(+5)"+"</html>");
	protected JButton sellWoolButton = new JButton("<html>"+"Sell Wool"+"<br>"+"(+10)"+"</html>");
	protected JButton sellMeatButton = new JButton("<html>"+"Sell Meat"+"<br>"+"(+2000)"+"</html>");

	//LABEL
	protected JLabel messageLabel = new JLabel("Message:");
	protected JLabel hayLabel = new JLabel("Hay: " + String.valueOf(hay.getHay()));
	protected JLabel grainLabel = new JLabel("Grain: " + String.valueOf(grain.getGrain()));
	protected JLabel infoLabel = new JLabel("Info:");
	protected JLabel goldLabel = new JLabel("Gold: "+String.valueOf(wallet.getGold()));
	protected JLabel turnLabel = new JLabel("Turn: "+String.valueOf(turn.getTurn()));

	//Field Button
	protected JButton waterButton = new JButton("Water"); 
	protected JButton nextTurnButton = new JButton("Next Turn");
	protected JButton feedwithhayButton = new JButton("Feed by hay");
	protected JButton feedwithgrainButton = new JButton("Feed by grain");
	protected JButton harvestButton = new JButton("Harvest");
	protected JButton harvestCow = new JButton("Harvest Milk");
	protected JButton harvestSheep = new JButton ("Harvest Wool");
	protected JButton slaughterButton = new JButton("Slaughter");


	//Shop Button
	protected JButton buyCowButton = new JButton("<html>"+"Buy Cow"+"<br>"+"(-1600)"+"</html>");
	protected JButton buyPigButton = new JButton("<html>"+"Buy Pig"+"<br>"+"(-400)"+"</html>");
	protected JButton buySheepButton = new JButton("<html>"+"Buy Sheep"+"<br>"+"(-150)"+"</html>");
	protected JButton buyChickenButton = new JButton("<html>"+"Buy Chicken"+"<br>"+"(-50)"+"</html>");

	protected JButton sellCowButton = new JButton("<html>"+"Sell Cow"+"<br>"+"(+800)"+"</html>");
	protected JButton sellPigButton = new JButton("<html>"+"Sell Pig"+"<br>"+"(+200)"+"</html>");
	protected JButton sellSheepButton = new JButton("<html>"+"Sell Sheep"+"<br>"+"(+75)"+"</html>");
	protected JButton sellChickenButton = new JButton("<html>"+"Sell Chicken"+"<br>"+"(+25)"+"</html>");

	protected JButton plantCarrotButton = new JButton("<html>"+"Plant Carrot"+"<br>"+"(-10)"+"</html>");
	protected JButton plantStrawberryButton = new JButton("<html>"+"Plant Strawberry"+"<br>"+"(-50)"+"</html>");
	protected JButton buyHayButton = new JButton("<html>"+"Buy Hay"+"<br>"+"(-10)"+"</html>");
	protected JButton buyGrainButton = new JButton("<html>"+"Buy Grain"+"<br>"+"(-1)"+"</html>");

	protected JButton extendFieldButton = new JButton("<html>"+"Extend Field"+"<br>"+"(-2000)"+"</html>");
	protected JButton cancelbuyButton = new JButton("Cancel buy");

	//Worker button

	protected JButton AutoFeedCow = new JButton("AutoFeedCow");
	protected JButton AutoFeedPig = new JButton("AutoFeedPig");
	protected JButton AutoFeedSheep = new JButton("AutoFeedSheep");
	protected JButton AutoFeedChicken = new JButton("AutoFeedChicken");

	protected JOptionPane dialog = new JOptionPane();
	private static final Font LABEL_FONT = new Font(Font.MONOSPACED, Font.BOLD, 20);
	private static final Font BUTTON_FONT = new Font(Font.MONOSPACED, Font.BOLD, 14);

	private CardLayout cardLayout = new CardLayout();
	private  JPanel centerPanel;      
	private  JPanel fieldPanel; 
	private JPanel workerPanel;
	private  JPanel shopPanel;
	private JPanel warehousePanel;
	private  JPanel bottomPanel;
	private  JPanel leftPanel;
	private JPanel cardPanel, buttonPanel;
	private JButton btn1, btn2, btn3, btn4;


	public IHM_Demo(String title) throws IOException {
		super(title);
		initFunction();
		initStyle();
		initLayout();
		initActions();
	}

	protected void initFunction() {
		for (int i = 0; i< casesLabel.length; i++) {
			casesLabel[i] = new JButton(new ImageIcon("image/gravel.jpg"));
		}

		for (int x=1; x<=2; x++) {
			for (int y=9; y<=16; y++) {
				int i = caseOp.findIndex(x, y);
				casesLabel[i] = new JButton(new ImageIcon("image/grass.jpg"));
				casesLabel[i].putClientProperty("x", x);
				casesLabel[i].putClientProperty("y", y);
				casesLabel[i].addActionListener(new updateInfoAnimalAction());
			}
		}

		for (int x=4; x<=5; x++) {
			for (int y=9; y<=16; y++) {
				int i = caseOp.findIndex(x, y);
				casesLabel[i] = new JButton(new ImageIcon("image/straw.jpg"));
				casesLabel[i].putClientProperty("x", x);
				casesLabel[i].putClientProperty("y", y);
				casesLabel[i].addActionListener(new updateInfoAnimalAction());
			}
		}

		for (int x=7; x<=8; x++) {
			for (int y=9; y<=16; y++) {
				int i = caseOp.findIndex(x, y);
				casesLabel[i] = new JButton(new ImageIcon("image/soli.jpg"));
				casesLabel[i].putClientProperty("x", x);
				casesLabel[i].putClientProperty("y", y);
				casesLabel[i].addActionListener(new updateInfoAnimalAction());
			}
		}

		for (int x=10; x<=11; x++) {
			for (int y=9; y<=16; y++) {
				int i = caseOp.findIndex(x, y);
				casesLabel[i] = new JButton(new ImageIcon("image/grass.jpg"));
				casesLabel[i].putClientProperty("x", x);
				casesLabel[i].putClientProperty("y", y);
				casesLabel[i].addActionListener(new updateInfoAnimalAction());
			}
		}

		for (int x=1; x<=2; x++) {
			for (int y=1; y<=6; y++) {
				int i = caseOp.findIndex(x, y);
				casesLabel[i] = new JButton(new ImageIcon("image/road.jpg"));
				casesLabel[i].putClientProperty("x", x);
				casesLabel[i].putClientProperty("y", y);
				casesLabel[i].addActionListener(new UpdateInfoGarageAction());
			}
		}

		for (int x=4; x<=4+2+fields.getLevel(); x++) {
			for (int y=1; y<=6; y++) {
				int i = caseOp.findIndex(x, y);
				casesLabel[i] = new JButton(new ImageIcon("image/ground.jpg"));
				casesLabel[i].putClientProperty("x", x);
				casesLabel[i].putClientProperty("y", y);
				casesLabel[i].addActionListener(new updateInfoFieldAction());

			}
		}
	}

	protected void initActions(){
		//Field Action
		/*feedAllCowButton.addActionListener(new feedAllCowAction());
		feedAllChickenButton.addActionListener(new feedAllChickenAction());
		feedAllSheepButton.addActionListener(new feedAllSheepAction());
		feedAllPigButton.addActionListener(new feedAllPigAction());*/
		feedwithhayButton.addActionListener(new feedwithhayAction());
		feedwithgrainButton.addActionListener(new feedwithgrainAction());
		waterButton.addActionListener(new waterAction());
		harvestButton.addActionListener(new harvestAction());
		harvestCow.addActionListener(new harvestMilk());
		harvestSheep.addActionListener(new harvestWool());
		slaughterButton.addActionListener(new slaughterAction());
		nextTurnButton.addActionListener(new nextTurnAction());
		plantCarrotButton.addActionListener(new plantCarrotAction());
		plantStrawberryButton.addActionListener(new plantStrawberryAction());

		//WROKER ACtion
		AutoFeedCow.addActionListener(new autoFeedCowAction());
		AutoFeedPig.addActionListener(new autoFeedPigAction());
		AutoFeedSheep.addActionListener(new autoFeedSheepAction());
		AutoFeedChicken.addActionListener(new autoFeedChickenAction());


		//Shop Action
		buyCowButton.addActionListener(new buyCowAction());
		buyChickenButton.addActionListener(new buyChickenAction());
		buySheepButton.addActionListener(new buySheepAction());
		buyPigButton.addActionListener(new buyPigAction());
		sellCowButton.addActionListener(new sellCowAction());
		sellChickenButton.addActionListener(new sellChickenAction());
		sellSheepButton.addActionListener(new sellSheepAction());
		sellPigButton.addActionListener(new sellPigAction());
		buyTractorX1Button.addActionListener(new buyTractorX1Action());
		buyTractorX2Button.addActionListener(new buyTractorX2Action());
		sellTractorButton.addActionListener(new sellTractorAction());
		repairVehicleButton.addActionListener(new repairVehicleAction());
		buyHayButton.addActionListener(new buyHayAction());
		buyGrainButton.addActionListener(new buyGrainAction());
		extendFieldButton.addActionListener(new extendFieldAction());
		cancelbuyButton.addMouseListener(new cancelBuyAction());

		//Warehouse Action
		sellCarrotButton.addActionListener(new sellCarrotAction());
		sellStrawberryButton.addActionListener(new sellStrawberryAction());
		sellMilkButton.addActionListener(new sellMilkAction());
		sellEggButton.addActionListener(new sellEggAction());
		sellWoolButton.addActionListener(new sellWoolAction());
		sellMeatButton.addActionListener(new sellMeatAction());
	}


	protected void initLayout() throws IOException{
		setPreferredSize(new Dimension(1200,800));
		centerPanel = new JPanel();         
		shopPanel = new JPanel();   
		bottomPanel = new JPanel();
		fieldPanel = new JPanel();
		workerPanel = new JPanel();
		buttonPanel = new JPanel();
		warehousePanel = new JPanel();
		leftPanel = new JPanel();

		setLayout(new BorderLayout());
		centerPanel.setLayout(new GridBagLayout()); //Field
		shopPanel.setLayout(new GridLayout(5,4)); // line; columns 
		bottomPanel.setLayout(new GridLayout(2,7)); //Info
		fieldPanel.setLayout(new GridLayout(4,2));  //PLAY
		workerPanel.setLayout(new GridLayout(4,2));
		leftPanel = new JPanel(new GridLayout(16,1)); //TICK
		warehousePanel.setLayout(new GridLayout(4,3)); 
		cardPanel = new JPanel();
		cardPanel.setLayout(cardLayout);



		add(centerPanel, BorderLayout.CENTER);
		add(bottomPanel, BorderLayout.SOUTH);
		add(cardPanel, BorderLayout.EAST);
		add(buttonPanel, BorderLayout.NORTH);
		add(leftPanel, BorderLayout.WEST);

		//leftPanel
		for( int i = 1; i<=16; i++) {
			JLabel temp = new JLabel(" " + String.valueOf(i) + " ");
			Font leftLabel_FONT = new Font(Font.MONOSPACED, Font.BOLD, 15);
			temp.setFont(leftLabel_FONT);
			leftPanel.add(temp);
		}

		//Bottom Panel
		bottomPanel.add(goldLabel);
		bottomPanel.add(turnLabel);
		bottomPanel.add(hayLabel);
		bottomPanel.add(grainLabel);
		bottomPanel.add(messageLabel);
		bottomPanel.add(carrotLabel);
		bottomPanel.add(strawberryLabel);
		bottomPanel.add(milkLabel);
		bottomPanel.add(woolLabel);
		bottomPanel.add(eggLabel);
		bottomPanel.add(meatLabel);


		//Warehouse Panel
		warehousePanel.setPreferredSize(new Dimension(480,690));
		warehousePanel.add(sellMilkButton);
		warehousePanel.add(sellEggButton);
		warehousePanel.add(sellWoolButton);
		warehousePanel.add(sellCarrotButton);
		warehousePanel.add(sellStrawberryButton);
		warehousePanel.add(sellMeatButton);
		//warehousePanel.add(milkLabel);
		//warehousePanel.add(eggLabel);
		//warehousePanel.add(woolLabel);
		//warehousePanel.add(carrotLabel);
		//warehousePanel.add(meatLabel);
		warehousePanel.add(milkExpireLabel);
		warehousePanel.add(eggExpireLabel);
		warehousePanel.add(woolExpireLabel);
		warehousePanel.add(meatExpireLabel);
		//warehousePanel.add(strawberryLabel);



		//Field Panel
		fieldPanel.setPreferredSize(new Dimension(480,690));
		/*fieldPanel.add(feedAllCowButton);
		fieldPanel.add(feedAllChickenButton);
		fieldPanel.add(feedAllPigButton);
		fieldPanel.add(feedAllSheepButton);*/
		fieldPanel.add(feedwithhayButton);
		fieldPanel.add(feedwithgrainButton);
		fieldPanel.add(waterButton);
		fieldPanel.add(nextTurnButton);
		fieldPanel.add(harvestButton);
		fieldPanel.add(harvestCow);
		fieldPanel.add(slaughterButton);


		//Shop Panel
		shopPanel.setPreferredSize(new Dimension(480,690));
		shopPanel.add(buyCowButton);
		shopPanel.add(buyChickenButton);
		shopPanel.add(buyPigButton);
		shopPanel.add(buySheepButton);
		shopPanel.add(sellCowButton);
		shopPanel.add(sellChickenButton);
		shopPanel.add(sellPigButton);
		shopPanel.add(sellSheepButton);
		shopPanel.add(buyTractorX1Button);
		shopPanel.add(buyTractorX2Button);
		shopPanel.add(sellTractorButton);
		shopPanel.add(repairVehicleButton);

		shopPanel.add(plantCarrotButton);
		shopPanel.add(plantStrawberryButton);
		shopPanel.add(buyHayButton);
		shopPanel.add(buyGrainButton);

		shopPanel.add(extendFieldButton);
		shopPanel.add(cancelbuyButton);

		//Worker Panel
		workerPanel.add(AutoFeedCow);
		workerPanel.add(AutoFeedPig);
		workerPanel.add(AutoFeedSheep);
		workerPanel.add(AutoFeedChicken);


		//Center Panel
		GridBagConstraints gbc = new GridBagConstraints();
		centerPanel.setLayout(new GridLayout(16,16));
		centerPanel.setPreferredSize(new Dimension(640,640));
		int u = 0;
		while (u<=(casesLabel.length-1)) {
			for (int  p = 0; p < weight; p++) {
				for (int i = 0; i < weight; i++) {
					gbc.gridx = i;
					gbc.gridy = p;
					casesLabel[u].setBorder(null);
					casesLabel[u].setBorderPainted(false);
					casesLabel[u].setMargin(new Insets(0,0,0,0));
					casesLabel[u].setPreferredSize(new Dimension(40,40));
					centerPanel.add( casesLabel[u], gbc);
					u++;
				}
			}
		}
		cardPanel.setPreferredSize(new Dimension(480,690));
		cardPanel.add(fieldPanel, "MAIN");
		cardPanel.add(shopPanel, "SHOP");
		cardPanel.add(warehousePanel, "WAREHOUSE");
		cardPanel.add(workerPanel, "WORKER");

		//button FIELD
		btn1 = new JButton("FIELD");
		btn1.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				cardLayout.show(cardPanel, "MAIN");
			}
		});

		//button GO TO SHOP
		btn2 = new JButton("GO TO SHOP");
		btn2.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				cardLayout.show(cardPanel, "SHOP");
			}
		});

		//button WAREHOUSE
		btn3 = new JButton("WAREHOUSE");
		btn3.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				cardLayout.show(cardPanel, "WAREHOUSE");
			}
		});

		//button Worker
		btn4 = new JButton("WORKER");
		btn4.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				cardLayout.show(cardPanel, "WORKER");
			}
		});
		buttonPanel.add(btn1);
		buttonPanel.add(btn2);
		buttonPanel.add(btn3);
		buttonPanel.add(btn4);

		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		pack();
	}



	protected void initStyle() {
		for (int i =0; i< casesLabel.length; i++) {
			casesLabel[i].setFont(LABEL_FONT);
		}

		//Shop style

		buyTractorX1Button.setFont(BUTTON_FONT);
		buyTractorX2Button.setFont(BUTTON_FONT);
		sellTractorButton.setFont(BUTTON_FONT);
		repairVehicleButton.setFont(BUTTON_FONT);

		buyCowButton.setFont(BUTTON_FONT);
		buyChickenButton.setFont(BUTTON_FONT);
		buyPigButton.setFont(BUTTON_FONT);
		buySheepButton.setFont(BUTTON_FONT);

		sellCowButton.setFont(BUTTON_FONT);
		sellChickenButton.setFont(BUTTON_FONT);
		sellPigButton.setFont(BUTTON_FONT);
		sellSheepButton.setFont(BUTTON_FONT);

		plantCarrotButton.setFont(BUTTON_FONT);
		plantStrawberryButton.setFont(BUTTON_FONT);
		buyHayButton.setFont(BUTTON_FONT);
		buyGrainButton.setFont(BUTTON_FONT);
		nextTurnButton.setFont(BUTTON_FONT);
		harvestButton.setFont(BUTTON_FONT);
		cancelbuyButton.setFont(BUTTON_FONT);
		extendFieldButton.setFont(BUTTON_FONT);

		//Bottom information style
		goldLabel.setFont(LABEL_FONT);
		goldLabel.setForeground(new Color(242,205,72));
		turnLabel.setFont(LABEL_FONT);
		turnLabel.setForeground(Color.red);
		hayLabel.setFont(LABEL_FONT);
		grainLabel.setFont(LABEL_FONT);
		infoLabel.setFont(LABEL_FONT);
		messageLabel.setFont(LABEL_FONT);
		messageLabel.setForeground(Color.green);
		carrotLabel.setFont(LABEL_FONT);
		strawberryLabel.setFont(LABEL_FONT);
		milkLabel.setFont(LABEL_FONT);
		woolLabel.setFont(LABEL_FONT);
		meatLabel.setFont(LABEL_FONT);
		eggLabel.setFont(LABEL_FONT);

		//Field 
		feedwithhayButton.setFont(LABEL_FONT);
		feedwithgrainButton.setFont(LABEL_FONT);
		waterButton.setFont(LABEL_FONT);
		nextTurnButton.setFont(LABEL_FONT);
		harvestButton.setFont(LABEL_FONT);
		harvestCow.setFont(LABEL_FONT);
		slaughterButton.setFont(LABEL_FONT);

		//Warehouse
		sellMilkButton.setFont(BUTTON_FONT);
		sellEggButton.setFont(BUTTON_FONT);
		sellCarrotButton.setFont(BUTTON_FONT);
		sellStrawberryButton.setFont(BUTTON_FONT);
		sellWoolButton.setFont(BUTTON_FONT);
		sellMeatButton.setFont(BUTTON_FONT);
		meatExpireLabel.setFont(BUTTON_FONT);
		milkExpireLabel.setFont(BUTTON_FONT);
		woolExpireLabel.setFont(BUTTON_FONT);
		meatExpireLabel.setFont(BUTTON_FONT);
		eggExpireLabel.setFont(BUTTON_FONT);

	}


	//FIELD ACTION
	private class sellCowAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			mode="sellcow";
			setCursor(cursordollar);
			actualizeWallet();
			actualizeAll();
		}
	}

	private class sellChickenAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			mode="sellchicken";
			setCursor(cursordollar);
			actualizeWallet();
			actualizeAll();
		}
	}

	private class sellPigAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			mode="sellpig";
			setCursor(cursordollar);
			actualizeWallet();
			actualizeAll();
		}
	}

	private class sellSheepAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			mode="sellsheep";
			setCursor(cursordollar);
			actualizeWallet();
			actualizeAll();
		}
	}

	private class buyCowAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			if (wallet.getGold()<1600){
				System.out.println("money<1600");
				messageLabel.setText("Not enough money to buy cow");
				showError("NOT ENOUGH MONEY TO PROCESS");
			} else {
				mode="buycow";
				setCursor(cursorcow);
			}
		}


	}

	private class buyChickenAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			if (wallet.getGold()<50){
				System.out.println("money<50");
				messageLabel.setText("Not enough money to buy chicken");
				showError("NOT ENOUGH MONEY TO PROCESS");
			} else {
				mode="buychicken";
				setCursor(cursorchicken);
			}
		}
	}

	private class buyPigAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			if (wallet.getGold()<400){
				System.out.println("money<400");
				messageLabel.setText("Not enough money to buy pig");
				showError("NOT ENOUGH MONEY TO PROCESS");
			} else {
				mode="buypig";
				setCursor(cursorpig);
			}
		}
	}

	private class buySheepAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			if (wallet.getGold()<150){
				System.out.println("money<150");
				messageLabel.setText("Not enough money to buy sheep");
				showError("NOT ENOUGH MONEY TO PROCESS");
			} else {
				mode="buysheep";
				setCursor(cursorsheep);
			}
		}
	}

	// A faire
	private class slaughterAction implements ActionListener {
		public void actionPerformed(ActionEvent e){

			int x = userChoice("Please select rows", "COW TO BE HARVESTED");
			int y = userChoice("Please select columns", "COW TO BE HARVESTED");

			int animal = enclosures.whichAnimal(caseOp.findCase(x, y));
			Animal check = enclosures.accesValue(caseOp.findCase(x, y));
			if (animal == 0) {
				showError("ANIMAL NOT FOUND");
			} else {

				if (animal == 1) {
					if (check.getAge() > 5) {
						enclosures.removeAnimal(caseOp.findCase(x, y));
						meatw.add(meat);
						showInfo("COW IS SLAUGHTED", "SLAUGHTED");
					} else {
						showError("NOT ENOUGH AGE: \n" + check.getAge() +"/5");
					}
				} else if (animal == 3) {
					if (check.getAge() > 5) {
						enclosures.removeAnimal(caseOp.findCase(x, y));
						meatw.add(meat);
						showInfo("PIG IS SLAUGHTED", "SLAUGHTED");
					} else {
						showError("NOT ENOUGH AGE: \n" + check.getAge() +"/5");
					}
				} else if (animal == 2) {
					if (check.getAge() > 5) {
						enclosures.removeAnimal(caseOp.findCase(x, y));
						meatw.add(meat);
						showInfo("CHICKEN IS SLAUGHTED", "SLAUGHTED");
					} else {
						showError("NOT ENOUGH AGE: \n" + check.getAge() +"/5");
					}
				} else if (animal == 4) {
					if (check.getAge() > 5) {
						enclosures.removeAnimal(caseOp.findCase(x, y));
						meatw.add(meat);
						showInfo("SHEEP IS SLAUGHTED", "SLAUGHTED");
					} else {
						showError("NOT ENOUGH AGE: \n" + check.getAge() +"/5");
					}
				} else {
					showError("ERROR");
				}
			}
			actualizeAll();
		}
	}


	/*private class feedAllCowAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			if (hay.getHay() >= enclosures.totalCow()) {
				enclosures.feedAllCow();
				hay.removeHay(enclosures.feeded());
				actualizeHay();
				actualizeAnimal();
			}	
		}	
	}

	private class feedAllSheepAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			if (hay.getHay() >= enclosures.totalSheep()) {
				enclosures.feedAllSheep();
				hay.removeHay(enclosures.totalSheep());
				actualizeHay();
				actualizeAnimal();
			}	
		}	
	}

	private class feedAllChickenAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			if (grain.getGrain() >= enclosures.totalChicken()) {
				enclosures.feedAllChicken();
				grain.removeGrain(enclosures.totalChicken());
				actualizeGrain();
				actualizeAnimal();
			}	
		}	
	}

	private class feedAllPigAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			if (grain.getGrain() >= enclosures.totalPig()) {
				enclosures.feedAllPig();
				grain.removeGrain(enclosures.totalPig());
				actualizeGrain();
				actualizeAnimal();
			}	
		}	
	}
	 */

	private class updateInfoAnimalAction implements ActionListener {

		public void actionPerformed(ActionEvent e){


			int x = (int)((JComponent) e.getSource()).getClientProperty( "x" );
			int y =  (int)((JComponent) e.getSource()).getClientProperty( "y" );

			if (mode=="navigation"){
				if (enclosures.whichAnimal(caseOp.findCase(x, y)) == 0) {
					showError("ANIMAL NOT FOUND");
				} else {
					Animal animal =enclosures.accesValue(caseOp.findCase(x, y));
					showInfo(animal.toString(), "info");
				}
			}
			else if (mode=="buycow"){

				if (x<=2 && y>=9 && y<= 16) {
					if (enclosures.whichAnimal(caseOp.findCase(x, y)) == 0) {
						shop.buyCow(wallet, enclosures, caseOp.findCase(x, y));
						showInfo("Cow bought", "Purchased confirmation");
						messageLabel.setText("Cow bought");
						actualizeWallet();
					} else {
						showError("ALREADY ADDED");
					}
				} else {
					messageLabel.setText("CANNOT ADD COW");
					showError("CANNOT ADD COW");
					System.out.println("CANNOT ADD COW");
				}

			}

			else if (mode=="buychicken"){

				if (x<=5 && x>=4 && y>=9 && y<= 16) {
					if (enclosures.whichAnimal(caseOp.findCase(x, y)) == 0) {
						shop.buyChicken(wallet, enclosures, caseOp.findCase(x, y));
						showInfo("Chicken bought", "Purchased confirmation");
						messageLabel.setText("Chicken bought");
						actualizeWallet();
					} else {
						showError("ALREADY ADDED");
					}
				} else {
					messageLabel.setText("CANNOT ADD CHICKEN");
					showError("CANNOT ADD CHICKEN");
					System.out.println("CANNOT ADD CHICKEN");
				}
			}

			else if (mode=="buypig"){

				if (x<=8 && x>=7 && y>=9 && y<= 16) {
					if (enclosures.whichAnimal(caseOp.findCase(x, y)) == 0) {
						shop.buyPig(wallet, enclosures, caseOp.findCase(x, y));
						showInfo("Pig bought", "Purchased confirmation");
						messageLabel.setText("Pig bought");
						actualizeWallet();
					} else {
						showError("ALREADY ADDED");
					}
				} else {
					messageLabel.setText("CANNOT ADD PIG");
					showError("CANNOT ADD PIG");
					System.out.println("CANNOT ADD PIG");
				}

			}

			else if (mode=="buysheep"){

				if (x<=11 && x>=10 && y>=9 && y<= 16) {
					if (enclosures.whichAnimal(caseOp.findCase(x, y)) == 0) {
						shop.buySheep(wallet, enclosures, caseOp.findCase(x, y));
						showInfo("Sheep bought", "Purchased confirmation");
						messageLabel.setText("Sheep bought");
						actualizeWallet();
					} else {
						showError("ALREADY ADDED");
					}
				} else {
					messageLabel.setText("CANNOT ADD SHEEP");
					showError("CANNOT ADD SHEEP");
					System.out.println("CANNOT ADD SHEEP");
				}

			}

			else if (mode=="sellcow"){

				if (x<=2 && y>=9 && y<= 16) {
					if (enclosures.whichAnimal(caseOp.findCase(x, y)) == 0) {
						showError("COW NOT FOUND");
					} else {
						shop.sellCow(wallet, enclosures, caseOp.findCase(x, y));
						messageLabel.setText("Cow sold");
						showInfo("Cow sold", "Sold confirmation");
					}
				} else {
					showError("OUT OF ZONE");
				}

			}

			else if (mode=="sellchicken"){

				if (x<=5 && x>=4 && y>=9 && y<= 16) {
					if (enclosures.whichAnimal(caseOp.findCase(x, y)) == 0) {
						showError("CHICKEN NOT FOUND");
					} else {
						shop.sellChicken(wallet, enclosures, caseOp.findCase(x, y));
						messageLabel.setText("Chicken sold");
						showInfo("Chicken sold", "Sold confirmation");
					}
				} else {
					showError("OUT OF ZONE");
				}

			}

			else if (mode=="sellpig"){

				if (x<=8 && x>=7 && y>=9 && y<= 16) {
					if (enclosures.whichAnimal(caseOp.findCase(x, y)) == 0) {
						showError("PIG NOT FOUND");
					} else {
						shop.sellPig(wallet, enclosures, caseOp.findCase(x, y));
						messageLabel.setText("Pig sold");
						showInfo("Pig sold", "Sold confirmation");
					}
				} else {
					showError("OUT OF ZONE");
				}

			}

			else if (mode=="sellsheep"){

				if (x<=11 && x>=10 && y>=9 && y<= 16) {
					if (enclosures.whichAnimal(caseOp.findCase(x, y)) == 0) {
						showError("SHEEP NOT FOUND");
					} else {
						shop.sellSheep(wallet, enclosures, caseOp.findCase(x, y));
						messageLabel.setText("Sheep sold");
						showInfo("Sheep sold", "Sold confirmation");
					}
				} else {
					showError("OUT OF ZONE");
				}

			}

			else if(mode=="feedwithhayanimal"){ //A faire

				if (hay.getHay()>=1){ 
					if (enclosures.whichAnimal(caseOp.findCase(x, y)) == 0) {
						showError("ANIMAL NOT FOUND");
					} 
					else if((enclosures.whichAnimal(caseOp.findCase(x, y)) == 1)||(enclosures.whichAnimal(caseOp.findCase(x, y)) == 4)){
						enclosures.accesValue(caseOp.findCase(x, y)).feed();
						hay.removeHay(1);
					}
					else if((enclosures.whichAnimal(caseOp.findCase(x, y)) == 2)||(enclosures.whichAnimal(caseOp.findCase(x, y)) == 3)){
						showInfo("This animal doesn't eat hay", "Wrong way !");
					}

				} else {
					showError("NOT ENOUGH HAY TO FEED");
				}
			}

			else if(mode=="feedwithgrainanimal"){
				if (grain.getGrain()>=1){ 
					if (enclosures.whichAnimal(caseOp.findCase(x, y)) == 0) {
						showError("ANIMAL NOT FOUND");
					}

					else if((enclosures.whichAnimal(caseOp.findCase(x, y)) == 2)||(enclosures.whichAnimal(caseOp.findCase(x, y)) == 3)){
						enclosures.accesValue(caseOp.findCase(x, y)).feed();
						grain.removeGrain(1);
					}

					else if((enclosures.whichAnimal(caseOp.findCase(x, y)) == 1)||(enclosures.whichAnimal(caseOp.findCase(x, y)) == 4)){
						showInfo("This animal doesn't eat grain", "Wrong way !");
					}

				} else {
					showError("NOT ENOUGH GRAIN TO FEED");
				}
			}

			cancelBuy();
			actualizeWallet();
			actualizeAll();
		}
	}

	private class feedwithhayAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			mode="feedwithhayanimal";
			setCursor(cursorhay);
		}
	}

	private class feedwithgrainAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			mode="feedwithgrainanimal";
			setCursor(cursorgrain);
		}
	}

	private class waterAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			setCursor(cursorwateringcan);
			mode="water";
			actualizeCrop();
		}
	}

	//Repair
	private class repairVehicleAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			mode="repairvehicle";
			setCursor(cursorwrench);
			actualizeWallet();
			actualizeAll();
		}
	}

	//Buy TractorX1
	private class buyTractorX1Action implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			if (wallet.getGold()<1500){
				//System.out.println("money<1500");
				messageLabel.setText("Not enough money to buy this item");
				showError("NOT ENOUGH MONEY TO PROCESS");
			} else {
				if (garages.addMore() == false)  {
					//System.out.println("Cannot add more vehicle");
					messageLabel.setText("Cannot buy anymore");
					showError("CANNOT ADD MORE VEHICLE");
				} else {
					mode="buytractorx1";
					setCursor(cursortractorx1);
				} 
			}
			actualizeWallet();
			actualizeAll();
		}
	}

	//Buy TractorX2
	private class buyTractorX2Action implements ActionListener {

		public void actionPerformed(ActionEvent e){
			cancelBuy();
			if (wallet.getGold()<3000){
				System.out.println("money<3000");
				messageLabel.setText("Not enough money to buy this item");
				showError("NOT ENOUGH MONEY TO PROCESS");
			} else {
				if (garages.addMore() == false) {
					System.out.println("Cannot add more vehicle");
					messageLabel.setText("Cannot buy anymore");
					showError("CANNOT ADD MORE VEHICLE");
				} else {
					mode="buytractorx2";
					setCursor(cursortractorx2);
				} 
			}
			actualizeWallet();
			actualizeAll();
		}
	}

	// Sell Tractor
	private class sellTractorAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();

			if (garages.getNumberVehicle()==0){
				System.out.println("No item to sell");
				messageLabel.setText("No item to sell");
				showError("TRACTOR NOT FOUND");
			}
			else {
				mode="selltractor";
				setCursor(cursordollar);
			}
			actualizeWallet();
			actualizeAll();
		}
	}



	private class UpdateInfoGarageAction implements ActionListener {

		public void actionPerformed(ActionEvent e){
			int x = (int)((JComponent) e.getSource()).getClientProperty( "x" );
			int y =  (int)((JComponent) e.getSource()).getClientProperty( "y" );

			if(mode=="navigation"){

				if (garages.whichVehicle(caseOp.findCase(x,y)) == 0) {
					showError("TRACTOR NOT FOUND");
				} else {
					messageLabel.setText(garages.updateStatus(caseOp.findCase(x,y)));
					showInfo(garages.updateStatus(caseOp.findCase(x,y)), "Infomation");
				}
			}
			else if(mode=="buytractorx1"){
				//System.out.println("Current number of vehicle: " + (garages.getNumberVehicle()+1));

				if (x<=2 && y<=6) {
					if (garages.whichVehicle(caseOp.findCase(x, y)) == 0) {
						shop.buyTractorX1(wallet,garages, caseOp.findCase(x, y));
						showInfo("Tractor X1 bought", "Purchased confirmation");
						messageLabel.setText("Tractor X1 bought");
						actualizeWallet();
					} else {
						showError("ALREADY ADDED");
					}
				} else {
					messageLabel.setText("CANNOT ADD TRACTOR");
					showError("CANNOT ADD TRACTOR");

				}
			}

			else if(mode=="buytractorx1"){
				System.out.println("Current number of vehicle: " + garages.getNumberVehicle());
				if (x<=2 && y<=6) {
					if (garages.whichVehicle(caseOp.findCase(x, y)) == 0) {
						shop.buyTractorX2(wallet,garages, caseOp.findCase(x, y));
						showInfo("Tractor X2 bought", "Purchased confirmation");
						messageLabel.setText("Tractor X2 bought");
						actualizeWallet();
					}  else {
						showError("ALREADY ADDED");
					}
				} else {
					messageLabel.setText("CANNOT ADD TRACTOR");
					showError("CANNOT ADD TRACTOR");
					System.out.println("CANNOT ADD TRACTOR");
				}

			}

			else if(mode=="selltractor"){

				shop.sellTractor(wallet,garages, caseOp.findCase(x,y));
				System.out.println("Item sold");
				System.out.println("Current number of vehicle: " + garages.getNumberVehicle());
				showInfo("Tractor removed", "Sold confirmation");
				messageLabel.setText("Item sold");

			}

			else if(mode=="repairvehicle"){

				if (x>=2 && y>=6) {
					showError("OUT ZONE");
				}
				else if (garages.whichVehicle(caseOp.findCase(x, y)) == 0) {
					showError("TRACTOR NOT FOUND");
				} else {
					shop.repairTractor(wallet, garages, caseOp.findCase(x, y));
					showInfo("Tractor repaired", "Repair confirmation");
					messageLabel.setText("Tractor repaired");
				}
			}

			else if(mode=="tractorusedtoharvest"){
				positionofvehiclerunning = caseOp.findCase(x,y);
				showInfo("Select which crop you want harvest", "info");
				mode="croptoharvest";
				setCursor(cursorsickle);
			}

			if(!(mode=="croptoharvest")){
				cancelBuy();
			}
			actualizeAll();
		}
	}

	private class harvestMilk implements ActionListener {


		public void actionPerformed(ActionEvent e) {

			boolean able = actionpoint.verifyPoint(ALparameters.cowHarvest);

			if (able == true) {

				int z = userChoice("Please select rows", "COW TO BE HARVESTED");
				int t = userChoice("Please select columns", "COW TO BE HARVESTED");

				if (enclosures.whichAnimal(caseOp.findCase(z, t))== 1 && (enclosures.accesValue(caseOp.findCase(z, t)).getHarvested())==false){

					showInfo("HARVESTED", "Information");
					enclosures.accesValue(caseOp.findCase(z, t)).harvested();
					mw.add(milk);
					actualizeMilk();


				}

				else {

					System.out.println(enclosures.whichAnimal(caseOp.findCase(z, t)));
					showInfo("Not a Cow", "Infomation");

				}

			}

			else {

				showInfo("NOT ENOUGHT ACTION POINT", "Infomation");
				//message d'erreur plus assez de point d'action
			}



		}

	}

	private class harvestWool implements ActionListener{


		public void actionPerformed(ActionEvent e) {

			boolean able = actionpoint.verifyPoint(ALparameters.sheepHarvest);

			if (able == true) {

				int z = userChoice("Please select rows", "COW TO BE HARVESTED");
				int t = userChoice("Please select columns", "COW TO BE HARVESTED");

				if (enclosures.whichAnimal(caseOp.findCase(z, t))== 4){

					showInfo("HARVESTED", "Information");
					mw.add(milk);
					actualizeMilk();


				}

				else {

					System.out.println(enclosures.whichAnimal(caseOp.findCase(z, t)));
					showInfo("Not a sheep", "Infomation");

				}

			}
		}
	}

	private class harvestAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			mode="tractorusedtoharvest";
			setCursor(cursorwhichtractor);
			actualizeWallet();
			actualizeAll();	
		}
	}

	private class sellCarrotAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			shop.sellCarrot(cw, wallet);
			actualizeCarrot();
			actualizeWallet();
		}
	}

	private class sellStrawberryAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			shop.sellStrawberry(sw, wallet);
			actualizeStrawberry();
			actualizeWallet();
		}
	}

	private class sellMilkAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			shop.sellMilk(mw, wallet);
			actualizeMilk();
			actualizeWallet();
		}
	}

	private class sellWoolAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			shop.sellWool(ww, wallet);
			actualizeWool();
			actualizeWallet();
		}
	}

	private class sellEggAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			shop.sellEgg(ew, wallet);
			actualizeEgg();
			actualizeWallet();
		}
	}

	private class sellMeatAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			shop.sellMeat(meatw, wallet);
			actualizeMeat();
			actualizeWallet();
		}
	}

	public void actualizeTractor() {
		ImageIcon tractor = new ImageIcon("image/tractorx1road.jpg");
		ImageIcon tractor1 = new ImageIcon("image/tractorx2road.jpg");
		ImageIcon blank = new ImageIcon("image/road.jpg");
		for (int x=1; x<=2; x++) {
			for (int y=1; y<=6; y++) {
				int valV = garages.whichVehicle(caseOp.findCase(x, y));
				int i = caseOp.findIndex(x, y);
				if (valV == 1) {
					casesLabel[i].setIcon(tractor);
				} else if (valV == 2) {
					casesLabel[i].setIcon(tractor1);
				} else {
					casesLabel[i].setIcon(blank);
				}
				casesLabel[i].setBorder(null);
				casesLabel[i].setBorderPainted(false);
				casesLabel[i].setMargin(new Insets(0,0,0,0));
			}
		}
	}

	public void actualizeAnimal() {
		ImageIcon cow = new ImageIcon("image/cowgrass.jpg");
		ImageIcon cowstarve = new ImageIcon("image/cowstarve.jpg");
		ImageIcon chicken = new ImageIcon("image/chickenstraw.jpg");
		ImageIcon chickenstarve = new ImageIcon("image/chickenstarve.jpg");
		ImageIcon pig = new ImageIcon("image/pigsoli.jpg");
		ImageIcon pigstarve = new ImageIcon("image/pigstarve.jpg");
		ImageIcon sheep = new ImageIcon("image/sheepgrass.jpg");
		ImageIcon sheepstarve = new ImageIcon("image/sheepstarve.jpg");
		ImageIcon grass = new ImageIcon("image/grass.jpg");
		ImageIcon straw = new ImageIcon("image/straw.jpg");
		ImageIcon soli = new ImageIcon("image/soli.jpg");
		//For Cow
		for (int x=1; x<=2; x++) {
			for (int y=9; y<=16; y++) {
				int valE = enclosures.whichAnimal(caseOp.findCase(x, y));
				Animal a =  enclosures.accesValue(caseOp.findCase(x, y));
				int i = caseOp.findIndex(x, y);
				if (valE == 1) {
					if (a.getFed() == false) { 
						casesLabel[i].setIcon(cowstarve);
					} else {
						casesLabel[i].setIcon(cow);
					}
				} else {
					casesLabel[i].setIcon(grass);
				}
				casesLabel[i].setBorder(null);
				casesLabel[i].setBorderPainted(false);
				casesLabel[i].setMargin(new Insets(0,0,0,0));
			}
		}
		//For Chicken
		for (int x=4; x<=5; x++) {
			for (int y=9; y<=16; y++) {
				int valE = enclosures.whichAnimal(caseOp.findCase(x, y));
				Animal a =  enclosures.accesValue(caseOp.findCase(x, y));
				int i = caseOp.findIndex(x, y);
				if (valE == 2) {
					if (a.getFed() == false) { 
						casesLabel[i].setIcon(chickenstarve);
					} else {
						casesLabel[i].setIcon(chicken);
					} 
				} else {
					casesLabel[i].setIcon(straw);
				}
				casesLabel[i].setBorder(null);
				casesLabel[i].setBorderPainted(false);
				casesLabel[i].setMargin(new Insets(0,0,0,0));
			}
		}
		//For Pig
		for (int x=7; x<=8; x++) {
			for (int y=9; y<=16; y++) {
				int valE = enclosures.whichAnimal(caseOp.findCase(x, y));
				Animal a =  enclosures.accesValue(caseOp.findCase(x, y));
				int i = caseOp.findIndex(x, y);
				if (valE == 3) {
					if (a.getFed() == false) { 
						casesLabel[i].setIcon(pigstarve);
					} else {
						casesLabel[i].setIcon(pig);
					}
				} else {
					casesLabel[i].setIcon(soli);
				}
				casesLabel[i].setBorder(null);
				casesLabel[i].setBorderPainted(false);
				casesLabel[i].setMargin(new Insets(0,0,0,0));
			}
		}

		//For Sheep
		for (int x=10; x<=11; x++) {
			for (int y=9; y<=16; y++) {
				int valE = enclosures.whichAnimal(caseOp.findCase(x, y));
				Animal a =  enclosures.accesValue(caseOp.findCase(x, y));
				int i = caseOp.findIndex(x, y);
				if (valE == 4) {
					if (a.getFed() == false) { 
						casesLabel[i].setIcon(sheepstarve);
					} else {
						casesLabel[i].setIcon(sheep);
					}
				} else {
					casesLabel[i].setIcon(grass);
				}
				casesLabel[i].setBorder(null);
				casesLabel[i].setBorderPainted(false);
				casesLabel[i].setMargin(new Insets(0,0,0,0));
			}
		}

	}

	public void actualizeCrop() {
		ImageIcon carrot = new ImageIcon("image/carrotground.jpg");
		ImageIcon strawberry = new ImageIcon("image/strawberrygorund.jpg");
		ImageIcon ground = new ImageIcon("image/ground.jpg");
		ImageIcon carrotwater = new ImageIcon("image/carrotwater.jpg");
		ImageIcon strawberrywater = new ImageIcon("image/strawberrywater.jpg");
		ImageIcon carrotwarning = new ImageIcon("image/carrotwarning.jpg");
		ImageIcon strawberrywarning = new ImageIcon("image/strawberrywarning.jpg");
		ImageIcon carrotready = new ImageIcon("image/carrotready.jpg");
		ImageIcon strawberryready = new ImageIcon("image/strawberryready.jpg");
		for (int x=4; x<=4+2+fields.getLevel(); x++) {
			for (int y=1; y<=6; y++) {
				int valF = fields.whichCrop(caseOp.findCase(x, y));
				Crop c = fields.accesValue(caseOp.findCase(x, y));
				int i = caseOp.findIndex(x, y);
				if (valF == 3) {
					if (c.isHarvested()) {
						casesLabel[i].setIcon(carrotready);
					} else {
						if (c.isDying()) {
							casesLabel[i].setIcon(carrotwarning);
						} else if (c.getWater() == false) {
							casesLabel[i].setIcon(carrotwater);
						} else {
							casesLabel[i].setIcon(carrot);
						}
					}
				} else if (valF == 4) {
					if (c.isHarvested()) {
						casesLabel[i].setIcon(strawberryready);
					} else {
						if (c.isDying()) {
							casesLabel[i].setIcon(strawberrywarning);
						} else if (c.getWater() == false) {
							casesLabel[i].setIcon(strawberrywater);
						} else {
							casesLabel[i].setIcon(strawberry);
						}
					}
				} else {
					casesLabel[i].setIcon(ground);
				}
				casesLabel[i].setBorder(null);
				casesLabel[i].setBorderPainted(false);
				casesLabel[i].setMargin(new Insets(0,0,0,0));
			}
		}
	}

	public void actualizeAll() {
		actualizeTractor();
		actualizeAnimal();
		actualizeCrop();
		actualizeWarehouse();
	}


	public void actualizeWallet(){
		goldLabel.setText("Gold : "+String.valueOf(wallet.getGold()));
	}

	public void actualizeExtendFieldButton(){
		extendFieldButton.setText("EXTEND FIELD lv "+ fields.getLevel());
	}

	public void actualizeField(){
		for (int x=6+fields.getLevel(); x<=6+fields.getLevel(); x++) {
			for (int y=1; y<=6; y++) {
				int i = caseOp.findIndex(x, y);
				System.out.println("i= "+i);

				//casesLabel[i] = new JButton(new ImageIcon("ground.jpg"));
				casesLabel[i].setIcon(new ImageIcon("image/ground.jpg"));
				casesLabel[i].putClientProperty("x", x);
				casesLabel[i].putClientProperty("y", y);

				casesLabel[i].addActionListener(new updateInfoFieldAction());
			}
		}
	}

	public void showError(String custom) {
		JOptionPane.showMessageDialog(new JFrame(), custom, "Error",
				JOptionPane.ERROR_MESSAGE);
	}


	// Turn management
	private class nextTurnAction implements ActionListener {
		public void actionPerformed(ActionEvent e){

			cancelBuy();
			turn.goTurn();
			turn.turnCrops(fields, caseOp);
			turn.turnAnimal(enclosures, caseOp, milk, egg, wool ,mw, ew, ww);
			turn.turnWarehouse(cw, sw);
			randomevents.RandomEventsrisk(turn,caseOp, sw, cw, difficulty, enclosures, fields);

			if (feedCowWorker == true && stillWorking == true){

				System.out.println("on est bon");
				stillWorking=enclosures.autoFeedAllCow(turn.getTurn(),workingUntil);
				actualizeMilk();

				if (stillWorking == false){

					feedCowWorker = false;
					maxWorker = false;
					showInfo("Worker finished his contract", "Information");

				}
			}
			else if (feedPigWorker == true && stillWorking == true){

				System.out.println("on est bon");
				stillWorking=enclosures.autoFeedAllPig(turn.getTurn(),workingUntil);
				actualizeMilk();

				if (stillWorking == false){

					feedPigWorker = false;
					maxWorker = false;
					showInfo("Worker finished his contract", "Information");
				}
			}
			else if (feedSheepWorker == true && stillWorking == true){

				System.out.println("on est bon");
				stillWorking=enclosures.autoFeedAllSheep(turn.getTurn(),workingUntil);
				actualizeMilk();

				if (stillWorking == false){

					feedSheepWorker = false;
					maxWorker = false;
					showInfo("Worker finished his contract", "Information");
				}
			}
			else if (feedChickenWorker == true && stillWorking == true){

				System.out.println("on est bon");
				stillWorking=enclosures.autoFeedAllChicken(turn.getTurn(),workingUntil);
				actualizeMilk();

				if (stillWorking == false){

					feedChickenWorker = false;
					maxWorker = false;
					showInfo("Worker finished his contract", "Information");
				}
			}
			actualizeAll();
			actualizeWarehouse();
			actualizeTurn();
			actualizeEvent();
		}
	}


	private class updateInfoFieldAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			int x = (int)((JComponent) e.getSource()).getClientProperty( "x" );
			int y =  (int)((JComponent) e.getSource()).getClientProperty( "y" );

			if(mode=="navigation"){
				if (fields.whichCrop(caseOp.findCase(x,y)) == 0) {
					showError("CROP NOT FOUND");
				} else {
					messageLabel.setText(fields.updateStatus(caseOp.findCase(x,y)));
					showInfo(fields.updateStatus(caseOp.findCase(x,y)), "Infomation");
				}
			}

			else if (mode=="water"){

				if (fields.whichCrop(caseOp.findCase(x, y)) == 0) {
					showError("PLANT NOT FOUND");
				}else {
					fields.accesValue(caseOp.findCase(x, y)).water();
				}
			}

			else if (mode=="plantcarrot"){

				if (x >=4 && x <= 4+2+fields.getLevel() && y <= 6) {
					if (fields.whichCrop(caseOp.findCase(x,y))==0) {
						shop.buyCarrot(fields, wallet,caseOp.findCase(x,y));
						messageLabel.setText("ADDED");
						actualizeAll();
						actualizeWallet();
					} else {
						showError("ALREADY ADDED");
					}
				} else {
					messageLabel.setText("CANNOT ADD CARROT");
					showError("CANNOT ADD CARROT");
				}

			}

			else if (mode=="plantstrawberry"){

				if (x >=4 && x <= 4+2+fields.getLevel() && y <= 6) {
					if (fields.whichCrop(caseOp.findCase(x,y))==0) {
						shop.buyStrawberry(fields, wallet,caseOp.findCase(x,y));
						messageLabel.setText("ADDED");
						actualizeAll();
						actualizeWallet();
					} else {
						showError("ALREADY ADDED");
					}
				} else {
					messageLabel.setText("CANNOT ADD STRAWBERRY");
					showError("CANNOT ADD STRAWBERRY");
				}

			}

			else if(mode=="croptoharvest"){
				System.out.println(mode);
				Vehicle v = garages.accesValue(positionofvehiclerunning);
				Crop c = fields.accesValue(caseOp.findCase(x,y));
				if (garages.whichVehicle(positionofvehiclerunning) == 2){ 
					if (c.isHarvested()) {
						if (c instanceof Carrot) {
							cw.add(c);
							cw.add(c);
							actualizeCarrot();
						} else if (c instanceof Strawberry) {
							sw.add(c);
							sw.add(c);
							actualizeStrawberry();
						}
						fields.removeCrop(caseOp.findCase(x,y));
						v.harvestStatus();
						showInfo("HARVESTED", "Infomation");
					} else {
						showInfo("NOT ENOUGH AGE TO HARVEST", "Information");
					}

				} else if (garages.whichVehicle(positionofvehiclerunning) == 1) {
					if (c.isHarvested()) {
						if (c instanceof Carrot) {
							cw.add(c);
							actualizeCarrot();
						} else if (c instanceof Strawberry) {
							sw.add(c);
							actualizeStrawberry();
						}
						fields.removeCrop(caseOp.findCase(x,y));
						v.harvestStatus();
						showInfo("HARVESTED", "Infomation");
					} else {
						showInfo("NOT ENOUGH AGE TO HARVEST", "Information");
					}
				}
			}

			cancelBuy();


			actualizeCrop();
		}
	}

	//Plant carrot
	private class plantCarrotAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			mode="plantcarrot";
			setCursor(cursorcarrot);
		}	
	}


	//Plant strawberry
	private class plantStrawberryAction implements ActionListener {
		public void actionPerformed(ActionEvent e){
			cancelBuy();
			mode="plantstrawberry";
			setCursor(cursorstrawberry);
		}
	}

	public int userChoice(String info, String title) {
		try {
			Integer index = (Integer)JOptionPane.showInputDialog(new JFrame(), info, title,
					JOptionPane.INFORMATION_MESSAGE, new ImageIcon(), possibilities, 0);
			return index; 
		} catch(NullPointerException e) {
			return 0;
		}
	}


	//Buy hay
	private class buyHayAction implements ActionListener {

		public void actionPerformed(ActionEvent e){
			if (wallet.getGold()<(hay.getHay()*10)){ 
				showError("NOT ENOUGH MONEY TO BUY HAY");
			} else{
				shop.buyHay(wallet, hay);
				actualizeHay();
				actualizeWallet();
				messageLabel.setText("Hay Bought");
			}
		}
	}

	private class buyGrainAction implements ActionListener {

		public void actionPerformed(ActionEvent e){
			if (wallet.getGold()<(grain.getGrain()*10)){ 
				showError("NOT ENOUGH MONEY TO BUY GRAIN");
			} else{
				shop.buyGrain(wallet, grain);
				actualizeGrain();
				actualizeWallet();
				messageLabel.setText("Grain Bought");
			}
		}
	}

	private class extendFieldAction implements ActionListener {

		public void actionPerformed(ActionEvent e){
			if (wallet.getGold()<2000){ 
				showError("NOT ENOUGH MONEY TO EXTENDS THE FIELD");
			}
			else {
				wallet.removeGold(2000);
				actualizeWallet();


				fields.levelUp();
				actualizeField();
				actualizeExtendFieldButton();
			}
		}
	}

	//WORKER PANEL

	private class autoFeedCowAction implements ActionListener{

		public void actionPerformed(ActionEvent e){
			if (maxWorker == false){
				
				maxWorker = true;
				if (wallet.getGold()>500){
					
					if (feedCowWorker == false)
						
						feedCowWorker = true;
						stillWorking = true;
						workingUntil = turn.getTurn()+4;
						wallet.removeGold(500);
						actualizeWallet();

				}
				else {

					showInfo("Not enought money", "Information");
					
				}
			}
			else {
				
				showInfo("Already have a Worker in progress", "Information");
			}
		}	
	}		
	
	private class autoFeedPigAction implements ActionListener{

		public void actionPerformed(ActionEvent e){
			if (maxWorker == false){
				maxWorker = true;
				if (wallet.getGold()>500){
					
					if (feedPigWorker == false)
						
						feedPigWorker = true;
						stillWorking = true;
						workingUntil = turn.getTurn()+4;
						wallet.removeGold(500);
						actualizeWallet();

				}
				else {

					showInfo("Not enought money", "Information");
					
				}
			}
			else {
				
				showInfo("Already have a Worker in progress", "Information");
			}
		}	
	}
	
	private class autoFeedSheepAction implements ActionListener{

		public void actionPerformed(ActionEvent e){
			if (maxWorker == false){
				maxWorker = true;
				if (wallet.getGold()>500){
					
					if (feedSheepWorker == false)
						
						feedSheepWorker = true;
						stillWorking = true;
						workingUntil = turn.getTurn()+4;
						wallet.removeGold(500);
						actualizeWallet();

				}
				else {

					showInfo("Not enought money", "Information");
					
				}
			}
			else {
				
				showInfo("Already have a Worker in progress", "Information");
			}
		}	
	}

	private class autoFeedChickenAction implements ActionListener{

		public void actionPerformed(ActionEvent e){
			if (maxWorker == false){
				maxWorker = true;
				if (wallet.getGold()>500){
					
					if (feedChickenWorker == false)
						
						feedChickenWorker = true;
						stillWorking = true;
						workingUntil = turn.getTurn()+4;
						wallet.removeGold(500);
						actualizeWallet();

				}
				else {

					showInfo("Not enought money", "Information");
					
				}
			}
			else {
				
				showInfo("Already have a Worker in progress", "Information");
			}
		}	
	}
	private class cancelBuyAction implements MouseListener {

		@Override
		public void mouseClicked(MouseEvent e) {

			cancelBuy();

		}

		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseReleased(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub

		}	

	}





	public void actualizeHay(){
		hayLabel.setText("Hay: "+String.valueOf(hay.getHay()));
	}

	public Position getPosition(int index) {
		return caseOp.accesValue(index);
	}

	public void actualizeCarrot(){
		carrotLabel.setText("Carrot: "+String.valueOf(cw.getSize()));

	}

	public void actualizeStrawberry(){
		strawberryLabel.setText("Strawberry: "+String.valueOf(sw.getSize()));
	}

	public void actualizeMilk(){
		milkLabel.setText("Milk "+String.valueOf(mw.getSize()));
		milkExpireLabel.setText("Milk Expire In: " + String.valueOf(mw.warningCheck()));
	}

	public void actualizeEgg(){
		eggLabel.setText("Egg: "+String.valueOf(ew.getSize()));
		eggExpireLabel.setText("Egg Expire In: " + String.valueOf(ew.warningCheck()));
	}

	public void actualizeWool(){
		woolLabel.setText("Wool: "+String.valueOf(ww.getSize()));
		woolExpireLabel.setText("Wool Expire In: " + String.valueOf(ww.warningCheck()));
	}

	public void actualizeGrain(){
		grainLabel.setText("Grain: "+String.valueOf(grain.getGrain()));
	}

	public void actualizeTurn(){
		turnLabel.setText("Turn: "+String.valueOf(turn.getTurn()));
	}

	public void actualizeEvent() {
		String show = randomevents.RandomEventsrisk(turn,caseOp, sw, cw, difficulty, enclosures, fields);
		showInfo(show, "");
	}

	public void actualizeMeat() {
		meatLabel.setText("Meat: "+String.valueOf(meatw.getSize()));
		meatExpireLabel.setText("Meat Expire In: " + String.valueOf(meatw.warningCheck()));
	}


	private void actualizeWarehouse() {
		actualizeMeat();
		actualizeMilk();
		actualizeEgg();
		actualizeWool();
		actualizeCarrot();
		actualizeStrawberry();
	}

	public void showInfo(String custom, String title) {
		JOptionPane.showMessageDialog(new JFrame(), custom, title,
				JOptionPane.INFORMATION_MESSAGE);
	}

	public void cancelBuy(){
		if (mode!="navigation"){
			mode="navigation";
			setCursor(Cursor.getDefaultCursor());
		}
	}

	public static void changeFont ( Component component, Font font )
	{
		component.setFont ( font );
		if ( component instanceof Container )
		{
			for ( Component child : ( ( Container ) component ).getComponents () )
			{
				changeFont ( child, font );
			}
		}
	}

	public static void main(String[] args) throws IOException {
		new IHM_Demo("Demo");
	}
}
