package agrl;

public class StrawberryWarehouse{
	private Crop[] strawberrys;
	protected int maxCapacity;
	protected int currentSize = 0;

	public StrawberryWarehouse(int maxCapacity) {
		this.maxCapacity = maxCapacity;
		strawberrys = new Strawberry[maxCapacity];
	}

	public void add(Crop strawberry) {
		if (currentSize != strawberrys.length) {
			strawberrys[currentSize] = strawberry;
			currentSize++;
		}
	}

	public void remove(Crop strawberry) {
		int i;
		for (i = 0; i<currentSize; i++) {
			if (strawberrys[i].equals(strawberry)) {
				strawberrys[i] = null;
				break;
			}
		}
		for (int j = i; i<currentSize -1; i++) {
			strawberrys[j] = strawberrys[j + 1];
		}
		if (i != currentSize) {
			currentSize--;
		}
	}

	public void check() {
		for(int i=0; i<currentSize;i++) {
			strawberrys[i].warning();
			if(	strawberrys[i].lapsingStatus()) {
				remove(strawberrys[i]);
				System.out.println("EXPIRE");
				System.out.println("Strawberry at posistion " + i + " is removed");
		}
	}
	}

	public Crop accesValue(int search) {
		Crop res = null;
		for(int i=0; i<currentSize;i++) {
			if (i == search) {
				res = strawberrys[i];
			}
		}
		return res;
	}
	public int getSize() {
		return currentSize;
	}
	}