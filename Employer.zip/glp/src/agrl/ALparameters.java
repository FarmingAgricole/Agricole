package agrl;

public class ALparameters {
	
	
	public static final int cowHarvest = 1; // cout (pa) de la recolte de lait
	public static final int sheepHarvest = 1;
	public static final int chickenHarvest = 1;
	public static final int cropHarvest = 1;
	public static final int feedAction = 1;
	
	public static final int buyCowPrice = 1600;
	public static final int buySheepPrice = 400;
	public static final int buyChickenPrice = 200;
	public static final int buyPigPrice = 400;
	
	public static final int sellCowPrice= buyCowPrice/2;
	public static final int sellSheepPrice= buySheepPrice/2;
	public static final int sellChickenPrice= buyChickenPrice/2;
	public static final int sellPigPrice= buyPigPrice/2;
	
	public static final int buyHayPrice = 10;
	public static final int buyGrainPrice = 10;
	
	public static final int buyStrawPrice = 35;
	public static final int sellStrawPrice= 250;
	
	public static final int buyCarrotPrice = 10;
	public static final int sellCarrotPrice = 50;
	
	public static final int sellMilkPrice = 20;
	public static final int sellWoolPrice = 150;
	public static final int sellEggPrice = 15;
	public static final int sellMeatPrice = 1000;
	
	
	
	
	public static final int beginWith = 2; //Point d'action par tour
}
