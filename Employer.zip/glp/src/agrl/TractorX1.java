package agrl;

public class TractorX1 extends Vehicle {

	public TractorX1() {
		super("Tractor X1", 100);
	}
	
	public void harvestStatus() {
		super.harvestStatus();
	}
	
	public void setHavest(int gaint) {
		super.setHarvest(gaint);
	}
	
	public String toString() {
		return super.toString();
	}
}
