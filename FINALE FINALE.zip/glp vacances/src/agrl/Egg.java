package agrl;

public class Egg {
	
	protected int egg = 0;
	protected int dayspassed;
	protected static int lapsingmax = 30;
	
	public Egg(){
		
	}
	
	public int getEgg(){
		return this.egg;
	}
	
	public void addEgg(int amount){
		this.egg = this.egg + amount;
	}
	
	public void removeEgg(int amount){
		this.egg = this.egg - amount;
	}
	public void daysPasse() { 
		this.dayspassed++;
	}

	public int getDaysPassed() {
		return dayspassed;
	}
	
	public boolean lapsingStatus() { //Check if the item is passe lapsing day
		if (dayspassed > lapsingmax) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean lapsingWarning() { //Allow user to know the item will expire or not
		if (dayspassed >= lapsingmax -3 && dayspassed <= lapsingmax) {
			return true;
		} else {
			return false;
		}
	}
}
