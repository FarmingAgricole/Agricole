package agrl;

public class MilkWarehouse {
	private Milk[] milks;
	protected int maxCapacity;
	protected int currentSize = 0;

	public MilkWarehouse(int maxCapacity) {
		this.maxCapacity = maxCapacity;
		milks = new Milk[maxCapacity];
	}

	public void add(Milk milk) {
		if (currentSize != milks.length) {
			milks[currentSize] = milk;
			currentSize++;
		}
	}

	public void remove(Milk milk) {
		int i;
		for (i = 0; i<currentSize; i++) {
			if (milks[i].equals(milk)) {
				milks[i] = null;
				break;
			}
		}
		for (int j = i; i<currentSize -1; i++) {
			milks[j] = milks[j + 1];
		}
		if (i != currentSize) {
			currentSize--;
		}
	}

	public void check() {
		for(int i=0; i<currentSize;i++) {
			if(	milks[i].lapsingStatus()) {
				remove(milks[i]);
				System.out.println("EXPIRE");
				System.out.println("Milk at posistion " + i + " is removed");
		}
	}
	}
	
	public int warningCheck() { //Check number of all item ready to pass date limit
		int val = 0;
		for(int i=0; i<currentSize;i++) {
			if(	milks[i].lapsingWarning()) {
				val++;
			}
		}
		return val;
	}

	public Milk accesValue(int search) {
		Milk res = null;
		for(int i=0; i<currentSize;i++) {
			if (i == search) {
				res = milks[i];
			}
		}
		return res;
	}
	public int getSize() {
		return currentSize;
	}
}
