package agrl;

public class EggWarehouse {
	private Egg[] eggs;
	protected int maxCapacity;
	protected int currentSize = 0;

	public EggWarehouse(int maxCapacity) {
		this.maxCapacity = maxCapacity;
		eggs = new Egg[maxCapacity];
	}

	public void add(Egg Egg) {
		if (currentSize != eggs.length) {
			eggs[currentSize] = Egg;
			currentSize++;
		}
	}

	public void remove(Egg Egg) {
		int i;
		for (i = 0; i<currentSize; i++) {
			if (eggs[i].equals(Egg)) {
				eggs[i] = null;
				break;
			}
		}
		for (int j = i; i<currentSize -1; i++) {
			eggs[j] = eggs[j + 1];
		}
		if (i != currentSize) {
			currentSize--;
		}
	}

	public void check() {
		for(int i=0; i<currentSize;i++) {
			if(	eggs[i].lapsingStatus()) {
				remove(eggs[i]);
				System.out.println("EXPIRE");
				System.out.println("Egg at posistion " + i + " is removed");
		}
	}
	}
	
	public int warningCheck() { //Check number of all item ready to pass date limit
		int val = 0;
		for(int i=0; i<currentSize;i++) {
			if(	eggs[i].lapsingWarning()) {
				val++;
			}
		}
		return val;
	}

	public Egg accesValue(int search) {
		Egg res = null;
		for(int i=0; i<currentSize;i++) {
			if (i == search) {
				res = eggs[i];
			}
		}
		return res;
	}
	public int getSize() {
		return currentSize;
	}
}
