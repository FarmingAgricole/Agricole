package agrl;

public class Case {
	protected int x, y;
	Position[] cases = new Position[256];
	public Case() { //Setup the game field
		for (int i=0; i< cases.length; i++) {
			for (int x=1; x<=16; x++) {
				for (int y=1; y<=16; y++) {
					cases[i] = new Position(x,y);
					i++;
				}
			}
		}
	}

	//Return value of case index i by xy
	public Position findCase(int rows, int colums) {
		Position p = null;
		for (int i=0; i< cases.length; i++) {
			for (int x=1; x<=16; x++) {
				for (int y=1; y<=16; y++) {
					if (x == rows && y == colums) {
						p = cases[i];
					}
					i++;
				}
			}
		}
		return p;
	}

	//Return index of case by xy
	public int findIndex(int rows, int colums) {
		int find = 0;
		for (int i=0; i< cases.length; i++) {
					if (cases[i].getX() == rows && cases[i].getY() == colums) {
						find = i;
				}
			}
		return find;
	}
	
	public Position accesValue(int search) {
		Position p = null;
		for (int i = 0; i< cases.length; i++) {
			if (i == search) {
				p = cases[i];	
			}
		}
		return p;
	}
}
