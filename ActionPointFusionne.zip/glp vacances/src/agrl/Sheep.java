package agrl;

public class Sheep extends Animal{
	
	protected int healthpoint;
	protected static int maxhealth = 100 ;
	
	public Sheep(){
		super();
	}
	
	public Sheep(int healthpoint){ 
		super(healthpoint,maxhealth);
	}

	
	public void setHealthPoint(int currenthealth){ //change les points de vie
		super.setHealthPoint(currenthealth);
	}
	
	public String getShape(){
		return super.getShape();
	}
	
	public int getHealthPoint(){ //retourne les points de vie
		return super.getHealthPoint();
	}
	
	public void getOlder() {
		super.getOlder();
	}
	
	public String toString(){
		return "Feeded: " + super.getFed() + "\n"+ "Age:"+super.getAge()+" days"+"\n"+super.toString();
	}

}