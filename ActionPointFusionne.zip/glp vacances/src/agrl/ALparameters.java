package agrl;

public class ALparameters {
	
	//Action Point (pa) section//
	
	public static final int cowHarvest = 1; // cout (pa) de la recolte de lait
	public static final int sheepHarvest = 1;
	public static final int chickenHarvest = 1;
	public static final int cropHarvest = 1;
	public static final int feedAction = 1;
	
	
	public static final int beginWith = 2; //Point d'action par tour
}
