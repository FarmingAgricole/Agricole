package agrl;

//refonte fraiche le 25/02/2017
public abstract class Animal extends Shape {
	
	protected boolean fed = false;
	protected int age;
	public Animal(){
		super();
	}
	
	public Animal(int healthpoint, int maxhealth){
		super(healthpoint,maxhealth);
		this.age = 0;
		
	}
	
	public void setHealtPoint(int currenthealth){ //change les points de vie
		super.setHealthPoint(currenthealth);
	}
	
	
	public int getHealthPoint(){ //retourne les points de vie
		return super.getHealthPoint();
	}
	
	public void isStarving(){ // a passer en abstrait si on veut rendre spécifique la perte de hp suite a une famine
		super.setHealthPoint(super.getHealthPoint()-20);
	}
	
	public String getShape(){
		return super.getShape();
	}
	
	public void feed(){
		this.fed=true;
	}
	
	public void starve(){
		this.fed=false;
	}
	
	public boolean getFed(){
		return this.fed;
	}
	
	public void getOlder() {
		this.age++;
	}
	
	public int getAge() {
		return this.age;
	}
	
	public String toString(){
		return super.toString();
	}
	
}