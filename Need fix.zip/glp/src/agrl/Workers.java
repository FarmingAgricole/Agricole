package agrl;

import java.util.Collection;
import java.util.HashMap;

public class Workers {

	private int nbmax;
	private HashMap<Position, Animal> animals = new HashMap<Position, Animal>();

	public Workers (int nbmax){

		this.nbmax = nbmax;

	}

	public void autoHarvestMilk(MilkWarehouse mw, Milk milk) {

		Collection<Animal> values = animals.values();
		for (Animal animal : values) {
			if (animal instanceof Cow) {
				if (animal.getHarvested() == false) {
					animal.harvested();
					mw.add(milk);
				}
			}

		}
	}
}

