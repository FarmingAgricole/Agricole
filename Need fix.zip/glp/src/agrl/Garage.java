package agrl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
public class Garage {
	private int max_place = 12;
	
	private boolean res;
	private HashMap<Position, Vehicle> vehicles = new HashMap<Position, Vehicle>();

	public Garage() {
	}
	
	//Add TractorX1
	public void addTractorX1(Position p) {
		Vehicle v = accesValue(p);
			if (v == null) {
				vehicles.put(p, new TractorX1());
				System.out.println("ADDED");
			} else {
				System.out.println("CANNOT ADDED");		
			}
	}
	
	//Add tractorX2
	public void addTractorX2(Position p) {
		Vehicle v = accesValue(p);
		if (v == null) {
			vehicles.put(p, new TractorX2());
			System.out.println("ADDED");
		} else {
			System.out.println("CANNOT ADDED");	
		}
}
	//Remove vehicle
	public void removeVehicle(Position p) {
				vehicles.remove(p);
			}
	
	public boolean added() {
		return res;
	}
	
	//Check if garage is full or not
	public boolean addMore() {
		if (getNumberVehicle() < getMaxPlace()) {
			return true;
		} else {
			return false;
		}
	}
	
	//Return value X1 or X2
	public int whichVehicle(Position p) {
		int res = 0;
		Vehicle v = accesValue(p);
		if(v == null) {
			res = 0;
		} else if (v instanceof TractorX1) {
			res = 1;
		} else if (v instanceof TractorX2) {
			res = 2;
		}
		return res;
	}
	
	//Show info of tractor
	public String updateStatus(Position p) {
		return accesValue(p).toString();
	}
	
	
	public Vehicle accesValue(Position p) {
		Vehicle v = (Vehicle)vehicles.get(p);
		return v;
	}
	
	public int getNumberVehicle() {
		return vehicles.size();
	}
	
	public int getMaxPlace() {
		return max_place;
	}
	

	/*public String toString() {
	Iterator iterator = vehicles.keySet().iterator();
	while (iterator.hasNext()) {
		   Position key = (Position) iterator.next();
		   Vehicle value = vehicles.get(key);
		   System.out.println("Position:" + key.toString() + " - Report: " + value.toString());
	}
	return null;
}*/

}
